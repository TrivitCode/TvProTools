#include "stdafx.h"
#include "TestToolGen.h"

#include "ProToolkit.h"
#include "ProFeature.h"
#include "ProElemId.h"
#include "ProExtrude.h"
#include "ProModFeat.h"
#include "ProStdSection.h"
#include "ProElement.h"
#include "ProElempath.h"
#include "ProFeatType.h"
#include "ProFeatForm.h"
#include "ProSelection.h"
#include "ProSection.h"
//#include <PTApplsUnicodeUtils.h>

#include "ProDtmCrv.h"

#include <TvSolid.h>
#include <TvSection.h>
#include <ProCurve.h>
#include <ProDtlentity.h>
#include <TvMacro.h>
#include <ProSecdim.h>

ProError LoadTest()
{
	ProError err = PRO_TK_NO_ERROR;

	CString PathName = L"D:\\Test\\ToolGen\\dwg\\3700220.dwg";
	CString TargetPath = L"D:\\Temp";
	PathName.Replace(L"\\", L"\\\\");
	TargetPath.Replace(L"\\", L"\\\\");

	CString Cmd;
	Cmd.Format(L"~ Command `ProCmdModelOpen`;\
~ Trail `UI Desktop` `UI Desktop` `DLG_PREVIEW_POST` `file_open`;\
~ Select `file_open` `Type` 1  `db_-1`;\
~ Update `file_open` `Inputname` `%s`;\
~ Activate `file_open` `Inputname`;\
~ Select `impt_new_model` `RadioGroup1` 1 `drawing`;\
~ Activate `impt_new_model` `PushButton3`;\
~ Select `import_2d_dlg` `space_list` 1 `model_space`;\
~ Select `import_2d_dlg` `dim_pict_group` 1 `as_dims`;\
~ Activate `import_2d_dlg` `assoc_button` 1;\
~ Activate `import_2d_dlg` `blocks_button` 1;\
~ Activate `import_2d_dlg` `points_button` 0;\
~ Activate `import_2d_dlg` `var_size_button` 0;\
~ Activate `import_2d_dlg` `multi_line_button` 1;\
~ Activate `import_2d_dlg` `OK_Button`;NO!;NO!;\
~ Command `ProCmdDwgPageSetup`;\
~ Arm `pagesetup` `TblFormats` 2 `1` `fmt`;\
~ Select `pagesetup` `TblFormats` 2 `1` `fmt`;\
~ Activate `pagesetup` `ChkShowFmt` 0;\
~ Select `pagesetup` `RadUnits` 1 `mm`;\
~ Activate `pagesetup` `OK`;\
~ Command `ProCmdModelSaveAs`;\
~ Open `file_saveas` `type_option`;\
~ Close `file_saveas` `type_option`;\
~ Select `file_saveas` `type_option` 1 `db_560`;\
~ Input `file_saveas` `opt_EMBED_BROWSER_TB_SAB_LAYOUT` `%s`;\
~ Update `file_saveas` `opt_EMBED_BROWSER_TB_SAB_LAYOUT` `%s`;\
~ Activate `file_saveas` `opt_EMBED_BROWSER_TB_SAB_LAYOUT`;\
~ Activate `file_saveas` `OK`;\
~ Open `export_2d_dlg` `Version_Menu`;\
~ Close `export_2d_dlg` `Version_Menu`;\
~ Select `export_2d_dlg` `Version_Menu` 1 `2004`;\
~ Select `export_2d_dlg` `Splines_Group` 1 `as_polylines`;\
~ Select `export_2d_dlg` `Hatching_Group` 1 `as_sep_ent`;\
~ Select `export_2d_dlg` `Points_Group` 1 `as_shapes`;\
~ Select `export_2d_dlg` `Notes_Group` 1 `as_notes`;\
~ Activate `export_2d_dlg` `Mtext_Button` 1;\
~ Open `export_2d_dlg` `Alignment_Menu`;\
~ Close `export_2d_dlg` `Alignment_Menu`;\
~ Select `export_2d_dlg` `Alignment_Menu` 1 `as_is`;\
~ Activate `export_2d_dlg` `OK_Button`;", PathName, TargetPath, TargetPath);

	err = ProMacroLoad(Cmd.GetBuffer());
	return err;

	err = ProMacroExecute();
	if (err) return err;

	return PRO_TK_NO_ERROR;
}