// TvProTools.h : Hauptheaderdatei f�r die TvProTools-DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "'stdafx.h' vor dieser Datei f�r PCH einschlie�en"
#endif

#include "resource.h"		// Hauptsymbole

// CTvProToolsApp
// Siehe TvProTools.cpp f�r die Implementierung dieser Klasse
//

class CTvProToolsApp : public CWinApp
{
public:
	CTvProToolsApp();

// �berschreibungen
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
