#include "stdafx.h"
#include "TvHoleTableEx.h"

ProError TvHoleTableEx()
{
	ProError err = PRO_TK_NO_ERROR;

//	ShellExecute(NULL, L"open", L"notepad.exe", NULL, NULL, SW_NORMAL);
	//step 1: collect all hole feature
	


	return err;
}