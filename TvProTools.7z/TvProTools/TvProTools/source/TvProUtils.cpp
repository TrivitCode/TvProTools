#include "stdafx.h"
#include <ProUITree.h>
#include <TvSolid.h>
#include <ProAsmcomp.h>
#include "TvProUtils.h"

static UINT_PTR m_TimerId = 0;
static const int m_TimerInterval = 10000;
static int m_TimerCounter = 0;

ProError TvXMLSave()
{
	ProError err = PRO_TK_NO_ERROR;
	ProError eno = PRO_TK_NO_ERROR;
	CString msg = L"";

	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"Please select a feature...");
	if (err) _TVERR(err);

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("membfeat", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err || nSels != 1) _TVMSGERRTEXT("TVPROTOOLS_MSGW", L"select cancelled", err);

	ProFeature feat;
	err = ProSelectionModelitemGet( pSels[0], (ProModelitem*) &feat);
	if( err ) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "ProSelectionModelitemGet", err);

	ProAsmcomppath comp_path;
	err = ProSelectionAsmcomppathGet( pSels[0], &comp_path );
	if (err) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "ProSelectionAsmcomppathGet", err);

	TvFeature Feat(feat);
	Feat.SetAsmcomppath(comp_path);

	err = Feat.Initialize();
	if (err) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "TvFeature::Initialize", err);

	// make name
	ProPath path;
	err = ProDirectoryCurrentGet(path);
	if (err) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "ProDirectoryCurrentGet", err);

	CString pathname;
	pathname.Format(L"%s%s.xml", path, Feat.GetName());

	// Write XML
	err = Feat.WriteToXML(pathname);
	if (err)
	{
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "TvFeature::WriteToXML", TvProErrors[-err]);
	}
	else
	{
		msg.Format(L"write feature information of %s successfully to XML file: %s", Feat.GetName(), pathname);
		ProMessageClear();
		err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
	}

	pathname.Format(L"%s%s.txt", path, Feat.GetName());
	CFile f(pathname, CFile::modeCreate|CFile::modeReadWrite|CFile::modeNoTruncate);
	CString _msg = L"", line;
	line.Format(L"Feature \n\tname: %s, \n\tType=%d, \n\tID=%d\n", Feat.GetName(), Feat.GetType(), Feat.GetID());
	_msg += line;

	ProLine subType;
	err = ProFeatureSubtypeGet(Feat.GetFeature(), subType);
	if (err== PRO_TK_NO_ERROR)
	{
		line.Format(L"\tSubtype=%s\n", subType);
		_msg += line;
	}

	ProWVerstamp stamp;
	err = ProFeatureVerstampGet(Feat.GetFeature(), &stamp);
	if (err == PRO_TK_NO_ERROR)
	{
		char* p_stamp_string;
		err = ProVerstampStringGet( stamp, &p_stamp_string );
		if (err == PRO_TK_NO_ERROR)
		{
			ProVerstampStringFree( &p_stamp_string );
			line.Format(L"\tstamp=%s\n", p_stamp_string);
			_msg += line;
		}

		ProVerstampFree( &stamp );
	}

	if (Feat.GetType () == 1000)
	{
		// asm comp
		ProMdlType mdl_type;
		ProFamilyName mdl_name;
		err = ProAsmcompMdlNameGet(Feat.GetFeature(), &mdl_type, mdl_name);
		if (err == PRO_TK_NO_ERROR)
		{
			line.Format(L"\tmdl_type=%d\n\tmdl_name=%s\n", mdl_type, mdl_name);
			_msg += line;
		}
	}

	f.Write(CW2A(_msg), _msg.GetLength());
	f.Close();
	msg.Format(L"write feature information of %s successfully to text file: %s", Feat.GetName(), pathname);
	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());

	
	/////////////////////////
	
	return err;
}

ProError TvConstrGet()
{
	ProError err = PRO_TK_NO_ERROR;
	ProError eno = PRO_TK_NO_ERROR;

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("component", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err ) return err;

	ProAsmcomp asmcomp;
	err = ProSelectionModelitemGet( pSels[0], (ProModelitem*) &asmcomp);
	if( err ) return err;

	//asmcomp.type = (ProType) PRO_FEAT_COMPONENT;
	ProAsmcompconstraint* constr_array;
	err = ProAsmcompConstraintsGet(&asmcomp, &constr_array);
	if( err ) return err;

	int size = 0;
	err = ProArraySizeGet (constr_array, &size);
	if( err ) return err;

	for( int i = 0; i < size; i++)
	{
		ProAsmcompConstrType type;
		eno = ProAsmcompconstraintTypeGet (constr_array [i], &type);
		
		ProSelection asm_constr;
		ProDatumside dtmside;
		eno = ProAsmcompconstraintAsmreferenceGet (constr_array [i], &asm_constr, &dtmside);

		ProSelection comp_constr;
		eno = ProAsmcompconstraintCompreferenceGet(constr_array [i], &comp_constr, &dtmside);

		eno = PRO_TK_NO_ERROR;
	}

	ProArrayFree ((ProArray*)&constr_array);


	return err;
}

ProError TvCsysDataGet()
{
	ProError err = PRO_TK_NO_ERROR;

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("csys", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err ) return err;

	ProModelitem model_item;
	err = ProSelectionModelitemGet(pSels[0], &model_item);
	if( err ) return err;

	ProCsys p_csys;
	err = ProCsysInit( (ProSolid) model_item.owner, model_item.id, &p_csys);
	if( err ) return err;

	ProGeomitemdata *geomdata;
	err = ProCsysDataGet(p_csys, &geomdata);
	if( err ) return err;	

	err = ProGeomitemdataFree(&geomdata);

	return err;
}

ProError TvCsysAxisGetAngle()
{
	ProError err = PRO_TK_NO_ERROR;

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("edge", 2, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err ) return err;

	double result = 0.0;
	err = ProGeomitemAngleEval(pSels[0], pSels[1], &result);
	if( err ) return err;

	ProLine msg;
	swprintf_s(msg, L"angle is %g", result);
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg);

	return err;
}

ProError UITest()
{
	ProError err = PRO_TK_NO_ERROR;

	int num_sels;
	char** selnames;
	err = ProUITreeSelectednamesGet("main_dlg_cur", "PHTLeft.AssyTree", &num_sels, &selnames);
	if (err) return err;

	err = ProStringarrayFree (selnames, num_sels);
	if (err) return err;

	return err;
}

// Timer to check if confuguration is ready
static VOID CALLBACK WatchTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	CString msg;

	ProMdl mdl;
	ProError err = ProMdlCurrentGet(&mdl);
	if (err) return;

	ProSolid solid;
	err = ProMfgSolidGet((ProMfg)mdl, &solid);
	if (err) return;

	TvSolid Solid(solid);
	err = Solid.Initialize();
	if (err) return;
	
	TvFeatureList Feats;
	err = Solid.GetFeatures(PRO_FEAT_MILL, Feats);
	if (err) return;

	if (Feats.empty())
	{
		/////////////////////////
		msg.Format(L"Loop %03d: no PRO_FEAT_MILL found", m_TimerCounter);
		ProMessageClear();
		err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
		if (err) return;

		m_TimerCounter ++;
		return;
	}

	TvFeature* pFeat = Feats[0];

	err = pFeat->Initialize();
	if (err) return;

	// make name
	ProPath path;
	err = ProDirectoryCurrentGet(path);
	if (err) return;

	CString pathname;
	pathname.Format(L"%s%s_%03d.xml", path, pFeat->GetName(), m_TimerCounter);

	// Write XML
	err = pFeat->WriteToXML(pathname);
	if (err) return;
 
	/////////////////////////
	msg.Format(L"write feature information of %s successfully to XML file: %s", pFeat->GetName(), pathname);
	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
	if (err) return;

	m_TimerCounter ++;
}

static VOID CALLBACK UpdateFeatureTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	CString msg;

	ProMdl mdl;
	ProError err = ProMdlCurrentGet(&mdl);
	if (err) return;

	ProSolid solid;
	err = ProMfgSolidGet((ProMfg)mdl, &solid);
	if (err) return;

	TvSolid Solid(solid);
	err = Solid.Initialize();
	if (err) return;
	
	TvFeatureList Feats;
	err = Solid.GetFeatures(PRO_FEAT_MILL, Feats);
	if (err) return;

	if (Feats.empty())
	{
		/////////////////////////
		msg.Format(L"Loop %03d: no PRO_FEAT_MILL found", m_TimerCounter);
		ProMessageClear();
		err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
		if (err) return;

		m_TimerCounter ++;
		return;
	}

	TvFeature* pFeat = Feats[0];

	err = pFeat->Initialize();
	if (err) return;

	// make name
	ProPath path;
	err = ProDirectoryCurrentGet(path);
	if (err) return;

	CString pathname;
	pathname.Format(L"%s%s_%03d.xml", path, pFeat->GetName(), m_TimerCounter);

	// Write XML
	err = pFeat->WriteToXML(pathname);
	if (err) return;
 
	/////////////////////////
	msg.Format(L"write feature information of %s successfully to XML file: %s", pFeat->GetName(), pathname);
	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
	if (err) return;

	// update thie feature with name
	err = pFeat->SetName(L"NewName");
	if (err)
	{
		msg.Format(L"SetName failed");
		ProMessageClear();
		err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
		SetWatchTimer(false);
		return;
	}
	else
	{
		msg.Format(L"SetName succeed");
		ProMessageClear();
		err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", msg.GetBuffer());
		SetWatchTimer(false);
		return;
	}

	SetWatchTimer(false);
}

void SetWatchTimer(BOOL enable)
{
	if (enable)
	{
		if (m_TimerId == 0)
			m_TimerId = SetTimer(NULL, 0, m_TimerInterval, UpdateFeatureTimerProc);
	}
	else
	{
		if (m_TimerId != 0)
		{
			KillTimer(NULL, m_TimerId);
			m_TimerId = 0;
		}
	}
}

ProError CheckATBFeats(void)
{
	TvMdl * pMdl = new TvMdl();
	ProError err = pMdl->InitializeCurrent();
	if (err) return err;

	delete pMdl;

	return PRO_TK_NO_ERROR;
}