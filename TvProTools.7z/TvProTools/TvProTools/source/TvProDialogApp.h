#pragma once
#include <TvProDllApp.h>
#include <ProToolkitDll.h>

class TvProDialogApp : public TvProDllApp
{
public:
	TvProDialogApp(void);
	~TvProDialogApp(void);

	bool Initialize(void);
	bool Run(void);

	//bool AddHole();
	bool OnListClick(char *dialog, char *component, ProAppData data);
	bool OnListMouseover(char *dialog, char *component, ProAppData data);
	bool OnInputpanelInput(char *dialog, char *component, ProAppData data);
	bool OnPushbuttonClick(char *dialog, char *component, ProAppData data);
	void OnCancel(char *dialog);
	void OnOK(char *dialog);

protected:
	ProCharName m_szUIDlgName;
	ProCharName m_szUITextDlgName;
	ProCharName m_szUIDrwAreaName1;
	ProCharName m_szUIDrwAreaName2;
	ProCharName m_szUIDrwAreaName3;
	ProCharName m_szUIDrwAreaName4;
	ProCharName m_szUIListName;
	ProCharName m_szUITextAreaName;

	double m_AreaTotal;
	double m_Weight;
	double m_AreaHoles;
	double m_AreaCrossfeed;
	double m_AreaFixed;
	ProCollection m_Collection;
	int m_CurrentListPos;

protected:
	bool InitializeUI();
	bool InitializeDefaults();
	bool InitializeCrossfeeds();
	bool ExtractCollectionSurfaces();
	bool UpdateList(bool SaveSelection=false);
	bool HighlightListItem(int nItem, bool highlight);
	bool UpdateArea();
	void ResetUI();
	ProError ShowDialog(CString &text);
	void UpdateLength();
};