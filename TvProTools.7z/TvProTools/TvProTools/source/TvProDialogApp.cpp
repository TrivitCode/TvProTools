#include "stdafx.h"

#include <ProUIDialog.h>
#include <ProUIPushbutton.h>
#include <ProUIDrawingarea.h>
#include <ProUILabel.h>
#include <ProUIInputpanel.h>
#include <ProUIList.h>
#include <ProUITextarea.h>
#include <ProSrfcollection.h>
#include <TvMath.h>

#include "TvProDialogApp.h"

//////////////////////////////////////////////
//
TvProDialogApp::TvProDialogApp()
{
	strcpy_s(m_szUIDlgName, "TvGalvsurfaceGUI");
	strcpy_s(m_szUIDrwAreaName1, "DrawingArea1");
	strcpy_s(m_szUIDrwAreaName2, "DrawingArea2");
	strcpy_s(m_szUIDrwAreaName3, "DrawingArea3");
	strcpy_s(m_szUIDrwAreaName4, "DrawingArea4");
	strcpy_s(m_szUIListName, "List1");
	strcpy_s(m_szUITextDlgName, "TvProTools");
	strcpy_s(m_szUITextAreaName, "TvGalvsurfaceTextArea");

	m_AreaTotal = 0.0;
	m_AreaHoles = 0.0;
	m_AreaCrossfeed = 0.0;
	m_AreaFixed = 0.0;
	m_Collection = NULL;
	m_CurrentListPos = -1;
	m_Weight = 0.0;
}

TvProDialogApp::~TvProDialogApp()
{
}

bool TvProDialogApp::Initialize(void)
{
	if (!TvProDllApp::Initialize())
		return false;

	return true;
}

bool TvProDialogApp::InitializeUI()
{
	ProError err = ProUIDialogCreate(m_szUIDlgName, m_szUIDlgName);
	if (err)
	{
		LogProErr(L"ProUIDialogCreate", err);
		return false;
	}

	// set close action
	err = ProUIDialogCloseActionSet(m_szUIDlgName, (ProUIAction)TvGalvSurfaceDialogCloseAction, NULL);
	if (err)
	{
		LogProErr(L"ProUIDialogCloseActionSet", err);
		return false;
	}

	err = ProUIDialogStartlocationSet(m_szUIDlgName, PROUITOP_RIGHT);
	if (err)
	{
		LogProErr(L"ProUIDialogStartlocationSet", err);
		return false;
	}

	int pos_x_null = 12;
	int pos_y_label_null = 12, pos_y_inputpanel_null=10, pos_y_button_null=10;
	int offset_y = 27;
	
	
	///////////////////////////////////////////////////////////////////////
	// DrawingArea1
	//
	//
	int OffsetInputpanel1 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel1", 161);
	int LengthInputpanel1 = m_pOptions->GetInt(L"UI", L"LengthInputpanel1", 10);
	//

	// line1
	// add component: Label1
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Label1");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label1", pos_x_null, pos_y_label_null);
	err = ProUILabelTextSet(m_szUIDlgName, "Label1", GetTextMsg("TV_MENU_GALV_TOTAL_SURFACE").GetBuffer());

	// add component: Inputpanel1
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Inputpanel1");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel1", OffsetInputpanel1, pos_y_inputpanel_null);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel1", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel1", LengthInputpanel1);
	err = ProUIInputpanelInputActionSet(m_szUIDlgName, "Inputpanel1", (ProUIAction)TvGalvSurfaceInputpanelInputAction, NULL);

	// add component: PushButton1
	int OffsetPushButton1 = m_pOptions->GetInt(L"UI", L"OffsetPushButton1", 294);
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName1, "PushButton1");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton1", OffsetPushButton1, pos_y_button_null);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton1", L"Fix...");
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton1", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// line2: 1_5
	// add component: Label1_5
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Label1_5");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label1_5", 90, pos_y_label_null+offset_y/*39*/);
	err = ProUILabelTextSet(m_szUIDlgName, "Label1_5", GetTextMsg("TV_MENU_GALV_WEIGHT").GetBuffer());

	// add component: Inputpanel1_5
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Inputpanel1_5");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel1_5", OffsetInputpanel1, pos_y_inputpanel_null+offset_y);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel1_5", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel1_5", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel1_5");

	// line3 -> moved from line 4
	// add component: Label4
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Label4");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label4", pos_x_null, pos_y_label_null+offset_y*2);
	err = ProUILabelTextSet(m_szUIDlgName, "Label4", GetTextMsg("TV_MENU_GALV_EFFECTIVE_SURF").GetBuffer());

	//
	int OffsetInputpanel4 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel4", 236);
	int LengthInputpanel4 = m_pOptions->GetInt(L"UI", L"LengthInputpanel4", 10);
	//
	// add component: Inputpanel4
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Inputpanel4");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel4", OffsetInputpanel4, pos_y_inputpanel_null+offset_y*2);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel4", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel4", LengthInputpanel4);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel4");

	///////////////////////////////////////////////////////////////////////
	// DrawingArea4
	//
	// line4: moved from line 2
	// add component: Label2
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Label2");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label2", pos_x_null, pos_y_label_null);
	err = ProUILabelTextSet(m_szUIDlgName, "Label2", GetTextMsg("TV_MENU_GALV_HOLE_SURF").GetBuffer());

	// add component: Inputpanel2
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Inputpanel2");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel2", OffsetInputpanel1, pos_y_inputpanel_null);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel2", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel2", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel2");

	// line5: moved from line 3
	// add component: Label3
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Label3");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label3", 102, pos_y_label_null+offset_y);
	err = ProUILabelTextSet(m_szUIDlgName, "Label3", GetTextMsg("TV_MENU_GALV_REF").GetBuffer());

	// add component: Inputpanel3
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Inputpanel3");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel3", OffsetInputpanel1, pos_y_inputpanel_null+offset_y);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel3", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel3", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel3");

	// add component: PushButton3
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName4, "PushButton3");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton3", OffsetPushButton1, pos_y_button_null+offset_y);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton3", GetTextMsg("TV_MENU_GALV_SELECT").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton3", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// line5: moved from line3_5
	// add component: Label3_5
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Label3_5");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label3_5", 73, pos_y_label_null+offset_y*2);
	err = ProUILabelTextSet(m_szUIDlgName, "Label3_5", GetTextMsg("TV_MENU_GALV_ADJ").GetBuffer());

	// add component: Inputpanel3_5
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Inputpanel3_5");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel3_5", OffsetInputpanel1, pos_y_inputpanel_null+offset_y*2);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel3_5", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel3_5", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel3_5");

	///////////////////////////////////////////////////////////////////////
	// DrawingArea2
	//
	// line5
	// add component: Label5
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label5");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label5", pos_x_null, 12);
	err = ProUILabelSizeSet(m_szUIDlgName, "Label5", 200, 24);
	err = ProUILabelTextSet(m_szUIDlgName, "Label5", GetTextMsg("TV_MENU_GALV_BORE_HOLES").GetBuffer());

	// line6 left
	int WidthList1 = m_pOptions->GetInt(L"UI", L"WidthList1", 194);
	// add component: List1
	err = ProUIDrawingareaListAdd(m_szUIDlgName, m_szUIDrwAreaName2, m_szUIListName);
	err = ProUIListPositionSet(m_szUIDlgName, m_szUIListName, pos_x_null, 30);
	err = ProUIListSizeSet(m_szUIDlgName, m_szUIListName, WidthList1, 102);
	err = ProUIListSelectActionSet(m_szUIDlgName, m_szUIListName, (ProUIAction)TvGalvSurfaceListClickAction, NULL);
	err = ProUIListTriggerhighlightActionSet(m_szUIDlgName, m_szUIListName, (ProUIAction)TvGalvSurfaceListMouseoverAction, NULL);

	// line6 right
	//
	int OffsetInputpanel6 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel6", 218);
	int LengthInputpanel6 = m_pOptions->GetInt(L"UI", L"LengthInputpanel6", 5);

	// add component: Label6
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label6");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label6", OffsetInputpanel6, 30);
	err = ProUILabelTextSet(m_szUIDlgName, "Label6", GetTextMsg("TV_MENU_GALV_DIAMETER").GetBuffer());

	// add component: Inputpanel6
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel6");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel6", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel6", OffsetInputpanel6, 48);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel6", LengthInputpanel6);
	err = ProUIInputpanelInputActionSet(m_szUIDlgName, "Inputpanel6", (ProUIAction)TvGalvSurfaceInputpanelInputAction, NULL);

	// add component: PushButton6
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName2, "PushButton6");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton6", OffsetPushButton1, 48);
	err = ProUIPushbuttonSizeSet(m_szUIDlgName, "PushButton6", 24, 24);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton6", GetTextMsg("TV_MENU_GALV_SELECT").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton6", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// line7
	// add component: Label7
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label7");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label7", OffsetInputpanel6, 76);
	err = ProUILabelTextSet(m_szUIDlgName, "Label7", GetTextMsg("TV_MENU_GALV_INTERSPERSION").GetBuffer());

	// add component: Inputpanel7
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel7");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel7", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel7", OffsetInputpanel6, 94);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel7", LengthInputpanel6);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel7");

	// line8
	// add component: Label8
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label8");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label8", OffsetInputpanel6, 122);
	err = ProUILabelTextSet(m_szUIDlgName, "Label8", GetTextMsg("TV_MENU_GALV_COMP_LEN").GetBuffer());

	// add component: Inputpanel8
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel8");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel8", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel8", OffsetInputpanel6, 140);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel8", LengthInputpanel6);
	err = ProUIInputpanelInputActionSet(m_szUIDlgName, "Inputpanel8", (ProUIAction)TvGalvSurfaceInputpanelInputAction, NULL);
	//err = ProUIInputpanelBackgroundcolorSet(m_szUIDlgName, "Inputpanel8", PRO_UI_COLOR_RED);

	// add component: Label8_1
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label8_1");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label8_1", OffsetPushButton1, 143);
	err = ProUILabelTextSet(m_szUIDlgName, "Label8_1", GetTextMsg("TV_MENU_GALV_CHECK_DIMENSION").GetBuffer());

	// line9
	// add component: Label9
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label9");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label9", pos_x_null, 143);
	err = ProUILabelTextSet(m_szUIDlgName, "Label9", GetTextMsg("TV_MENU_GALV_INTERSP_SURF").GetBuffer());

	//
	int OffsetInputpanel9 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel9", 124);
	int LengthInputpanel9 = m_pOptions->GetInt(L"UI", L"LengthInputpanel9", 5);

	// add component: Inputpanel9
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel9");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel9", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel9", OffsetInputpanel9, 140);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel9", LengthInputpanel9);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel9");

	///////////////////////////////////////////////////////////////////////
	// DrawingArea3
	//
	// line 10
	// add component: PushButton10_1
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName3, "PushButton10_1");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton10_1", 26, 12);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton10_1", L"OK");
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton10_1", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// add component: PushButton10_2
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName3, "PushButton10_2");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton10_2", 148, 12);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton10_2", GetTextMsg("TV_MENU_GALV_CANCEL").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton10_2", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// add component: PushButton10_3
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName3, "PushButton10_3");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton10_3", 270, 12);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton10_3", GetTextMsg("TV_MENU_GALV_RESET").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton10_3", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	return true;
}


bool TvProDialogApp::Run(void)
{
	// create dialog
	if (!InitializeUI())
	{
		LogErr(L"Initialize UI failed: %s", GetLastError());
		return false;
	}

	// initialze default values
	if (!InitializeDefaults())
	{
		LogErr(L"Initialize default values failed: %s", GetLastError());
		return false;
	}

	ProError err = ProUIDialogShow(m_szUIDlgName);
	if (err)
	{
		LogProErr(L"ProUIDialogShow", err);
		return false;
	}

	int status = 0;
	err = ProUIDialogActivate(m_szUIDlgName, &status);
	if (err)
	{
		LogProErr(L"ProUIDialogActivate", err);
		return false;
	}

	// clear
	err = ProUIDialogDestroy(m_szUIDlgName);
	if (err)
		LogProErr(L"ProUIDialogDestroy", err, CA2W(m_szUIDlgName));
	else
		LogMsg(L"Dialog %S destroyed", m_szUIDlgName);

	if (m_pSolid)
	{
		delete m_pSolid;
		m_pSolid = NULL;
	}

	if (m_Collection)
	{
		ProCollectionFree(&m_Collection);
		m_Collection = NULL;
	}

	return true;
}

bool TvProDialogApp::InitializeDefaults()
{
	// get total surface
	if (m_pSolid) delete m_pSolid;

	m_pSolid = new TvSolid();
	TvProApp::CopyPropertiesTo(m_pSolid);
	ProError err = m_pSolid->InitializeCurrent();
	if (err)
	{
		LogProErr(L"TvSolid::InitializeCurrent", err);
		return false;
	}
	m_AreaTotal = m_pSolid->GetSurfaceArea()/10000.0;
	m_AreaFixed = m_AreaTotal;
	m_Weight    = m_pSolid->GetWeight();

	// set 
	CString Value;
	Value.Format(L"%.5g", m_AreaTotal);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel1", Value.GetBuffer());
	Value.Format(L"%.5g", m_AreaFixed);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel4", Value.GetBuffer());
	Value.Format(L"%.5g", m_Weight);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel1_5", Value.GetBuffer());

	return true;
}

bool TvProDialogApp::SelectSurfaces()
{
	ProError err = PRO_TK_NO_ERROR;

	// hide main dialog
	ProUIDialogHide(m_szUIDlgName);
	// repaint window
	ProWindowRepaint(PRO_VALUE_UNUSED);

	// let user to select a surface as reference of hole surface
	ProCollection collection;
	if (m_Collection)
	{
		err = ProSrfcollectionCopy(m_Collection, &collection);
		if (err)
		{
			LogProErr(L"ProSrfcollectionAlloc", err);
			return false;
		}
	}
	else
	{
		err = ProSrfcollectionAlloc(&collection);
		if (err)
		{
			LogProErr(L"ProSrfcollectionAlloc", err);
			return false;
		}
	}

	// load a macro before this call
	if (!m_Collection)
		ProMacroLoad(L"~ Activate `srfSetCollDlg` `AddSet`;~ Activate `srfSetCollDlg` `PreviewSrfSetBtn` 1;");
	else
		ProMacroLoad(L"~ Select `srfSetCollDlg` `SurfaceSetsTbl` 2 `RuleBased_0` `number`;~ Activate `srfSetCollDlg` `PreviewSrfSetBtn` 1;");
	ProSelection *coll_sels = NULL; 
	int coll_sels_size = 0; 

	// call UI to collect surfaces
	ProCollectioninstrType coll_filters[] = {PRO_SURFCOLL_SEED_N_BND,PRO_SURFCOLL_DONT_MIX};
	err = ProSurfacesCollect (coll_filters, 2, (ProCollFilter)NULL, (ProAppData)NULL, collection, &coll_sels, &coll_sels_size);
	if (err)
	{
		LogProErr(L"ProSurfacesCollect", err);
		return false;
	}
	LogMsg(L"%d surfaces collected", coll_sels_size);

	//
	TvSurfaceList SurfaceList;

	// use selection to get total surface area
	double total_area = 0.0;
	LogMsg(L"extracting collected surfaces...");
	m_AppLevel++;
	for (int i=0; i<coll_sels_size; i++)
	{
		ProModelitem mi;
		err = ProSelectionModelitemGet(coll_sels[i], &mi);
		if (err)
		{
			LogProErr(L"ProSelectionModelitemGet", err);
			return false;
		}

		// high-light this surface
		ProColortype color = PRO_COLOR_EDGE_HIGHLIGHT;
		ProSelectionHighlight(coll_sels[i], color);
		//ProSelectionDisplay(coll_sels[i]);

		TvModelitem Item(mi);
		err = Item.Initialize();
		if (err)
		{
			LogProErr(L"TvModelitem::Initialize", err);
			return false;
		}

		LogMsg(L"Modelitem collected: %s (ID_%d, Type_%d)", Item.GetName(), Item.GetID(), Item.GetType());

		ProSurface surface;
		err = ProGeomitemToSurface(&mi, &surface);
		if (err)
		{
			LogProErr(L"ProGeomitemToSurface", err);
			continue;
		}

		double area = 0.0;
		err = ProSurfaceAreaEval(surface, &area);
		if (err)
		{
			LogProErr(L"ProSurfaceAreaEval", err);
			continue;
		}
		LogMsg(L"surface area: %g", area);

		TvSurface srf;
		TvProApp::CopyPropertiesTo(&srf);
		srf.SetDebug(false);
		srf.SetSurface(surface);
		if (srf.Initialize()==PRO_TK_NO_ERROR)
			SurfaceList.push_back(srf);

		total_area = total_area + area;
	}
	m_AppLevel--;
	err = ProSelectionarrayFree(coll_sels);
	if (err)
	{
		LogProErr(L"ProSelectionarrayFree", err);
		return false;
	}

	LogMsg(L"Total holes area: %g", total_area);
	total_area = total_area/10000.0;
	CString Area;
	Area.Format(L"%.5g", total_area);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel2", Area.GetBuffer());
	m_AreaHoles = total_area;

	CString Text;
	Text.Format(L"%d %s", coll_sels_size, GetTextMsg("TV_MENU_GALV_SURFACE"));
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel3", Text.GetBuffer());

	double area_fixed = m_AreaTotal - m_AreaHoles;
	Text.Format(L"%.5g", area_fixed);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel4", Text.GetBuffer());

	// copy this collection
	if (m_Collection)
		ProCollectionFree(&m_Collection);
	err = ProSrfcollectionCopy(collection, &m_Collection);
	if (err)
	{
		LogProErr(L"ProSrfcollectionCopy", err);
		return false;
	}

	err = ProCollectionFree(&collection);
	if (err)
	{
		LogProErr(L"ProCollectionFree", err);
		return false;
	}

	// extract hole front surface
	if (!ExtractCollectionSurfaces())
	{
		LogErr(L"extract hole front surfaces from collection failed");
		return false;
	}

	// calculate hole diameter of front surfaces
	if (!CalculateFontSurfaceDiameters(&SurfaceList))
	{
		LogErr(L"calculate hole diameter of front surfaces failed");
		return false;
	}

	// calculate length of holes
	if (!UpdateDiameters())
		LogErr(L"calculate hole length failed");

	// update hole list
	if (!UpdateList())
	{
		LogErr(L"update hole list failed");
		return false;
	}

	// calculate fix and result
	if (!UpdateArea())
	{
		LogErr(L"calculate fixed area failed");
		return false;
	}

	// show main dialog
	ProUIDialogShow(m_szUIDlgName);

	LogMsg(L"Retrieve Hole Surfaces done!");
	return true;
}

bool TvProDialogApp::ExtractCollectionSurfaces()
{
	ProError err;

	if (m_Collection == NULL)
	{
		LogErr(L"m_Collection is null");
		return false;
	}

	// use collection to get front surface as reference for holes
	ProSrfcollinstr*  pInstrs = NULL;
	err = ProSrfcollectionInstructionsGet(m_Collection, &pInstrs);
	if (err)
	{
		LogProErr(L"ProSrfcollectionInstructionsGet", err);
		return false;
	}

	int nInstrs = 0;
	err = ProArraySizeGet(pInstrs, &nInstrs);
	if (err)
	{
		LogProErr(L"ProArraySizeGet", err);
		return false;
	}

	LogMsg(L"%d collection instructions retrieved, extraction collection information...", nInstrs);

	// clear hole list
	m_Holes.clear();

	m_AppLevel++;
	for (int i=0; i<nInstrs; i++)
	{
		ProSrfcollinstrType type;
		err = ProSrfcollinstrTypeGet(pInstrs[i], &type);
		if (err)
		{
			LogProErr(L"ProSrfcollinstrTypeGet", err);
			return false;
		}

		/*
		typedef enum pro_coll_instr_type
		{
		PRO_SURFCOLL_SINGLE_SURF      = 1,
		PRO_SURFCOLL_SEED_N_BND       = 2,
		PRO_SURFCOLL_QUILT_SRFS       = 3,
		PRO_SURFCOLL_ALL_SOLID_SRFS   = 4,
		PRO_SURFCOLL_NEIGHBOR         = 5,
		PRO_SURFCOLL_NEIGHBOR_INC     = 6,
		PRO_SURFCOLL_ALL_QUILT_SRFS   = 7,  Not supported for use in the surface collection UI, or in feature element trees.
		PRO_SURFCOLL_ALL_MODEL_SRFS   = 8,  Not supported for use in the surface collection UI,	or in feature element trees.
		PRO_SURFCOLL_LOGOBJ_SRFS      = 9,  
		PRO_SURFCOLL_DTM_PLN          = 10, Not supported for use in the surface collection UI, or in feature element trees.
		-- surface collection behaviors:
		PRO_SURFCOLL_DISALLOW_QLT       = 11,
		PRO_SURFCOLL_DISALLOW_SLD       = 12,
		PRO_SURFCOLL_DONT_MIX           = 13,
		PRO_SURFCOLL_SAME_SRF_LST       = 14,
		PRO_SURFCOLL_USE_BACKUP         = 15,
		PRO_SURFCOLL_DONT_BACKUP        = 16,
		PRO_SURFCOLL_DISALLOW_LOBJ      = 17,
		PRO_SURFCOLL_ALLOW_DTM_PLN      = 18,
		PRO_SURFCOLL_SEED_N_BND_INC_BND = 19,
		PRO_SURFCOLL_QUERY              = 20,
		PRO_SURFCOLL_ALLOW_QUERY        = 21, 

		PRO_SURFCOLL_GEOM_RULE          = 23,
		PRO_SURFCOLL_TANG_SRF           = 24,
		PRO_SURFCOLL_SHAPE_BASED        = 25,

		PRO_CURVCOLL_ONE_BY_ONE       = 101,
		PRO_CURVCOLL_TAN_CHAIN        = 102,
		PRO_CURVCOLL_CURVE_CHAIN      = 103,
		PRO_CURVCOLL_BNDRY_CHAIN      = 104,
		PRO_CURVCOLL_SURF_CHAIN       = 105,
		PRO_CURVCOLL_LOG_EDGE         = 106,
		PRO_CURVCOLL_ALL_EDGES        = 107,
		PRO_CURVCOLL_CONVEX_EDGES     = 108,
		PRO_CURVCOLL_CONCAVE_EDGES    = 109
		} ProCollectioninstrType;
		typedef enum pro_coll_instr_type ProSrfcollinstrType;
		*/
		LogMsg(L"Collection instruction %d: type=%d", i, type);

		if (type != PRO_SURFCOLL_SEED_N_BND)
			continue;

		ProSrfcollref* pInstrRefs = NULL; 
		err = ProSrfcollinstrReferencesGet(pInstrs[i], &pInstrRefs);
		if (err)
		{
			LogProErr(L"ProSrfcollinstrReferencesGet", err);
			return false;
		}

		int nInstrRefs = 0;
		err = ProArraySizeGet(pInstrRefs, &nInstrRefs);
		if (err)
		{
			LogProErr(L"ProArraySizeGet", err);
			return false;
		}

		LogMsg(L"%d instruction references retrieved, extracting instruction reference...", nInstrRefs);
		m_AppLevel++;
		for (int j=0; j<nInstrRefs; j++)
		{
			ProSrfcollrefType ref_type;
			err = ProSrfcollrefTypeGet(pInstrRefs[j], &ref_type);
			if (err)
			{
				LogProErr(L"ProSrfcollrefTypeGet", err);
				return false;
			}

			/*
			typedef enum pro_coll_ref_type
			{
			PRO_SURFCOLL_REF_SINGLE        = 1,
			PRO_SURFCOLL_REF_SINGLE_EDGE   = 2,
			PRO_SURFCOLL_REF_SEED          = 3,
			PRO_SURFCOLL_REF_BND           = 4,
			PRO_SURFCOLL_REF_SEED_EDGE     = 5,
			PRO_SURFCOLL_REF_NEIGHBOR      = 6,
			PRO_SURFCOLL_REF_NEIGHBOR_EDGE = 7,
			PRO_SURFCOLL_REF_GENERIC       = 8,

			PRO_CURVCOLL_REF_EDGE          = 101,
			PRO_CURVCOLL_REF_ALL           = 102,
			PRO_CURVCOLL_REF_FROM_TO       = 103,
			PRO_CURVCOLL_REF_FROM_TO_FLIP  = 104,
			PRO_CURVCOLL_REF_FROM          = 105,
			PRO_CURVCOLL_REF_TO            = 106
			} ProCollectionrefType;
			typedef enum pro_coll_ref_type ProSrfcollrefType;
			*/
			LogMsg(L"Instruction reference %d: type=%d", j, ref_type);

			if (ref_type != PRO_SURFCOLL_REF_BND)
				continue;

			// get reference
			ProReference ref;
			err = ProSrfcollrefItemGet(pInstrRefs[j], &ref);
			if (err)
			{
				LogProErr(L"ProSrfcollrefItemGet", err);
				return false;
			}

			LogMsg(L"retrieving hole front surface from Reference...");
			m_AppLevel++;
			if (!AddReferenceAsHoleFrontSurface(ref))
			{
				m_AppLevel++;
				LogErr(L"retrieving hole front surface from Reference failed");
			}
			m_AppLevel++;
			LogMsg(L"retrieving hole front surface from Reference...Done");
				
			err = ProReferenceFree(ref);
			if (err)
			{
				LogProErr(L"ProReferenceFree", err);
				return false;
			}
			LogMsg(L"Instruction reference %d retrieved", j);
		}
		m_AppLevel--;

		err = ProSrfcollrefArrayFree(pInstrRefs);
		if (err)
		{
			LogProErr(L"ProSrfcollrefArrayFree", err);
			return false;
		}
		LogMsg(L"Collection instruction %d retrieved", i);
	}

	m_AppLevel--;
	err = ProSrfcollinstrArrayFree(pInstrs);
	if (err)
	{
		LogProErr(L"ProSrfcollinstrArrayFree", err);
		return false;
	}

	return true;
}

bool TvProDialogApp::AddReferenceAsHoleFrontSurface(ProReference ref)
{
	ProError err;
	TvHoleItem item;
	TvProApp::CopyPropertiesTo(&item);
	item.SetAppLevel(m_AppLevel+1);

	ProSelection sel;
	err = ProReferenceToSelection(ref, &sel);
	if (err)
	{
		LogProErr(L"ProReferenceToSelection", err);
		return false;
	}
	item.SetSelection(sel);

	ProModelitem mi;
	err = ProSelectionModelitemGet(sel, &mi);
	if (err)
	{
		LogProErr(L"ProSelectionModelitemGet", err);
		return false;
	}

	// get surface
	ProSurface surface;
	err = ProGeomitemToSurface(&mi, &surface);
	if (err)
	{
		LogProErr(L"ProGeomitemToSurface", err);
		return false;
	}

	item.SetFrontSurface(m_pSolid->GetSolid(), surface);	
	if (!item.Initialize())
	{
		LogErr(L"Initialize TvHoleItem failed: %s", item.GetLastError());
		return false;
	}
	m_Holes.push_back(item);
	
	LogMsg(L"ItemText=%s", item.GetSurfaceName());
	
	// end
	err = ProSelectionFree(&sel);
	if (err)
	{
		LogProErr(L"ProSelectionFree", err);
		return false;
	}

	return true;
}

bool TvProDialogApp::UpdateList(bool SaveSelection)
{
	ProError err;
	int nums = (int) m_Holes.size();

	char **names, **images;
	wchar_t **labels;

	err = ProArrayAlloc(nums, sizeof(char *), 1, (ProArray *)&names);
	if (err)
	{
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	err = ProArrayAlloc(nums, sizeof(char *), 1, (ProArray *)&images);
	if (err)
	{
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	err = ProArrayAlloc(nums, sizeof(wchar_t *), 1, (ProArray *)&labels);
	if (err)
	{
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	for (int i=0; i<nums; i++)
	{
		names[i] = (char*) calloc(PRO_LINE_SIZE, sizeof(char));
		sprintf_s(names[i], PRO_LINE_SIZE, "%d", m_Holes[i].GetSurfaceID());

		images[i] = (char*) calloc(PRO_LINE_SIZE, sizeof(char));
		if (m_Holes[i].GetLength()<m_Holes[i].GetCrossfeed())
			strcpy_s(images[i], PRO_LINE_SIZE, "miss_data.gif");
		else
			strcpy_s(images[i], PRO_LINE_SIZE, "");

		labels[i] = (wchar_t*) calloc(PRO_LINE_SIZE, sizeof(wchar_t));
		wcscpy_s(labels[i], PRO_LINE_SIZE, m_Holes[i].GetSurfaceName());
	}

	err = ProUIListNamesSet(m_szUIDlgName, m_szUIListName, nums, (char**)names);
	if (err)
	{
		LogProErr(L"ProUIListNamesSet", err);
		return false;
	}

	err = ProUIListLabelsSet(m_szUIDlgName, m_szUIListName, nums, (wchar_t**)labels);
	if (err)
	{
		LogProErr(L"ProUIListLabelsSet", err);
		return false;
	}

	err = ProUIListItemimageSet(m_szUIDlgName, m_szUIListName, nums, images);
	if (err)
	{
		LogProErr(L"ProUIListItemimageSet", err);
		return false;
	}

	for (int i=0; i<nums; i++)
	{
		free(names[i]);
		free(labels[i]);
	}

	ProArrayFree((ProArray *)&names);
	ProArrayFree((ProArray *)&labels);

	err = ProUIListSelectionpolicySet(m_szUIDlgName, m_szUIListName, PROUISELPOLICY_SINGLE);
	if (err)
	{
		LogProErr(L"ProUIListSelectionpolicySet", err);
		return false;
	}

	if (m_CurrentListPos>=0)
	{
		char **sel_names;
		ProArrayAlloc(1, sizeof(char *), 1, (ProArray *)&sel_names);
		sel_names[0] = (char*) calloc(PRO_LINE_SIZE, sizeof(char));
		sprintf_s(sel_names[0], PRO_LINE_SIZE, "%d", m_Holes[m_CurrentListPos].GetSurfaceID());
		ProUIListSelectednamesSet(m_szUIDlgName, m_szUIListName, 1, sel_names);
		free(sel_names[0]);
		ProArrayFree((ProArray *)&sel_names);
	}

	return true;
}

bool TvProDialogApp::OnListClick(char *dialog, char *component, ProAppData data)
{
	ProError err;

	// get selected item text
	int nSels=0;
	char **pSels;
	err = ProUIListSelectednamesGet(dialog, component, &nSels, &pSels);
	if (err)
	{
		LogProErr(L"ProUIListSelectednamesGet", err);
		return false;
	}

	if (nSels==0)
	{
		HighlightListItem(-1, false);
		m_CurrentListPos = -1;
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel6", L"");
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel7", L"");
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel8", L"");
		err = ProUIInputpanelBackgroundcolorSet(m_szUIDlgName, "Inputpanel8", PRO_UI_COLOR_WHITE);
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", L"");
		return false;
	}

	ProLine sel;
	ProStringToWstring(sel, pSels[0]);
	int srf_id = _wtoi(sel);

	err = ProStringarrayFree(pSels, nSels);
	if (err)
	{
		LogProErr(L"ProStringarrayFree", err);
		return false;
	}

	for (size_t i=0;i<m_Holes.size(); i++)
	{
		if (m_Holes[i].GetSurfaceID() != srf_id)
		{
			HighlightListItem((int)i, false);
			continue;
		}
		
		HighlightListItem((int)i, true);
		m_CurrentListPos = (int)i;

		CString value;
		
		// display diameter
		value.Format(L"%.5g", m_Holes[i].GetDiameter());
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel6", value.GetBuffer());

		// display crossfeed
		value.Format(L"%.5g", m_Holes[i].GetCrossfeed());
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel7", value.GetBuffer());

		// display length
		value.Format(L"%.5g", m_Holes[i].GetLength());
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel8", value.GetBuffer());

		// display cross area
		value.Format(L"%.5g", m_Holes[i].GetCrossArea()/10000.0);
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", value.GetBuffer());

		UpdateLength();
	}

	return true;
}

bool TvProDialogApp::OnListMouseover(char *dialog, char *component, ProAppData data)
{
	// this function can do nothing

	//LogMsg(L"mouse over: dialog=%S, component=%S", dialog, component);
	return true;
}

bool TvProDialogApp::HighlightListItem(int nItem, bool highlight)
{
	ProError err;

	for (size_t i=0; i<m_Holes.size(); i++)
	{
		if (nItem>=0)
		{
			if (i != nItem)
				continue;
		}

		// highlight/unhighlight this surface
		ProModelitem mi;
		err = ProModelitemInit(m_pSolid->GetMdl(), m_Holes[i].GetSurfaceID(), PRO_SURFACE, &mi);
		if (err)
		{
			LogProErr(L"ProModelitemInit", err);
			return false;
		}

		ProSelection sel;
		err = ProSelectionAlloc(NULL, &mi, &sel);
		if (err)
		{
			LogProErr(L"ProSelectionAlloc", err);
			return false;
		}

		if (nItem == -1)
		{
			err = ProSelectionUnhighlight(sel);
			if (err)
			{
				LogProErr(L"ProSelectionUnhighlight", err);
				return false;
			}
		}
		else
		{
			if (highlight)
			{
				//err = ProSelectionHighlight(sel, PRO_COLOR_HIGHLITE);
				err = ProSelectionDisplay(sel);
				if (err)
				{
					LogProErr(L"ProSelectionHighlight", err);
					return false;
				}
			}
			else
			{
				err = ProSelectionUnhighlight(sel);
				if (err)
				{
					LogProErr(L"ProSelectionUnhighlight", err);
					return false;
				}
			}

		}

		err = ProSelectionFree(&sel);
		if (err)
		{
			LogProErr(L"ProSelectionFree", err);
			return false;
		}
	}

	return true;
}

bool TvProDialogApp::InitializeCrossfeeds()
{
	CStringArray items;
	m_pOptions->GetKeyNames(L"Crossfeeds", &items);

	if (items.IsEmpty())
	{
		LogErr(L"Crossfeeds not defined in %s", m_pOptions->GetPathName());
		return false;
	}

	for (INT_PTR i=0; i<items.GetCount(); i++)
	{
		CString name = items[i];
		CString value = m_pOptions->GetString(L"Crossfeeds", name);
		
		TvCrossfeed cf;
		cf.m_Diameter = _wtof(name);
		cf.m_Crossfeed = _wtof(value);
		m_Crossfeeds.push_back(cf);
	}
	LogMsg(L"%d crossfeeds defined", m_Crossfeeds.size());

	return true;
}

bool TvProDialogApp::UpdateArea()
{
	ProError err;
	m_AreaCrossfeed = 0.0;
	double total_cross_feed=0.0, total_length=0.0;
	for (size_t i=0; i<m_Holes.size(); i++)
	{
		m_AreaCrossfeed += m_Holes[i].GetCrossArea();
		total_cross_feed+= m_Holes[i].GetCrossfeed();
		total_length    += m_Holes[i].GetLength();
	}
	m_AreaCrossfeed = m_AreaCrossfeed/10000.0;

	// Fix: if total cross feed >= total length
	if ((total_cross_feed-total_length)>=0.00000001)
		m_AreaCrossfeed = m_AreaHoles;
	
	LogMsg(L"Total fix area: %g", m_AreaCrossfeed);
	
	CString value;
	if (m_AreaCrossfeed>0.00000001)
	{
		value.Format(L"%.5g", m_AreaCrossfeed);
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel3_5", value.GetBuffer());
	}
	else
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel3_5", L"");

	if (m_AreaCrossfeed>=m_AreaHoles)
		m_AreaFixed = m_AreaTotal;
	else
		m_AreaFixed = m_AreaTotal - m_AreaHoles + m_AreaCrossfeed;

	value.Format(L"%.5g", m_AreaFixed);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel4", value.GetBuffer());

	return true;
}

bool TvProDialogApp::OnInputpanelInput(char *dialog, char *component, ProAppData data)
{
	ProError err;

	CString comp(component);
	LogMsg(L"Input event from Inputpanel %s", comp);

	wchar_t* value;
	err = ProUIInputpanelWidestringGet(dialog, component, &value);
	if (err)
	{
		LogProErr(L"ProUIInputpanelWidestringGet", err);
		return false;
	}
	CString Value(value);
	ProWstringFree(value);
	
	if (comp.CompareNoCase(L"Inputpanel1")==0) // this is for the total surface area
	{
		m_AreaTotal = _wtof(Value);
	}
	else if (comp.CompareNoCase(L"Inputpanel6")==0) // this is for hole diameter
	{
		if (m_CurrentListPos>=0)
		{
			m_Holes[m_CurrentListPos].SetDiameter(_wtof(Value));
			m_Holes[m_CurrentListPos].SetCrossfeed(m_Crossfeeds.GetCrossfeed(m_Holes[m_CurrentListPos].GetDiameter()));
			double CrossFeed = m_Holes[m_CurrentListPos].GetCrossfeed();
			double HoleLength = m_Holes[m_CurrentListPos].GetLength();
			// update cross feed
			Value.Format(L"%.5g", CrossFeed);
			err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel7", Value.GetBuffer());

			// update cross area
			Value.Format(L"%.5g", m_Holes[m_CurrentListPos].GetCrossArea()/10000.0);
			err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", Value.GetBuffer());

			// update UI
			UpdateLength();
			UpdateList();
		}
	}
	else if (comp.CompareNoCase(L"Inputpanel8")==0) // this is for hole length
	{
		if (m_CurrentListPos>=0)
		{
			m_Holes[m_CurrentListPos].SetLength(_wtof(Value));
			// display cross area
			Value.Format(L"%.5g", m_Holes[m_CurrentListPos].GetCrossArea()/10000.0);
			err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", Value.GetBuffer());

			// update UI
			UpdateLength();
			UpdateList();
		}
	}

	if (!UpdateArea())
		LogErr(L"Update area faield");

	return true;
}

bool TvProDialogApp::OnPushbuttonClick(char *dialog, char *component, ProAppData data)
{
	ProError err;

	CString comp(component);
	LogMsg(L"Click event from Pushbutton %s", comp);

	if (comp.CompareNoCase(L"PushButton1")==0)	// this is to call TvGewindeFlaeche
	{
		double fixed_total_area;
		if (!FixTotalArea(&fixed_total_area))
		{
			LogErr(L"Fix total area failed");
		}
		m_AreaTotal = fixed_total_area;
		CString Value;
		Value.Format(L"%.5g", m_AreaTotal);
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel1", Value.GetBuffer());
	}
	else if (comp.CompareNoCase(L"PushButton3")==0)	// this is to select surfaces
	{
		SelectSurfaces();
	}
	else if (comp.CompareNoCase(L"PushButton6")==0)		// this is to select diameter (dimension)
	{
		if (m_CurrentListPos<0)
			return false;

		double dim = SelectDiameter();
		if (dim>0.00000001)
		{
			if (m_CurrentListPos>=0)
			{
				m_Holes[m_CurrentListPos].SetDiameter(dim);
				m_Holes[m_CurrentListPos].SetCrossfeed(m_Crossfeeds.GetCrossfeed(m_Holes[m_CurrentListPos].GetDiameter()));
				CString Value;
				// update diameter
				Value.Format(L"%.5g", m_Holes[m_CurrentListPos].GetDiameter());
				err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel6", Value.GetBuffer());
				// update cross feed
				Value.Format(L"%.5g", m_Holes[m_CurrentListPos].GetCrossfeed());
				err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel7", Value.GetBuffer());
				// update cross area
				Value.Format(L"%.5g", m_Holes[m_CurrentListPos].GetCrossArea()/10000.0);
				err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", Value.GetBuffer());

				UpdateLength();
				UpdateList();
			}
		}
	}
	else if (comp.CompareNoCase(L"PushButton10_1")==0)	// Button OK: save/update parameter, close dialog
	{
		OnOK(dialog);
	}
	else if (comp.CompareNoCase(L"PushButton10_2")==0)	// Button Abbrechen: close dialog
	{
		OnCancel(dialog);
	}
	else if (comp.CompareNoCase(L"PushButton10_3")==0)	// Button Zur�cksetzen: re-initialize default values
	{
		ProWindowRepaint(PRO_VALUE_UNUSED);
		ResetUI();
	}
	else if (comp.CompareNoCase(L"OK")==0)	// Button OK: close all
	{
		ProWindowRepaint(PRO_VALUE_UNUSED);
		ProUIDialogExit(dialog, PRO_TK_CONTINUE);
	}

	if (!UpdateArea())
		LogErr(L"Update area faield");

	return true;
}

void TvProDialogApp::OnCancel(char *dialog)
{
	if (strcmp(dialog, m_szUIDlgName)==0)
		ProWindowRepaint(PRO_VALUE_UNUSED);
	ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
}

void TvProDialogApp::OnOK(char *dialog)
{
	CString text = L"", line, ParamValue, varText, varTextID;

	// set parameter of galvanish surface area
	CString ParamName = m_pOptions->GetString(L"DEFAULT", L"ParameterGalvName");
	CString ParamForm = m_pOptions->GetString(L"DEFAULT", L"ParameterGalvFormat", L"%g");
	if (ParamName.IsEmpty())
		LogMsg(L"[DEFAULT]ParameterGalvName not defined");
	else	// save m_AreaFixed to parameter
	{
		ParamValue.Format(ParamForm, m_AreaFixed);
		ParamValue.Replace(L".", L",");
		m_pSolid->SetParameter(ParamName, ParamValue, true);
	}

	varTextID.Format(L"%s_GALV_EFFEC_SURF", m_Language);
	varText = m_pOptions->GetString(L"Translates", varTextID, L"", false);
	varText.Replace(L"\\n", L"\n");
	line.Format(varText, ParamName, ParamValue);
	text += line;

	// set parameter of total surface
	ParamName = m_pOptions->GetString(L"DEFAULT", L"ParameterTotalName");
	ParamForm = m_pOptions->GetString(L"DEFAULT", L"ParameterTotalFormat", L"%g");
	if (ParamName.IsEmpty())
		LogMsg(L"[DEFAULT]ParameterTotalName not defined");
	else	// save m_AreaFixed to parameter
	{
		ParamValue.Format(ParamForm, m_AreaTotal);
		ParamValue.Replace(L".", L",");
		m_pSolid->SetParameter(ParamName, ParamValue, true);
	}

	varTextID.Format(L"%s_GALV_TOTAL_SURF", m_Language);
	varText = m_pOptions->GetString(L"Translates", varTextID, L"", false);
	varText.Replace(L"\\n", L"\n");
	line.Format(varText, ParamName, ParamValue);
	text += line;
	
	// set parameter of weight
	ParamName = m_pOptions->GetString(L"DEFAULT", L"ParameterWeightName");
	ParamForm = m_pOptions->GetString(L"DEFAULT", L"ParameterWeightFormat", L"%g");
	if (ParamName.IsEmpty())
		LogMsg(L"[DEFAULT]ParameterWeightName not defined");
	else	// save m_AreaFixed to parameter
	{
		ParamValue.Format(ParamForm, m_Weight);
		ParamValue.Replace(L".", L",");
		m_pSolid->SetParameter(ParamName, ParamValue, true);
	}

	varTextID.Format(L"%s_GALV_WEIGHT", m_Language);
	varText = m_pOptions->GetString(L"Translates", varTextID, L"", false);
	varText.Replace(L"\\n", L"\n");
	line.Format(varText, ParamName, ParamValue);
	text += line;

	ShowDialog(text);
}

ProError TvProDialogApp::ShowDialog(CString &text)
{
	ProError err = PRO_TK_NO_ERROR;

	// create a info window to display results
	err = ProUIDialogCreate(m_szUITextDlgName, m_szUITextDlgName);
	if (err) return err;

	// set close action
	err = ProUIDialogCloseActionSet(m_szUITextDlgName, (ProUIAction) TvGalvSurfaceDialogCloseAction, NULL);
	if (err) return err;

	if (text.GetLength() > 32)
	{
		err = ProUITextareaMaxlenSet(m_szUITextDlgName, m_szUITextAreaName, (int)text.GetLength());
		if (err) return err;
	}
	
	err = ProUITextareaValueSet(m_szUITextDlgName, m_szUITextAreaName, text.GetBuffer());
	if (err) return err;

	text.ReleaseBuffer();

	err = ProUIPushbuttonActivateActionSet(m_szUITextDlgName, "OK", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);
	err = ProUIPushbuttonActivateActionSet(m_szUITextDlgName, "Cancel", (ProUIAction)TvGalvSurfaceDialogCloseAction, NULL);

	int status = 0;
	err = ProUIDialogActivate(m_szUITextDlgName, &status);
	if (err) return err;

	err = ProUIDialogDestroy(m_szUITextDlgName);
	if (err) return err;

	if (status == PRO_TK_CONTINUE)
		ProUIDialogExit(m_szUIDlgName, PRO_TK_NO_ERROR);

	return PRO_TK_NO_ERROR;
}

double TvProDialogApp::SelectDiameter()
{
	ProError err;
	double ret = 0.0;

	ProSelection* pSels = NULL;
	int nSels = 0;
	err = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if (err)
	{
		LogProErr(L"ProSelect", err);
		return ret;
	}
	err = ProSelectionUnhighlight (pSels[0]);

	if (nSels != 1)
		return ret;

	err = ProGeomitemDiameterEval(pSels[0], &ret);
	if (err)
	{
		LogProErr(L"ProGeomitemDiameterEval", err);
		return ret;
	}

	LogMsg(L"Diameter selected: %g", ret);

	return ret;
}

bool TvProDialogApp::UpdateDiameters()
{
	for (size_t i=0; i<m_Holes.size(); i++)
	{
		ProSelection sel1 = m_Holes[i].GetSelection();
		for (size_t j=0; j<m_Holes.size(); j++)
		{
			if (i==j)
				continue;

			ProSelection sel2 = m_Holes[j].GetSelection();
			double distance = 0.0;
			ProError err = ProGeomitemDistanceEval(sel1, sel2, &distance);
			if (err)
			{
				LogProErr(L"ProSelectionDistanceEval", err);
				continue;
			}
			if (distance>0.0)
			{
				m_Holes[i].SetLength(distance/2.0);
				m_Holes[j].SetLength(distance/2.0);
				LogMsg(L"distance between hole %d(ID_%d) and %d(ID_%d) calculated: %g", i, m_Holes[i].GetSurfaceID(), j, m_Holes[j].GetSurfaceID(), distance);

				m_Holes[i].SetPairID(m_Holes[j].GetSurfaceID());
				m_Holes[j].SetPairID(m_Holes[i].GetSurfaceID());
			}
		}
	}

	if (m_Holes.size() == 2)
	{
		if (m_Holes[0].GetPairID()==0)
		{
			ProVector ct1, ct2, dir1, dir2;
			m_Holes[0].GetCenter(ct1);
			m_Holes[0].GetDirection(dir1);
			m_Holes[1].GetCenter(ct2);
			m_Holes[1].GetDirection(dir2);

			ProVector p1, p2;
			if (TvUtils::TvLinesIntersect2(ct1, dir1, ct2, dir2, p1, p2))
			{
				double distance = TvUtils::TvPointsDist(ct1, p1);
				m_Holes[0].SetLength(distance);

				distance = TvUtils::TvPointsDist(ct2, p2);
				m_Holes[1].SetLength(distance);
			}
			else
			{
				double distance = TvUtils::TvPointsDist(ct1, ct2);

				m_Holes[0].SetLength(distance/2.0);
				m_Holes[1].SetLength(distance/2.0);
			}

			LogMsg(L"length of hole 0(ID_%d) calculated: %f", m_Holes[0].GetSurfaceID(), m_Holes[0].GetLength());
			LogMsg(L"length of hole 1(ID_%d) calculated: %f", m_Holes[1].GetSurfaceID(), m_Holes[1].GetLength());
		}
	}

	if (m_Holes.size() == 3)
	{
		for (size_t i=0; i<m_Holes.size();i++)
		{
			if (m_Holes[i].GetLength()>0.00000001)
				continue;

			size_t j,k;
			switch (i)
			{
			case 0:
				j=1;
				k=2;
				break;
			case 1:
				j=0;
				k=2;
				break;
			case 2:
				j=0;
				k=1;
				break;
			default:
				break;
			}

			ProVector center1, center2, center3;
			m_Holes[i].GetCenter(center1);
			m_Holes[j].GetCenter(center2);
			m_Holes[k].GetCenter(center3);
			double length = TvUtils::TvPointLineDist(center1, center2, center3);
			LogMsg(L"length of hole %d(ID_%d) calculated from hole %d(ID_%d) and %d(ID_%d): %f", 
				i, m_Holes[i].GetSurfaceID(), j, m_Holes[j].GetSurfaceID(), k, m_Holes[k].GetSurfaceID(), length);
			m_Holes[i].SetLength(length);
		}
	}

	return true;
}

void TvProDialogApp::ResetUI()
{
	ProError err;

	// re-initialize current model
	InitializeDefaults();

	// reset Holes area
	m_AreaHoles = 0.0;
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel2", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel3", L"");
	if (m_Collection)
	{
		ProCollectionFree(&m_Collection);
		m_Collection = NULL;
	}

	// reset hole information
	m_Holes.clear();
	UpdateList();
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel6", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel7", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel8", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", L"");

	m_AreaCrossfeed = 0.0;
	m_CurrentListPos = -1;
}

bool TvProDialogApp::FixTotalArea(double* pArea)
{
	ProError err;

	CString AppPath = m_pOptions->GetString(L"DEFAULT", L"PathTvGewindeflaeche");
	if (AppPath.IsEmpty())
	{
		LogErr(L"[DEFAULT]PathTvGewindeflaeche not defined");
		return false;
	}

	// load this dll
	ProName app_name = L"TvGewindeflaeche";
	ProCharPath exec_file;
	sprintf_s(exec_file, PRO_PATH_SIZE, "%S\\x86e_win64\\TvGewindeFlaeche.dll", AppPath); 

	ProCharPath text_dir;
	strcpy_s(text_dir, PRO_PATH_SIZE, CW2A(AppPath));

	ProToolkitDllHandle handle;
	ProError user_err = PRO_TK_NO_ERROR;
	ProPath user_str = L"";
	err = ProToolkitDllLoad(app_name, exec_file, text_dir, PRO_B_TRUE, &handle, &user_err, user_str);
	if (err)
	{
		LogProErr(L"ProToolkitDllLoad", err);
		return false;
	}

	if (user_err!=PRO_TK_NO_ERROR)
	{
		LogErr(L"Load dll(%s) failed: %s", exec_file, user_str);
		return false;
	}
	LogMsg(L"%S loaded", exec_file);

	/////////////////////////////////////////////////////////////////////////////////
	// call open csv file proc
	ProArgument* p_inputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &p_inputs);
	if (err)
	{
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	ProArgument* p_outputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &p_outputs);
	if (err)
	{
		ProArgumentProarrayFree(&p_inputs);
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	// hide main dialog
	err = ProUIDialogHide(m_szUIDlgName);
	if (err) return false;

	err = ProToolkitTaskExecute(handle, "GetFixedTotalArea", p_inputs, &p_outputs, &user_err);
	if (err)
	{
		LogProErr(L"ProToolkitTaskExecute", err, L"GetFixedTotalArea");
		ProArgumentProarrayFree(&p_inputs);
		ProArgumentProarrayFree(&p_outputs);
		ProUIDialogShow(m_szUIDlgName);
		return false;
	}

	ProUIDialogShow(m_szUIDlgName);

	// extract fixed area from argument
	int n_values = 0;
	err = ProArraySizeGet(p_outputs, &n_values);
	if (err) return FALSE;

	if (n_values == 1)
	{
		ProValueData value_data;
		err = ProArgumentByLabelGet(p_outputs, L"AREA_FIXED", &value_data);
		if (err)
		{
			LogErr(L"Argument \"AREA_FIXED\" not found");
			return FALSE;
		}

		if (value_data.type != PRO_VALUE_TYPE_DOUBLE)
			return FALSE;

		(*pArea) = value_data.v.d/10000.0;
		LogMsg(L"Fixed area: %g", value_data.v.d);
	}

	// free memory
	err = ProArgumentProarrayFree(&p_inputs);
	if (err) return FALSE;

	err = ProArgumentProarrayFree(&p_outputs);
	if (err) return FALSE;
	
	LogMsg(L"RunPproc GetFixedTotalArea succeed");
	/////////////////////////////////////////////////////////////////////////////////

	// unload dll
	err = ProToolkitDllUnload(handle);
	if (err)
	{
		LogProErr(L"ProToolkitDllUnload", err);
		return false;
	}
	LogMsg(L"%S unloaded", exec_file);

	return true;
}

bool TvProDialogApp::CalculateFontSurfaceDiameters(TvSurfaceList* pSrfs)
{
	ProError err = PRO_TK_NO_ERROR;

	for (size_t i=0; i<m_Holes.size(); i++)
	{
		TvContourList* pContours = m_Holes[i].GetSurface()->GetContours();
		Pro3dPnt center;
		bool bFoundCenter=false;
		for (size_t j=0; j<pContours->size(); j++)
		{
			TvEdgeList* pEdges = pContours->at(j).GetEdges();
			for (size_t k=0; k<pEdges->size(); k++)
			{
				TvEdge edge1, edge2;
				TvSurface srf1, srf2;
				if (pEdges->at(k).GetNeighbors(&edge1, &edge2, &srf1, &srf2) == PRO_TK_NO_ERROR)
				{
					bool bFound=false;
					INT_PTR pos = pSrfs->Find(srf1.GetID());
					if (pos>=0)
					{
						LogMsg(L"Srf1(ID_%d) found", srf1.GetID());
						bFound=true;
					}
					pos = pSrfs->Find(srf2.GetID());
					if (pos>=0)
					{
						LogMsg(L"Srf2(ID_%d) found", srf2.GetID());
						bFound=true;
					}

					if (bFound)
					{
						double diam = pEdges->at(k).GetDiameter();
						if (diam>0.00000001)
						{
							m_Holes[i].SetDiameter(diam);
							m_Holes[i].SetCrossfeed(m_Crossfeeds.GetCrossfeed(diam));
						}

						// save center
						pEdges->at(k).GetCenter(center);
						bFoundCenter = true;
					}
				}
			}
		}

		if (bFoundCenter)
		{
			LogMsg(L"Hole %d found center: %g,%g,%g", i, center[0],center[1],center[2]);

			m_Holes[i].SetCenter(center);
			ProSurface srf = m_Holes[i].GetSurface()->GetSurface();
			ProUvParam uv_pnt;
			err = ProSurfaceParamEval(m_pSolid->GetSolid(), srf, center, uv_pnt);
			if (err == PRO_TK_NO_ERROR)
			{
				ProVector dir;
				err = ProSurfaceXyzdataEval(srf, uv_pnt, NULL, NULL, NULL, dir);
				if (err == PRO_TK_NO_ERROR)
				{
					LogMsg(L"Hole %d direction at center: %g,%g,%g", i, dir[0],dir[1],dir[2]);
				}
				m_Holes[i].SetDirection(dir);
			}
		}
	}

	return true;
}

void TvProDialogApp::UpdateLength()
{
	// check hole length and crossfeed length, and modify UI:
	//  - change background color of input

	ProError err = PRO_TK_NO_ERROR;

	double CrossFeed = m_Holes[m_CurrentListPos].GetCrossfeed();
	double HoleLength = m_Holes[m_CurrentListPos].GetLength();

	if (CrossFeed<=HoleLength)	//
	{
		// update Inputpanel8
		ProUIInputpanelBackgroundcolorSet(m_szUIDlgName, "Inputpanel8", PRO_UI_COLOR_WHITE);
	}
	else
	{
		// update Inputpanel8
		ProUIInputpanelBackgroundcolorSet(m_szUIDlgName, "Inputpanel8", PRO_UI_COLOR_RED);
	}
}