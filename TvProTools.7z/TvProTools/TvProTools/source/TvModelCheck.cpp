/*====================================================================*\
FILE    :  UgModelCheck.c
PURPOSE :  Example that demonstrates implementation of ModelCheck custom
           checks.

NOTES   :  The checks coded in this file work with the ModelCheck config files 
           stored in pt_userguide/text/modelcheck.  Your ModelCheck config
           must include these configuration changes in order to see the 
           custom checks in the report.

HISTORY..
DATE       BUILD      AUTHOR    MODIFICATIONS
11-May-05  K-03-27     JCN     $$1   Created.
\*====================================================================*/

#include "stdafx.h"

#include <ProToolkit.h>
#include <ProMdlChk.h>
#include <ProMessage.h>
#include <ProParameter.h>
#include <ProSolid.h>
#include <ProDrawing.h>
#include <ProFamtable.h>
#include <ProGraphic.h>
#include <ProSelection.h>
#include <ProScope.h>
#include <ProWindows.h>
#include <ProDrawing.h>
#include <ProDtlsyminst.h>

#include <TvUtils.h>
#include <TvIniFile.h>
using namespace TvUtils;

#include "TvModelCheck.h"

static wchar_t** s_results_table = NULL;
static wchar_t*  s_results_url = NULL;

static ProFileName MSG_FILE = L"tvprotools_msg.txt";

/*======================================================================================================*\
FUNCTION: UserCustCheckCleanUtility
PURPOSE:  Cleanup function for all of the ModelCheck checks. 
\*======================================================================================================*/
ProError UserCustCheckCleanUtility (ProCharName name, ProMdl mdl, ProAppData appdata)
{
	int size, i;
	ProError err = PRO_TK_NO_ERROR;

	if (s_results_table !=  NULL)
	{
		err = ProArraySizeGet (s_results_table, &size);

		if (err == PRO_TK_NO_ERROR)
		{
			for (i = 0; i < size; i++)
				free (s_results_table [i]);

			err = ProArrayFree ((ProArray*)&s_results_table);
			if (err) return err;
		}
		s_results_table = NULL;
	}

	if (s_results_url != NULL)
	{
		free (s_results_url);
		s_results_url = NULL;
	}

	return err;
}


ProError TvCollectMTUFSymbol(ProDrawing drawing, ProDtlsyminst **ppSymbols, int *pnSymbols)
{
	ProError err = PRO_TK_NO_ERROR;

	// collect all symbols in drawing in all sheets
	int nSheets = 0;
	err = ProDrawingSheetsCount(drawing, &nSheets );
	if( err ) return err;

	ProDtlsyminst *pSymbols = NULL;
	err = ProArrayAlloc(0, sizeof(ProDtlsyminst), 1, (ProArray*)&pSymbols);
	if( err )
		return err;

	for( int i=0; i< nSheets; i++ )
	{
		ProDtlsyminst *pSheetSymbols = NULL;
		err = ProDrawingDtlsyminstsCollect( drawing, i+1, &pSheetSymbols );
		if( err != PRO_TK_NO_ERROR )
			continue;

		int nSheetSymbols = 0;
		err = ProArraySizeGet( (ProArray) pSheetSymbols, &nSheetSymbols );
		if( err )
			return err;

		if( nSheetSymbols > 0 )
		{
			err = ProArrayObjectAdd( (ProArray*)&pSymbols, -1, nSheetSymbols, pSheetSymbols );
			if( err )
				return err;

			err = ProArrayFree( (ProArray*) &pSheetSymbols );
			if( err )
				return err;
		}
	}

	// get count
	int nSymbols = 0;
	err = ProArraySizeGet( (ProArray) pSymbols, &nSymbols);
	if (err) return err;

	if (nSymbols>0)
	{
		*pnSymbols = nSymbols;
		*ppSymbols = pSymbols;
	}

	return err;
}


// Check if MTU UDF exists
ProError TvCustCheckUdfExistsProc(ProCharName name, ProMdl mdl, ProAppData appdata, 
								  int* results_count, wchar_t** results_url, wchar_t*** results_table)
{
	ProError err = PRO_TK_NO_ERROR;

	// Output the symbol list.
	ProDtlsyminst *pSymbols = NULL;
	err = ProDrawingDtlsyminstsCollect( (ProDrawing)mdl, PRO_VALUE_UNUSED, &pSymbols);
	if (err) return err;
	
	int nSymbols = 0;
	err = ProArraySizeGet(pSymbols, &nSymbols);
	if (err) return err;

	/******************************************************************/
	CString path;
	if (!TvGetModulePath(L"TvProTools.dll", path))
		return PRO_TK_E_NOT_FOUND;
	
	path += L"\\syscfg\\mtuf2.ini";
	TvIniFile ini;
	ini.SetPath(string(CW2A(path)));
	if (!ini.ReadFile())
		return PRO_TK_BAD_CONTEXT;

	// get [udfs to search]
	long udf_pos = ini.FindKey("udfs to search");
	if (udf_pos < 0)
		return PRO_TK_BAD_CONTEXT;

	CStringList mtuf_symbols;
	for (unsigned int i=0; i<ini.GetNumValues(udf_pos); i++)
		mtuf_symbols.AddTail(CA2W(ini.GetValueName(udf_pos, i).data()));
	/******************************************************************/

	// make name list, the list MUST not habe same name
	CStringList names;
	for (int i=0; i<nSymbols; i++)
	{
		// get symbol instance data
		ProDtlsyminstdata symInstData;
		err = ProDtlsyminstDataGet( &pSymbols[i], PRODISPMODE_NUMERIC, &symInstData );
		if( err ) return err;

		// get symbol definition
		ProDtlsymdef symDef;
		err = ProDtlsyminstdataDefGet( symInstData, &symDef );
		if( err ) return err;

		// get symbol definition data
		ProDtlsymdefdata symDefdata;
		err = ProDtlsymdefDataGet(&symDef, &symDefdata);
		if (err) return err;

		// get name of this definition data
		ProName wszName;
		err = ProDtlsymdefdataNameGet(symDefdata, wszName);
		if (err) return err;

		err = ProDtlsymdefdataFree(symDefdata);
		if (err) return err;

		err = ProDtlsyminstdataFree(symInstData);
		if (err) return err;

		// check if name exists
		CString name(wszName);
		if ( mtuf_symbols.Find(name) == NULL )
			continue;

		CString id;
		id.Format(L"%d", pSymbols[i].id);

		// add name
		names.AddTail(id);
	}

	// free symbol list
	err = ProArrayFree( (ProArray*) &pSymbols);
	if (err) return err;
	pSymbols = NULL;

	if (!names.IsEmpty())
	{
		int size = (int)names.GetCount();
		err = ProArrayAlloc(size, sizeof(ProWstring), 1, (ProArray*)&s_results_table);		
		if (err) return err;

		POSITION pos = names.GetHeadPosition();
		int i=0;
		while (pos)
		{
			s_results_table [i] = (wchar_t*) calloc (PRO_NAME_SIZE, sizeof (wchar_t));

			CString name = names.GetNext(pos);

			ProName wszName;
			wcscpy_s(wszName, PRO_NAME_SIZE, name.GetBuffer());
			ProWstringCopy (wszName, s_results_table[i], PRO_VALUE_UNUSED);
			i++;
		}

		*results_table = s_results_table;
		*results_count = size;
		*results_url = NULL;

		
	}
	else
	{
		*results_table = NULL;
		*results_count = 0;
		*results_url = NULL;
	}

	return PRO_TK_NO_ERROR;
}

ProError TvCustCheckUdfHighlightProc(ProCharName name, ProMdl mdl, wchar_t* selected_item, 
 									 ProAppData appdata)
{
	//ProFileName message_file;
	ProError err = PRO_TK_NO_ERROR;

	ProName id;
	wcscpy_s(id, PRO_NAME_SIZE, selected_item);

	ProDtlsyminst symbol;
	symbol.id = _wtoi(id);
	symbol.owner = mdl;
	symbol.type = PRO_SYMBOL_INSTANCE;

	ProSelection sel;
	err = ProSelectionAlloc(NULL, NULL, &sel);
	if (err) return err;

	err = ProSelectionSet(sel, NULL, &symbol);
	if (err) return err;

	err = ProSelectionHighlight(sel, PRO_COLOR_HIGHLITE);
	if (err) return err;

	//ProMessageDisplay(message_file, ""

	return PRO_TK_NO_ERROR;
}

ProError TvCustCheckUdfUpdateProc(ProCharName name, ProMdl mdl, wchar_t* selected_item, ProAppData appdata)
{

	return PRO_TK_NO_ERROR;
}


ProError TvUserCustomModelChecksDefine()
{
	ProFileName message_file;
	ProCharName model_check_name;
	ProLine check_label, action_label, update_label;
	static ProName param_name;
	ProError status;

	// message file
	ProStringToWstring (message_file, "mtu_modelcheck.txt");

	/* The name of the check. */
    strcpy_s(model_check_name, "CHKTK_MTUF_UDF_EXIST");
    
    /* The label for the check */
	status = ProMessageToBuffer (check_label, message_file, "MTU CustomCheck: MTUF SYMBOL EXISTS");

	// action label
	status = ProMessageToBuffer (action_label, message_file, "MTU CustomCheckAction: MTUF SYMBOL HIGHLIGHT");

	// update label
	status = ProMessageToBuffer (update_label, message_file, "MTU CustomUpdateAction: MTUF SYMBOL UPDATE");

	// Register the custom ModelCheck check (an info check, so no action or update is possible).
    status = ProModelcheckCheckRegister(model_check_name, check_label, NULL, 
										TvCustCheckUdfExistsProc, 
										UserCustCheckCleanUtility, 
										action_label, 
										TvCustCheckUdfHighlightProc,
										update_label, 
										TvCustCheckUdfUpdateProc, 
										NULL);


	if (status)
	{
		ProMessageClear();
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_REG_CUSTMCHK_ERROR", model_check_name, &status);
	}
	else
	{
		ProMessageClear();
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_REG_CUSTMCHK_SUCCESS", model_check_name);
	}

	return PRO_TK_NO_ERROR;
}
