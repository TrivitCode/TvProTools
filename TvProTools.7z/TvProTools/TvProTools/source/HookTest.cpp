#include "stdafx.h"

BOOL SetHook(void)
{




	return TRUE;
}