// TvProTools.cpp : Definiert die Initialisierungsroutinen f�r die DLL.
//

#include "stdafx.h"
#include <afxsock.h>

#include <vector>
using namespace std;

#include "TvProTools.h"

#include <TvProErrors.h>
#include <TvProTkUtils.h>
#include <TvMath.h>
#include <ProDtlentity.h>

#include <ProMdlChk.h>
#include <ProMdl.h>
#include <ProNcseq.h>

#include <ProToolkitDll.h>
#include <ProUITree.h>
#include <ProUtil.h>

#include <ProSecdim.h>
#include <ProSelbuffer.h>
#include <ProPiping.h>
#include <ProExtobj.h>

#include <curl.h>
//#include <json.h>


// from creo 1.0: prodevelop.h does not exists
//#if PRO_VER < 6000
// #include <prodevelop.h>
//#else if PRO_VER < 7000
// #include <select3d.h>
// #include <prodev_error.h>
//#endif
//
//#include <prodev_light.h>

#include <ProIntfimport.h>

#include "TvProUtils.h"
#include "TvHoleTableEx.h"
#include "TvProMfg.h"
#include "TvModelCheck.h"
#include "TvProUdf.h"
#include "TvProCable.h"
using namespace TvUtils;

//#include "excel.h"

#include "TvImportFeature.h"
#include "TvAssemblyTest.h"
#include "HookTest.h"

#include <TvFeature.h>
#include <TvSolid.h>

#if PRO_VER > 7000
#include <ProATB.h>
#endif

#include "TestToolGen.h"
#include "TvGalvSurfaceApp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

struct PushButton{
	char szCmdName[64];
	uiCmdCmdActFn fnFunction;
	ProMenuItemName ButtonName;
	ProMenuItemLabel ButtonLabel;
	ProMenuLineHelp Tooltip;
	uiCmdCmdId cmdId;
};

// variables:
static ProFileName MENU_FILE = L"tvprotools_menu.txt";

static const char VERSION[] = "3.0.0";

//static TvGalvSurfApp* g_pApp = NULL;

static UINT_PTR m_TimerId = 0;
static const int m_TimerInterval = 1000;

#ifdef _DEBUG  
CMemoryState oldMemState,newMemState,diffMemState;  
#endif

ProError TvTestProc1();
ProError TvTestProc2();
ProError TvTestProc3();
ProError TvWriteXMLProc();
ProError TvGetConstrProc();
ProError TvCsysGetDataProc();
ProError TvCsysAxisGetAngleProc();
ProError TvHoleTableExProc();
ProError TvMfgToolCollectProc();
ProError TvUdfAddProc();
ProError TvVartextFindProc();
ProError TvHighlightProc();
ProError TvParamCfgImportProc();
ProError TvGetTransMatrixProc();
ProError TvSetCommonNameProc();
ProError CopyBrowserData();
ProError TvNcNoteEditorProc();

//ProError TvGalvSurfaceProc();

////////////////////////////////////////////////////////////////////
// functions

BOOL IsUrlLoaded()
{
	int win_id = 0;
	ProError err = ProWindowCurrentGet(&win_id);
	if (err) return FALSE;

	ProWstring url = NULL;
	err = ProWindowURLGet(win_id, &url);
	if (err) return FALSE;

	if (url==NULL)
		return FALSE;

	CString Url(url);
	ProWstringFree(url);

	if (Url.Find(L"Awt.epm.EPMDocument")>=0)
		return TRUE;
	
	return FALSE;
}

//////////////////////////////////////////////////
// Timer to check if confuguration is ready
static VOID CALLBACK WatchTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	if (IsUrlLoaded())
	{
		CopyBrowserData();
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"CopyBrowserData done");
		KillTimer(NULL, m_TimerId);
		m_TimerId = 0;
	}
}

//
//TODO: Wenn diese DLL dynamisch mit MFC-DLLs verkn�pft ist,
//		muss f�r alle aus dieser DLL exportierten Funktionen, die in
//		MFC aufgerufen werden, das AFX_MANAGE_STATE-Makro
//		am Anfang der Funktion hinzugef�gt werden.
//
//		Beispiel:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// Hier normaler Funktionsrumpf
//		}
//
//		Es ist sehr wichtig, dass dieses Makro in jeder Funktion
//		vor allen MFC-Aufrufen angezeigt wird. Dies bedeutet,
//		dass es als erste Anweisung innerhalb der 
//		Funktion angezeigt werden muss, sogar vor jeglichen Deklarationen von Objektvariablen,
//		da ihre Konstruktoren Aufrufe in die MFC-DLL generieren
//		k�nnten.
//
//		Siehe Technische Hinweise f�r MFC 33 und 58 f�r weitere
//		Details.
//


// CTvProToolsApp

BEGIN_MESSAGE_MAP(CTvProToolsApp, CWinApp)
END_MESSAGE_MAP()


// CTvProToolsApp-Erstellung

CTvProToolsApp::CTvProToolsApp()
{
	// TODO: Hier Code zur Konstruktion einf�gen.
	// Alle wichtigen Initialisierungen in InitInstance positionieren.
}


// Das einzige CTvProToolsApp-Objekt

CTvProToolsApp theApp;


// CTvProToolsApp-Initialisierung

BOOL CTvProToolsApp::InitInstance()
{
	CWinApp::InitInstance();

	if(!AfxOleInit())  // Your addition starts here
	{
		AfxMessageBox(L"Could not initialize COM dll");
		return FALSE;
	}                 // End of your addition

	return TRUE;
}

// init
extern "C" int user_initialize(int argc,			/** Number of arguments		**/
							   char *argv[],		/** Pro/E arguments			**/
							   char *proe_vsn,		/** Pro/E version			**/
							   char *build,			/** Pro/E build				**/
							   wchar_t err_buff[])	/** Error buffer			**/
{
#ifdef _DEBUG  
	oldMemState.Checkpoint(); 
#endif 

	ProError err = PRO_TK_NO_ERROR;
	
	///////////////////////////////////////////////////////////////////
	// Add a menu to Pro/Engineer
	// add main menu "Toolbox"
	err = ProMenubarMenuAdd( "TvProTools", "TVPROTOOLS_MENU_MAIN", "Utilities", PRO_B_TRUE, MENU_FILE);
	if( err != PRO_TK_NO_ERROR )
	{
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "ProMenubarMenuAdd", TvProErrors[-err]);
		return err;
	}
	
	// add push button
	vector<PushButton> BtnList;

	PushButton pbWriteXML = {"TvWriteXMLProc", (uiCmdCmdActFn)TvWriteXMLProc, "tvprotools_write_xml", "TVPROTOOLS_MENU_WRITE_XML", "TVPROTOOLS_MENU_WRITE_XML_TOOLTIP"};
	BtnList.push_back(pbWriteXML);

	PushButton pbGetConstr = {"TvGetConstrProc", (uiCmdCmdActFn)TvGetConstrProc, "tvprotools_get_constr", "TVPROTOOLS_MENU_GET_CONSTR", "TVPROTOOLS_MENU_GET_CONSTR_TOOLTIP"};
	BtnList.push_back(pbGetConstr);

	PushButton pbCsysGetData = {"TvCsysGetDataProc", (uiCmdCmdActFn)TvCsysGetDataProc, "tvprotools_csys_get_data", "TVPROTOOLS_MENU_CSYS_GET_DATA", "TVPROTOOLS_MENU_CSYS_GET_DATA_TOOLTIP"};
	BtnList.push_back(pbCsysGetData);

	PushButton pbCsysAxisGetAngle = {"TvCsysAxisGetAngleProc", (uiCmdCmdActFn)TvCsysAxisGetAngleProc, "tvprotools_csys_axis_get_angle", "TVPROTOOLS_MENU_CSYS_AXIS_GET_ANGLE", "TVPROTOOLS_MENU_CSYS_AXIS_GET_ANGLE_TOOLTIP"};
	BtnList.push_back(pbCsysAxisGetAngle);

	PushButton pbHoleTableEx = {"TvHoleTableExProc", (uiCmdCmdActFn)TvHoleTableExProc, "tvprotools_table_hole_ex", "TVPROTOOLS_MENU_HOLE_TABLE_EX", "TVPROTOOLS_MENU_HOLE_TABLE_EX_TOOLTIP"};
	BtnList.push_back(pbHoleTableEx);

	PushButton pbMfgToolCollect = {"TvMfgToolCollectProc", (uiCmdCmdActFn)TvMfgToolCollectProc, "tvprotools_mfg_tool_collect", "TVPROTOOLS_MENU_TOOL_COLLECT", "TVPROTOOLS_MENU_TOOL_COLLECT_TOOLTIP"};
	BtnList.push_back(pbMfgToolCollect);

	//PushButton pbRotateComp = {"TvRotateCompProc", (uiCmdCmdActFn)TvRotateCompProc, "tvprotools_rotate_comp", "TVM_ROTATE_COMP", "TVM_ROTATE_COMP_TOOLTIP"};
	//BtnList.push_back(pbRotateComp);

//#ifndef WF2
//	PushButton pbRegisterCUSTMCHK = {"TvUserCustomModelChecksDefine", (uiCmdCmdActFn)TvUserCustomModelChecksDefine, "tvprotools_register_custmchk", "TVPROTOOLS_MENU_CUSTMCHK", "TVPROTOOLS_MENU_CUSTMCHK_TOOLTIP"};
//	BtnList.push_back(pbRegisterCUSTMCHK);
//#endif

#ifndef WF2
	PushButton pbUdfAdd = {"TvUdfAdd", (uiCmdCmdActFn)TvUdfAddProc, "tvprotools_udf_add", "TVPROTOOLS_MENU_UDF_ADD", "TVPROTOOLS_MENU_UDF_ADD_TOOLTIP"};
	BtnList.push_back(pbUdfAdd);
#endif

	// PROTOOLS_MENU_FIND_LONG_VARTEXT
	PushButton pbVartextFind = {"TvVartextFind", (uiCmdCmdActFn)TvVartextFindProc, "tvprotools_vartext_find", "TVPROTOOLS_MENU_VARTEXT_FIND", "TVPROTOOLS_MENU_VARTEXT_FIND_TOOLTIP"};
	BtnList.push_back(pbVartextFind);

	// TVPROTOOLS_MENU_EXPORT_PTD
#ifndef WF2
	PushButton pbUdfFamtblExport = {"TvUdfFamtblExport", (uiCmdCmdActFn)TvUdfFamtblExportProc, "tvprotools_udffamtbl_export", "TVPROTOOLS_MENU_EXPORT_PTD", "TVPROTOOLS_MENU_EXPORT_PTD_TOOLTIP"};
	BtnList.push_back(pbUdfFamtblExport);
#endif

	// TVPROTOOLS_MENU_IMPORT_PARAM
	PushButton pbParamCfgImport = {"TvParamCfgImport", (uiCmdCmdActFn)TvParamCfgImportProc, "tvprotools_param_import", "TVM_IMPORT_PARAM", "TVM_IMPORT_PARAM_TOOLTIP"};
	BtnList.push_back(pbParamCfgImport);

	// TVPROTOOLS_MENU_GET_MATRIX
	PushButton pbGetTransMatrix = {"TvGetTransMatrix", (uiCmdCmdActFn)TvGetTransMatrixProc, "tvprotools_get_trans_matrix", "TVPROTOOLS_MENU_GET_MATRIX", "TVPROTOOLS_MENU_GET_MATRIX_TOOLTIP"};
	BtnList.push_back(pbGetTransMatrix);

	// TVPROTOOLS_MENU_SET_COMMON_NAME
	PushButton pbSetCommonName = {"TvSetCommonName", (uiCmdCmdActFn)TvSetCommonNameProc, "tvprotools_set_common_name", "TVPROTOOLS_MENU_SET_COMMON_NAME", "TVPROTOOLS_MENU_SET_COMMON_NAME_TOOLTIP"};
	BtnList.push_back(pbSetCommonName);

//#ifdef PRO_DEBUG
	PushButton pbTest1 = {"TvTestProc1", (uiCmdCmdActFn)TvTestProc1, "tvprotools_test1", "TVPROTOOLS_MENU_TEST1", "TVPROTOOLS_MENU_TEST1_TOOLTIP"};
	BtnList.push_back(pbTest1);

	PushButton pbTest2 = {"TvTestProc2", (uiCmdCmdActFn)TvTestProc2, "tvprotools_test2", "TVPROTOOLS_MENU_TEST2", "TVPROTOOLS_MENU_TEST2_TOOLTIP"};
	BtnList.push_back(pbTest2);

	PushButton pbTest3 = {"TvTestProc3", (uiCmdCmdActFn)TvTestProc3, "tvprotools_test3", "TVPROTOOLS_MENU_TEST3", "TVPROTOOLS_MENU_TEST3_TOOLTIP"};
	BtnList.push_back(pbTest3);
//#endif

	for( size_t i=0; i< BtnList.size(); i++ )
	{
		PushButton pb = BtnList.at(i);
		err = ProCmdActionAdd(pb.szCmdName, pb.fnFunction, uiProe2ndImmediate, NULL, 
			PRO_B_TRUE, PRO_B_TRUE, & pb.cmdId);
		if( err != PRO_TK_NO_ERROR )
		{
			ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "ProCmdActionAdd", TvProErrors[-err]);
			return err;
		}

		err = ProMenubarmenuPushbuttonAdd("TvProTools", pb.ButtonName, pb.ButtonLabel, pb.Tooltip, 
			NULL, PRO_B_TRUE, pb.cmdId, MENU_FILE);
		if( err != PRO_TK_NO_ERROR )
		{
			CString msg;
			msg.Format(L"ProMenubarmenuPushbuttonAdd(%S)",pb.ButtonName);
			char buf[128];
			strcpy_s(buf, CW2A(msg));
			ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", buf, TvProErrors[-err]);
			return err;
		}
	}

	// Add NC-Note Editor
	uiCmdCmdId id_nc_note_editor;
	err = ProCmdActionAdd("TvNcNoteEditorProc", (uiCmdCmdActFn)TvNcNoteEditorProc, uiProe2ndImmediate, NULL, PRO_B_TRUE, PRO_B_TRUE, &id_nc_note_editor);
	if( err != PRO_TK_NO_ERROR )
	{
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "ProCmdActionAdd", TvProErrors[-err]);
		return err;
	}

	err = ProMenubarmenuPushbuttonAdd("Applications", "TvNcNoteEditor", "TVNCNOTE_MENU", "TVNCNOTE_MENU_TOOLTIP", NULL, PRO_B_TRUE, id_nc_note_editor, MENU_FILE);
	if( err != PRO_TK_NO_ERROR )
	{		
		CString msg = L"Can't add push button for NC Note Editor";
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", (char*)CW2A(msg), TvProErrors[-err]);
		return err;
	}

	// add a command: main command
	//uiCmdCmdId cmd_main;
	//err = ProCmdActionAdd("TvProToolsDlgProc", (uiCmdCmdActFn)TvGalvSurfaceProc, uiProe2ndImmediate, NULL, 
	//					  PRO_B_TRUE, PRO_B_TRUE, &cmd_main);
	//if( err != PRO_TK_NO_ERROR )
	//{
	//	ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "ProCmdActionAdd", TvUtils::TvProErrors[-err]);
	//	return err;
	//}

	//// designate command
	//err = ProCmdDesignate(cmd_main, "TVPROTOOLS_MENU_DIALOG", "TVPROTOOLS_MENU_DIALOG_TOOLTIP", "TVPROTOOLS_MENU_DIALOG_DESC", MENU_FILE);
	//if (err)
	//{
	//	ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "ProCmdDesignate", TvUtils::TvProErrors[-err]);
	//	return err;
	//}

	//err = ProCmdIconSet(cmd_main, "tvprotools.png");
	//if (err)
	//{
	//	ProMessageDisplay(MSG_FILE, "TVPROTOOLS_PROTK_ERR", "ProCmdIconSet", TvUtils::TvProErrors[-err]);
	//	return err;
	//}

	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	ProEngineerMultithreadModeEnable();

		// create app
	//g_pApp = new TvGalvSurfApp();
	//g_pApp->SetAppName(L"TvProTools");
	//g_pApp->SetAppVersion(CA2W(VERSION));
	//g_pApp->SetMsgFile(MSG_FILE);

	//if (!g_pApp->Initialize())
	//{
	//	ProMessageDisplay(MSG_FILE, "TV_APP_INIT_FAILED");
	//	delete g_pApp;
	//	g_pApp = NULL;
	//	return -1;
	//}

	///////////////////////////////////////////////////////////////////
	// End
	ProMessageDisplay(MSG_FILE, "TVPROTOOLS_INIT_SUCCESS", VERSION);

	return 0;
}

extern "C" void user_terminate()
{
	ProMessageDisplay(MSG_FILE, "TVPROTOOLS_EXIT");

	//delete g_pApp;
	//g_pApp = NULL;

#ifdef _DEBUG  
	newMemState.Checkpoint();  
	if(diffMemState.Difference(oldMemState,newMemState))  
		TRACE("Memory leak detected!\n");  
	else
		TRACE("No Memory leak detected!\n");
#endif 
}

//ProError TvGalvSurfaceProc()
//{
//	ProError err = PRO_TK_NO_ERROR;
//
//	/////////////////////////////////////////////////////////////////////
//	// run
//	g_pApp->Run();
//
//	return err;
//}

//////////////////////////////////////////////////////////////////////
// callbacks from dialog
// callback function for dialog
//void TvGalvSurfaceDialogCloseAction(char *dialog, char *component, ProAppData data)
//{
//	g_pApp->OnCancel(dialog);
//}
//
////void TvGalvSurfaceDialogAddHoleAction(char *dialog, char *component, ProAppData data)
////{
////	g_pApp->AddHole();
////}
//
//void TvGalvSurfaceListClickAction(char *dialog, char *component, ProAppData data)
//{
//	g_pApp->OnListClick(dialog, component, data);
//}
//
//void TvGalvSurfaceListMouseoverAction(char *dialog, char *component, ProAppData data)
//{
//	g_pApp->OnListMouseover(dialog, component, data);
//}
//
//void TvGalvSurfaceInputpanelInputAction(char *dialog, char *component, ProAppData data)
//{
//	g_pApp->OnInputpanelInput(dialog, component, data);
//}
//
//void TvGalvSurfacePushbuttonClickAction(char *dialog, char *component, ProAppData data)
//{
//	g_pApp->OnPushbuttonClick(dialog, component, data);
//}

ProError TvLoadProTkAppProc()
{
	ProError err = PRO_TK_NO_ERROR;

	// load dll: Lage-Automat.dll
	ProToolkitDllHandle hLAAU;
	ProError eno = PRO_TK_NO_ERROR;
	ProPath msg;
	err = ProToolkitDllLoad(L"Lage-Automat", 
							"D:\\Test\\Lage-Automat\\i486_nt\\Lage-Automat.dll", 
							"D:\\Test\\Lage-Automat\\text",
							PRO_B_TRUE,
							&hLAAU,
							&eno,
							msg);
	if (err) return err;

	ProArgument *inputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &inputs);
	if (err) return err;

	ProArgument in1;
	wcscpy_s(in1.label, PRO_NAME_SIZE, L"CSV_PATHNAME");
	err = ProValuedataWstringSet(&in1.value, L"D:\\Test\\Lage-Automat\\work\\testdaten_start\\test_lageautomat.csv");
	if (err) return err;

	err = ProArrayObjectAdd( (ProArray*) &inputs, -1, 1, &in1 );
	if (err) return err;

	ProArgument *outputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &outputs);
	if (err) return err;

	err = ProToolkitTaskExecute(hLAAU, "Lageautomat", inputs, &outputs, &eno);
	if (err) return err;

	// check outputs
	int nOutputs = 0;
	err = ProArraySizeGet( (ProArray) outputs, &nOutputs );
	if (err) return err;
	if (nOutputs == 2)
	{
		ProArgument out1;
		err = ProArgumentByLabelGet( outputs, L"CSV_PATHNAME", &out1.value);
		if (err) return err;

		ProArgument out2;
		err = ProArgumentByLabelGet( outputs, L"LOG_PATHNAME", &out2.value);
		if (err) return err;
	}

	// free memory
	err = ProArgumentProarrayFree( &inputs );

	err = ProArgumentProarrayFree( &outputs );

	err = ProToolkitDllUnload(hLAAU);
	if (err) return err;

	return err;
}

ProError TvRunModelCheckProc()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	int errors = 0;
	int warnings = 0;
	ProBoolean b_saved = PRO_B_FALSE;

	err = ProModelcheckExecute(mdl, PRO_B_TRUE, PRO_MODELCHECK_GRAPHICS, NULL, NULL, &errors, &warnings, &b_saved); 
	if (err) return err;

	return err;
}

static wchar_t** s_results_table = NULL;
static wchar_t*  s_results_url = NULL;

static ProError CheckSmallNameProc(ProCharName name, 
								   ProMdl mdl,
                                   ProAppData appdata,
								   int* results_count, 
                                   wchar_t** results_url, 
                                   wchar_t*** results_table)
{
	ProError err = PRO_TK_NO_ERROR;
	
	ProName mdl_name;
	err = ProMdlNameGet(mdl, mdl_name);
	if (err) return err;

	size_t len = wcslen(mdl_name);
	if (len > 12)
	{
		*results_count = 0;
		*results_url = NULL;
		*results_table = NULL;
	}
	else
	{
		ProLine error_msg;
		wcscpy_s( error_msg, PRO_LINE_SIZE, L"The name of current model is too small" );

		// make buffer
		err = ProArrayAlloc(1, sizeof(ProWstring), 1, (ProArray*)&s_results_table);
		s_results_table [0] = (wchar_t*) calloc (PRO_LINE_SIZE, sizeof (wchar_t));
		ProWstringCopy (error_msg, s_results_table[0], PRO_VALUE_UNUSED);

		/*--------------------------------------------------------------------*\
		This URL will be used for the "Check Details" link in the ModelCheck
		report.
		\*-------------------------------------------------------------------*/
		s_results_url = (wchar_t*) calloc (PRO_PATH_SIZE, sizeof (wchar_t));
		ProStringToWstring (s_results_url, "http://www.ptc.com/");
		*results_table = s_results_table;
		*results_count = 1;
		*results_url = s_results_url;
	}

	return err;
}

ProError TestSurfVisitProc(ProSurface p_surface, ProError status, ProAppData app_data)
{
	ProMdl mdl = (ProMdl) app_data;

	ProModelitem mi;
    ProError err = ProSurfaceToGeomitem((ProSolid)mdl, p_surface, (ProGeomitem*)&mi);
	if (err) return PRO_TK_NO_ERROR;

	//Pro_surf_props properties;
	//int ret = prodb_get_surface_props((Prohandle)mdl, SEL_3D_SRF, mi.id, 0, &properties);
	//if (ret != PRODEV_SURF_PROPS_SET)
	//	return PRO_TK_NO_ERROR;

	return PRO_TK_NO_ERROR;
}

ProError TvOpenExcelProc()
{
	ProError err = PRO_TK_NO_ERROR;

	//// open an Excel file
	//_Application app;  // app is the Excel _Application object

	//// Start Excel and get Application object...
	//if(!app.CreateDispatch(L"Excel.Application"))
	//{
	//	AfxMessageBox(L"Couldn't start Excel.");
	//}
	//else
	//{
	//	//Make Excel Visible and display a message
	//	app.SetVisible(TRUE);
	//	AfxMessageBox(L"Excel is Running!");
	//}

	return err;	
}

ProError TvTestProcImportFeatureCreateNeutral()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMdl mdl_part;
	err = ProMdlInit(L"NEUTRAL_TEST_IMPORT", PRO_MDL_PART, &mdl_part);
	if (err) return err;

	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	TvImportFeature *pImft = new TvImportFeature();
	err = pImft->SetIntfDataSource(mdl_part);
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	pImft->SetSolid((ProSolid)mdl);

	err = pImft->Create();
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	delete pImft;
	pImft = NULL;

	return err;
}

ProError TvTestProcImportFeatureCreateNeutralFile()
{
	ProError err = PRO_TK_NO_ERROR;
	
	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	TvImportFeature *pImft = new TvImportFeature();
	err = pImft->SetIntfDataSource(L"neutral_test_import.neu.1");
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	pImft->SetSolid((ProSolid)mdl);

	err = pImft->Create();
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	delete pImft;
	pImft = NULL;

	return err;
}

ProError TvTestProcImportFeatureRedefineNeutral()
{
	ProError err = PRO_TK_NO_ERROR;

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("feature", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if (err) return err;

	ProFeature feat;
	err = ProSelectionModelitemGet(pSels[0], &feat);
	if (err) return err;

	ProMdl mdl_part;
	err = ProMdlInit(L"NEUTRAL_TEST_IMPORT", PRO_MDL_PART, &mdl_part);
	if (err) return err;

	TvImportFeature *pImft = new TvImportFeature();
	pImft->SetFeature(feat);

	err = pImft->SetIntfDataSource(mdl_part);
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	err = pImft->Redefine();
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	delete pImft;
	pImft = NULL;

	return err;
}

ProError TvTestProcImportFeatureRedefineNeutralFile()
{
	ProError err = PRO_TK_NO_ERROR;

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("feature", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if (err) return err;

	ProFeature feat;
	err = ProSelectionModelitemGet(pSels[0], &feat);
	if (err) return err;

	TvImportFeature *pImft = new TvImportFeature();
	pImft->SetFeature(feat);

	err = pImft->SetIntfDataSource(L"neutral_test_import_gear.neu.1");
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	err = pImft->Redefine();
	if (err)
	{
		delete pImft;
		pImft = NULL;
		return err;
	}

	delete pImft;
	pImft = NULL;

	return err;
}
ProError TvCurveVisitProc(ProGeomitem *p_handle, ProError status, ProAppData app_data)
{
	ProError err = PRO_TK_NO_ERROR;

	int *num = (int*) app_data;

	(*num)++;

	ProCurve curve;
	err = ProGeomitemToCurve(p_handle, &curve);
	if (err) return err;

	ProEnttype type;
	err = ProCurveTypeGet(curve, &type);
	if (err) return err;

	if (type == PRO_ENT_CMP_CRV)
		return err;

	ProGeomitemdata *pData = NULL;
	err = ProCurveDataGet(curve, &pData);
	if (err) return err;

	// free data
	err =  ProGeomitemdataFree(&pData);
	if (err) return err;	

	return err;	
}

ProError ProUtilSectionClean(ProSection section)
{
	ProError err;
	ProIntlist ent_ids, dim_ids, constr_ids;
	int n_dim_ids, n_ids, i, n_constr_ids;

#if 1
	err = ProSectionConstraintsIdsGet(section, &constr_ids, &n_constr_ids);
	if (err) return err;
	
	for (i=0; i<n_constr_ids; i++)
	{
		err = ProSectionConstraintDeny(section, constr_ids[i]);
		if (err) return err;
	}

	err = ProArrayFree( (ProArray *) &constr_ids);
	if (err) return err;
	
#endif
	err = ProSecdimIdsGet(section,&dim_ids,&n_dim_ids);
	if (err) return err;
	

	for (i=0; i<n_dim_ids; i++)
	{
		err = ProSecdimDelete(section,dim_ids[i]);
		if (err) return err;
		
	}

	err = ProArrayFree( (ProArray *) &dim_ids);
	if (err) return err;
	

	err = ProSectionEntityIdsGet(section,&ent_ids,&n_ids);
	if (err) return err;
	

	for (i=0; i<n_ids; i++)
	{
		err = ProSectionEntityDelete(section,ent_ids[i]);
		if (err) return err;
		
	}

	err = ProArrayFree( (ProArray *) &dim_ids);
	if (err) return err;
	

	return(err);
}

ProError TvSolidOutlineCompute()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	Pro3dPnt outline[2];
    static ProMatrix matrix={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
	ProSolidOutlExclTypes excludes[] = {PRO_OUTL_EXC_DATUM_PLANE, 
                                        PRO_OUTL_EXC_DATUM_POINT,
                                        PRO_OUTL_EXC_DATUM_CSYS};
	err = ProSolidOutlineCompute( (ProSolid) mdl, matrix, excludes, 3, outline);
	if (err) return err;

	return err;	
}

ProError TvPrintDtlsymSubgroup(CString offset, CString &text, ProDtlsymgroup* p_group)
{
	ProDtlsymgroup* p_sub_groups = NULL;
	ProError err = ProDtlsymgroupSubgroupsCollect(p_group, &p_sub_groups);
	if (err == PRO_TK_NO_ERROR)
	{
		offset += L"\t";
		int n_sub_groups=0;
		err = ProArraySizeGet(p_sub_groups, &n_sub_groups);
		if (err) return err;

		CString line;
		for (int i=0; i<n_sub_groups; i++)
		{
			ProDtlsymgroup group = p_sub_groups[i];

			ProDtlsymgroupdata group_data;
			err = ProDtlsymgroupDataGet(&group, &group_data);
			if (err) continue;

			ProName group_name;
			err = ProDtlsymgroupdataNameGet(group_data, group_name);
			if (err) continue;

			line.Format(L"%s%d:%s\r\n", offset, p_sub_groups[i].sym_group_id, group_name);
			text += line;

			// add sub_groups
			TvPrintDtlsymSubgroup(offset, text, &p_sub_groups[i]);
		}
		
		err = ProArrayFree((ProArray*)&p_sub_groups);
		if (err) return err;
	}

	return PRO_TK_NO_ERROR;
}

ProError TvTestProc1()
{
	ProError err = PRO_TK_NO_ERROR;
	
	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	// try to collect drawing balloon
	ProDtlnote* pEntities = NULL;
	err = ProDrawingDtlnotesCollect((ProDrawing)mdl, NULL, PRO_VALUE_UNUSED, &pEntities);
	if (err) return err;

	int nEntities = 0;
	err = ProArraySizeGet(pEntities, &nEntities);
	if (err) return err;

	CString ids, texts;
	for (int i=0; i<nEntities; i++)
	{
		ProDtlnote note = pEntities[i];

		CString sid;
		sid.Format(L"%d", note.id);
		ids += sid;
		ids += ",";

		if (note.id < 188)
			continue;

		// try to get text of this note
		ProDtlnotedata data;
		err = ProDtlnoteDataGet(&note, NULL, PRODISPMODE_SYMBOLIC, &data);
		if (err) continue;

		ProDtlnoteline* pLines = NULL;
		err = ProDtlnotedataLinesCollect(data, &pLines);
		if (err) continue;

		ProDtlnotetext* pTexts = NULL;
		err = ProDtlnotelineTextsCollect(pLines[0], &pTexts);
		if (err) continue;

		ProLine line;
		err = ProDtlnotetextStringGet(pTexts[0], line);
		if (err) continue;

		if (note.id == 192)
		{
			wcscpy_s(line, L"&RB_ASM0003:D");
			err = ProDtlnotetextStringSet(pTexts[0], line);
			if (err) return err;

			err = ProDtlnotelineTextsSet(pLines[0], pTexts);
			if (err) return err;

			err = ProDtlnoteldataLinesSet(data, pLines);
			if (err) return err;

			err = ProDtlnoteModify(&note, NULL, data);
			if (err) return err;
		}

		ProDtlnotedataFree(data);
		ProArrayFree((ProArray*)&pTexts);
		ProArrayFree((ProArray*)&pLines);

		sid.Format(L"%d:%s\r\n", note.id, line);
		texts += sid;

		
	}

	err = ProArrayFree((ProArray*)&pEntities);
	return err;
}

#include <TvMacro.h>

void SelectGroup(std::vector<CString>* pGroups, CString &cmd)
{
	CString line;

	size_t i=0;
	for (; i<pGroups->size()-1; i++)
	{
		// node before last: use expand
		line.Format(L"~ Expand `drawing_sym` `tree_group` `%s`;", pGroups->at(i));
		cmd+=line;
	}

	// last node: use select
	line.Format(L"~ Select `drawing_sym` `tree_group` 1 `%s`;", pGroups->at(i));
	cmd+=line;

	// change back 
	line = L"~ Select `drawing_sym` `tab_main` 1 `lay_general`;";
	cmd+=line;	
}



int write_data(void* buffer, int size, int nmemb, void* userp) {
	std::string * str = dynamic_cast<std::string *>((std::string *)userp);
	str->append((char *)buffer, size * nmemb);
	return nmemb;
}

bool CreateJoomlaFormRest(CString* pMsg)
{
	string response;
	CURL *curl;
	CURLcode ret;
	curl = curl_easy_init();
	struct curl_httppost* post = NULL;
	struct curl_httppost* last = NULL;

	if (curl)
	{
		curl_easy_setopt(curl, CURLOPT_URL, "http://wc.home-chen.com:80/Windchill/servlet/rest/objects");           //
		curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);                     //
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);          //
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&response);        //
		curl_easy_setopt(curl, CURLOPT_USERNAME, "orgadmin");
		curl_easy_setopt(curl, CURLOPT_PASSWORD, "Gross7879");

		//const char buf[] = "Token: cYjMTUTNMV3zMZimxY5JRhOM5Dxj5jmYMY0E5Gi";
		//struct curl_slist * headers = NULL;
		//headers = curl_slist_append(headers, buf);
		//curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

		ret = curl_easy_perform(curl);                          //

		curl_global_cleanup();
		curl_easy_cleanup(curl);

		//curl_formfree(last);
		//curl_slist_free_all(headers);

		pMsg->SetString(CA2W(response.data()));
		if (ret != CURLE_OK)
			return false;
	}

	return true;
}


ProError TvTestProc2()
{
	ProError err = PRO_TK_NO_ERROR;

	CString msg;
	CreateJoomlaFormRest(&msg);

	return err;
}

#include <ProMfg.h>

struct handle_data {
    unsigned long process_id;
    HWND window_handle;
};

BOOL CALLBACK EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	handle_data* p_data = (handle_data*)lParam;

	DWORD nProcId = 0;
	GetWindowThreadProcessId(hWnd, &nProcId);

	p_data->process_id = nProcId;
	p_data->window_handle = hWnd;

	// find Notepad++
	TCHAR szClassName[1024];
	::GetClassName(hWnd,  szClassName,  1024);
	if ( _tcscmp( szClassName,  _T("HCS16139P") ) != 0 )
		return TRUE;

	return FALSE;
}

BOOL CALLBACK EnumVisibleChildWndProc(HWND hwnd, LPARAM lParam)
{
	// check is window visiable
	if (!IsWindowVisible(hwnd))
		return TRUE;

	*(HWND*)lParam = hwnd;
	return FALSE;
}

struct ThreadData {
	int win_id;
	CString url;
	bool succeed;
};

UINT ThreadProc(LPVOID lpParam)
{
	ThreadData* p_data = (ThreadData*) lpParam;

	//ProWstring url = NULL;

	//while (1)
	//{
	//	ProWindowURLGet(p_data->win_id, &url);
	//	if (url)
	//	{
	//		ProMessageClear();
	//		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", url);
	//		if (p_data->url.CompareNoCase(url)==0)
	//			p_data->succeed = true;
	//		ProWstringFree(url);
	//		url = NULL;
	//	}

	//	if (p_data->succeed)
	//		return 0;
	//	Sleep(1000);
	//}

	ProWindowURLShow(p_data->win_id, p_data->url.GetBuffer());

	p_data->succeed = true;

	return 0;
}

ProError TvTestProc3()
{
	// select a symbol, show it's view, location and attach_point
	ProSelection *sels = NULL;
	int nSel = 0;
	ProError err = ProSelect(
		"component",
		1,
		NULL,
		NULL,
		NULL,
		NULL,
		&sels,
		&nSel);
	if (nSel < 1)
	{
		return err;
	}

	// get selection
	ProDtlsyminst inst;
	err = ProSelectionModelitemGet(sels[0], &inst);
	if (err) return err;

	

	return PRO_TK_NO_ERROR;
}

ProError CopyBrowserData()
{
	DWORD nProc = ::GetCurrentProcessId();

	handle_data data;
	data.process_id = nProc;
	data.window_handle = 0;
	 
	::EnumWindows(EnumWindowsProc, (LPARAM)&data);
	if (data.window_handle == 0)
		return PRO_TK_GENERAL_ERROR;

	TCHAR szText[1024];
	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	HWND hWnd = data.window_handle;

	// check child window "HCS16139C"
	HWND hWndParent = data.window_handle;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
	if (hWnd == 0)
		return PRO_TK_GENERAL_ERROR;
	
	// check child window "CefBrowserWindow"
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
	if (hWnd == 0)
		return PRO_TK_GENERAL_ERROR;

	::SetForegroundWindow(hWnd);

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('A'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('A'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('C'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('C'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

	// check 

	return PRO_TK_NO_ERROR;
}



ProError TvTestProc4()
{
	// find chrome window, send ctrl+a, and ctrl+v
	DWORD nProc = ::GetCurrentProcessId();

	handle_data data;
	data.process_id = nProc;
	data.window_handle = 0;
	 
	::EnumWindows(EnumWindowsProc, (LPARAM)&data);
	if (data.window_handle == 0)
		return PRO_TK_NO_ERROR;

	// check child window "HCS16139C"
	HWND hWndParent = data.window_handle;
	HWND hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
	if (hWnd == 0)
		return PRO_TK_NO_ERROR;
	
	// check child window "CefBrowserWindow"
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
	if (hWnd == 0)
		return PRO_TK_NO_ERROR;

	::SetForegroundWindow(hWnd);
	
//	// check child window "Chrome_WidgetWin_0"
//	hWndParent = hWnd;
//	hWnd = 0;
//	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
//	if (hWnd == 0)
//		return PRO_TK_NO_ERROR;
//
//	::SetForegroundWindow(hWnd);
//	// check child window "Chrome_RenderWidgetHostHWND"
//	hWndParent = hWnd;
//	hWnd = 0;
//	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
//	if (hWnd == 0)
//		return PRO_TK_NO_ERROR;
//
//	TCHAR szClassName[100];
//
//	::GetClassName(hWnd,  szClassName,  sizeof(szClassName));
//
//	TCHAR szWndText[1024];
//	::GetWindowText(hWnd, szWndText, 1024);
//
//	ProMacroLoad(L"~ Activate `main_dlg_cur` `EMBED_BROWSER_SMARTAB_LAYOUT_buttons_lay_ph.page_0` 0;\
//~ Trail `UI Desktop` `UI Desktop` `SmartTabs` `selectButton main_dlg_cur@EMBED_BROWSER_SMARTAB_LAYOUT_buttons_lay page_0 1`;");
//	ProMacroExecute();

	//::EnableWindow(hWnd, TRUE);
	//::SetForegroundWindow(hWnd);
	//::SetFocus(hWnd);

	//BOOL ret = FALSE;
	//ret = SetWindowPos(hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	//
	
	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('A'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('A'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('C'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('C'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

	
	//ret = PostMessage(hWnd, WM_LBUTTONDBLCLK, 0, (LPARAM)MAKELONG(624, 257));
	////ret = PostMessage(hWnd, WM_COPY, 0, 0);
	//ret = PostMessage(hWnd, WM_KEYDOWN, VK_CONTROL, 0);
	//ret = PostMessage(hWnd, WM_KEYDOWN, VkKeyScan('a'), 0);
	////ret = PostMessage(hWnd, WM_KEYUP, VkKeyScan('a'), 0);
	////ret = PostMessage(hWnd, WM_KEYUP, VK_CONTROL, 0);

	//RECT rc;
	//GetWindowRect(hWnd, &rc);

	//INPUT ip={0}; KEYBDINPUT kb={0};

	////kb.wScan=0xE1;
	//kb.wVk = VK_CONTROL;
	//kb.dwFlags = KEYEVENTF_EXTENDEDKEY;
	//ip.type=INPUT_KEYBOARD;
	//ip.ki=kb;
	//SendInput(1,&ip,sizeof(INPUT));

	//kb.wScan = 'A';
	//kb.dwFlags = KEYEVENTF_SCANCODE;
	//SendInput(1,&ip,sizeof(INPUT));

	//kb.dwFlags = KEYEVENTF_KEYUP;
	//SendInput(1,&ip,sizeof(INPUT));

	//MessageBox(hWnd, L"Hello", L"TV", MB_OK);
	return PRO_TK_NO_ERROR;
}

//////////////////////////////////////////
// test function for NC-Note Editor
ProError TvTestProcModifyNcseqParameters()
{
	ProError err = PRO_TK_NO_ERROR;
	ProError eno = PRO_TK_NO_ERROR;

	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"Please select a feature...");
	if (err) _TVERR(err);

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("membfeat", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err || nSels != 1) _TVMSGERRTEXT("TVPROTOOLS_MSGW", L"select cancelled", err);

	ProFeature feat;
	err = ProSelectionModelitemGet( pSels[0], (ProModelitem*) &feat);
	if( err ) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "ProSelectionModelitemGet", err);
	
	ProAsmcomppath comp_path;
	err = ProSelectionAsmcomppathGet( pSels[0], &comp_path );
	if (err) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "ProSelectionAsmcomppathGet", err);

	ProPath path;
	err = ProDirectoryCurrentGet(path);
	if (err) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "TvModelitemNameGet", err);

	// use oject: TvFeature
	TvFeature *pFeat = new TvFeature(feat);
	if (pFeat == NULL) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "TvFeature", PRO_TK_GENERAL_ERROR);

	pFeat->SetAsmcomppath(comp_path);

	ProElement tree = NULL;
	err = pFeat->GetElemTree(&tree);
	if (err)
	{
		delete pFeat;
		pFeat = NULL;
		_TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "TvFeature.GetElemTree()", err);
	}

	////////////////////////////////////////////////
	// test: modify ncseq parameters here
	//
	// get parameter: SPINDLE_SPEED
	ProElempathItem path_item[1];
	path_item[0].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	path_item[0].path_item.elem_id = PRO_E_MFG_PARAMS;

	ProElempath elempath;
	err = ProElempathAlloc(&elempath);

	err = ProElempathDataSet(elempath, path_item, 1);

	int nElems = 0;
	err = ProElementArrayCount(tree, elempath, &nElems);

	ProElement *pElems = NULL;
	err = ProArrayAlloc(0, sizeof(ProElement), 1, (ProArray*)&pElems);

	err = ProElementArrayGet(tree, elempath, &pElems);

	for (int i=0; i<nElems; i++)
	{
		ProValue value;
		err = ProElementValueGet(pElems[i], &value);
		if (err) continue;
	}

	err = ProArrayFree((ProArray*)&pElems);

	err = ProElempathFree(&elempath);
	if (err) return err;

	ProFeatureCreateOptions opts[1];
	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;
	ProErrorlist errors;
	err = pFeat->Redefine(opts, 1, &errors);

	////////////////////////////////////////////////
	delete pFeat;
	pFeat = NULL;

	return err;	
}


ProError TvHighlightProc()
{
	ProError err = PRO_TK_NO_ERROR;

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("feature", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if (err) return err;

	ProModelitem mi;
	err = ProSelectionModelitemGet(pSels[0], &mi);
	if (err) return err;

#ifdef _DEBUG
	ProName mdl_name;
	ProMdlNameGet(mi.owner, mdl_name);

	ProMdlType mdl_type;
	ProMdlTypeGet(mi.owner, &mdl_type);
#endif

	///////////////////////////////////////
	ProSelection sel;
	err = ProSelectionAlloc(NULL, &mi, &sel);
	if (err) return err;

	// 
	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	ProView *pViews = NULL;
	err = ProDrawingViewsCollect( (ProDrawing) mdl, &pViews);
	if (err) return err;
	
	int nViews = 0;
	err = ProArraySizeGet( pViews, &nViews );
	if (err) return err;

	for (int i=0; i<nViews; i++)
	{
		// set view
		err = ProSelectionViewSet(pViews[i], &sel);
		if (err) return err;

		err = ProSelectionHighlight(sel, PRO_COLOR_HIGHLITE);
		if (err) return err;
	}

	// free
	err = ProArrayFree( (ProArray*) &pViews);
	if (err) return err;	

	return err;	
}

ProError TvWriteXMLProc()
{
	ProError err = PRO_TK_NO_ERROR;

#ifdef _DEBUG  
	CMemoryState oldMemState,newMemState,diffMemState;
	oldMemState.Checkpoint(); 
#endif

	err = TvXMLSave();


#ifdef _DEBUG  
	newMemState.Checkpoint();  
	if(diffMemState.Difference(oldMemState,newMemState))
	{
		TRACE("-> ERR!!!Memory leak detected!(CADAutomat:OpenCSVProc)\n");  
		diffMemState.DumpStatistics();
		AfxMessageBox(L"Memory leak detected!");
	}
	else
	{
		TRACE("-> No Memory leak detected!(CADAutomat:OpenCSVProc)\n");
	}
#endif

	return err;
}

ProError TvGetConstrProc()
{
	ProError err = PRO_TK_NO_ERROR;

	err = TvConstrGet();

	return err;
}

ProError TvCsysGetDataProc()
{
	ProError err = PRO_TK_NO_ERROR;

	err = TvCsysDataGet();

	return err;
}

ProError TvCsysAxisGetAngleProc()
{
	ProError err = PRO_TK_NO_ERROR;

	err = TvCsysAxisGetAngle();

	return err;
}

ProError TvHoleTableExProc()
{
	ProError err = PRO_TK_NO_ERROR;

	err = TvHoleTableEx();

	return err;
}

ProError TvMfgToolCollectProc()
{
	ProError err = PRO_TK_NO_ERROR;

	err = TvProMfgToolsCollect();

	return err;
}


ProError TvUdfAddProc()
{
	ProError err = PRO_TK_NO_ERROR;

	// get current model
	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	// ask user to select a udf file
	// open file dialog
	ProPath wszSelection;
	err = ProFileOpen( L"Open udf file", L"*.gph", NULL, NULL, NULL, NULL, wszSelection );
	if (err) return err;

	ProArgument *inputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &inputs);
	if (err) return err;

	// first input argument: UDF filename
	ProArgument in1;
	ProWstringCopy(L"TV_UDF_ADD_PATHNAME", in1.label, PRO_VALUE_UNUSED);
	err = ProValuedataWstringSet(&in1.value, wszSelection);
	if (err) return err;

	err = ProArrayObjectAdd( (ProArray*) &inputs, -1, 1, &in1 );
	if (err) return err;

	// second input argument: CS selection
	ProArgument in2;
	// set name
	ProWstringCopy(L"TV_UDF_ADD_CSYS", in2.label, PRO_VALUE_UNUSED);
	in2.value.type = PRO_VALUE_TYPE_SELECTION;

	// set second argument as ProSelection
	//ProModelitem cs_mi;
	//err = ProModelitemByNameInit(mdl, PRO_CSYS, L"CS_UDF", &cs_mi);
	//if (err) return err;

	//err = ProSelectionAlloc(NULL, &cs_mi, &in2.value.v.r); 
	//if (err) return err;

	//err = ProArrayObjectAdd( (ProArray*) &inputs, -1, 1, &in2 );
	//if (err) return err;

	// third input argument: ProMdl
	ProArgument in3;
	// set name
	ProWstringCopy(L"TV_UDF_ADD_MDL", in3.label, PRO_VALUE_UNUSED);
	in3.value.type = PRO_VALUE_TYPE_SELECTION;

	// set third argument as ProSelection
	ProModelitem mdl_mi;
	err = ProMdlToModelitem(mdl, &mdl_mi);
	if (err) return err;

	err = ProSelectionAlloc(NULL, &mdl_mi, &in3.value.v.r); 
	if (err) return err;

	err = ProArrayObjectAdd( (ProArray*) &inputs, -1, 1, &in3 );
	if (err) return err;

	// set fourth argument: TV_UDF_ADD_REF, prompt of reference
	//ProArgument in4;
	//ProWstringCopy(L"TV_UDF_ADD_REF", in4.label, PRO_VALUE_UNUSED);
	//err = ProValuedataWstringSet(&in4.value, L"UDF_KS");
	//if (err) return err;

	//err = ProArrayObjectAdd( (ProArray*) &inputs, -1, 1, &in4 );
	//if (err) return err;

	// make output arguments
	ProArgument *outputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &outputs);
	if (err) return err;

	// call TvUdfAdd
#ifndef WF2
	err = TvUdfAdd(inputs, &outputs);
#endif

	//////////////////////////////////////////////////////////////////////////
	// check outputs
	int nOutputs = 0;
	err = ProArraySizeGet( (ProArray) outputs, &nOutputs );
	if (err) return err;
	if (nOutputs == 1)
	{
		ProArgument out1;
		err = ProArgumentByLabelGet( outputs, L"TV_UDF_ADD_UDF", &out1.value);
		if (err) return err;

		err = ProSelectionHighlight(out1.value.v.r, PRO_COLOR_HIGHLITE);
		if (err) return err;
	}
	



	//////////////////////////////////////////////////////////////////////////
	// free memory
	err = ProArgumentProarrayFree( &inputs );

	err = ProArgumentProarrayFree( &outputs );


	return err;
}


ProError TvVartextFindProc()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	vector<TvProTkSymbolInfo> symbols;
	err = TvDrawingSymbolsCollect( (ProDrawing) mdl, NULL, -1, &symbols);
	if (err) return err;

	for (size_t i=0; i<symbols.size(); i++)
	{
		for (size_t j=0; j<symbols[i].TextVars.size(); j++)
		{
			if (wcslen(symbols[i].TextVars[j].param_name) > PRO_NAME_SIZE)
			{
				ProMessageClear();
				ProMessageDisplay(MSG_FILE, "TVPROTOOLS_VARTEXT_NAME_TOO_LONG", symbols[i].TextVars[j].param_name, symbols[i].Name);
			}
		}
	}

	return err;
}

ProError TvParamCfgImportProc()
{
	ProError err = PRO_TK_NO_ERROR;

	// ask user to select configuration file
	ProPath wszSelection;
	err = ProFileOpen( L"Open Toolbox/Gearwheel configuration file", L"*.txt", NULL, NULL, NULL, NULL, wszSelection );
	if (err) return err;

	// read this file 
	TvIniFile config;
	config.SetPath(string(CW2A(wszSelection)));

	if (!config.ReadFile())
		return err;

	int param_pos = config.FindKey("parameters");
	if (param_pos<0)
		return err;

	int num = config.GetNumValues("parameters");
	if (num<=0)
		return err;

	vector<TvProTkDtlvartext> params;
	for (int i=0; i<num; i++)
	{
		TvProTkDtlvartext var;
		wcscpy_s(var.param_name, PRO_LINE_SIZE, CA2W(config.GetValueName(param_pos, i).data()));

		string value = config.GetValue(param_pos, i);
		wcscpy_s(var.param_value, PRO_LINE_SIZE, CA2W(value.data()));

		params.push_back(var);
	}

	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"Parameter configuration file successfully loaded");
	if (err) _TVERR(err);

	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"Please select a Feature to set parameters...");
	if (err) _TVERR(err);

	// ask user to select feature
	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("feature", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if (err) return err;

	if (nSels != 1)
		return err;

	ProFeature feat;
	err = ProSelectionModelitemGet(pSels[0], (ProModelitem*) &feat);
	if (err) return err;

	// set parameters to this feature
	err = TvFeatureParametersSet(&feat, &params);
	if (err) return err;

	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"Set parameters to selected feature successfully");
	if (err) _TVERR(err);

	return err;
}

ProError TvNcNoteEditorProc()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMessageClear();
	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"Bitte eine NC-Folge ausw�hlen...");
	if (err) _TVERR(err);

	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("membfeat", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err || nSels != 1) _TVMSGERRTEXT("TVPROTOOLS_MSGW", L"select cancelled", err);

	ProFeature feat;
	err = ProSelectionModelitemGet( pSels[0], (ProModelitem*) &feat);
	if( err ) _TVMSGERRFUNCODE("TVPROTOOLS_PROTK_ERR", "ProSelectionModelitemGet", err);

	return err;
}

ProError TvSetCommonNameProc()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err)
	{
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_NO_CURRENT_MODEL");
		return err;
	}

	err = ProMessageDisplay(MSG_FILE, "TVPROTOOLS_SET_COMMON_NAME");
	if (err) return err;

	ProName name = L"";
	err = ProMessageStringRead(PRO_NAME_SIZE, name);
	if (err) return err;

	// set name
	if (wcslen(name)==0)
		return PRO_TK_NO_ERROR;

	ProName oname;
	err = ProMdlNameGet(mdl, oname);
	if (err) return err;

	if (_wcsicmp(name, oname)==0)
	{
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_NO_CHANGE");
		return PRO_TK_NO_ERROR;
	}

	ProMdlType type;
	err = ProMdlTypeGet(mdl, &type);
	if (err) return err;

	ProLine cname;
	if (type == PRO_MDL_PART)
		swprintf_s(cname, L"%s.prt", name);
	else if (type == PRO_MDL_ASSEMBLY)
		swprintf_s(cname, L"%s.asm", name);
	else
		swprintf_s(cname, L"%s.unknown", name);

	err = ProMdlCommonnameSet(mdl, cname);
	if (err) return err;

	err = ProMdlRename(mdl, name);
	if (err) return err;

	err = ProMdlSave(mdl);
	if (err) return err;

	return err;
}

ProError TvProToolsDlgProc()
{


	return PRO_TK_NO_ERROR;
}