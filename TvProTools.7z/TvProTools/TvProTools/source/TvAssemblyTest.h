#pragma once

#include <TvProTkUtils.h>


ProError TvRotateCompProc();
ProError TvGetTransMatrixProc();