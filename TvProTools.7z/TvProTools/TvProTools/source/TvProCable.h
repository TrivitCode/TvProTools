#pragma once

#include <ProToolkit.h>
#include <TvProTkUtils.h>
#include <ProCabling.h>
#include <ProCurve.h>

using namespace TvUtils;

ProError TvProCableTest1( ProAssembly assembly );
ProError TvProCableTest2( ProAssembly assembly );
ProError TvProCableTest3( ProMdl mdl );

