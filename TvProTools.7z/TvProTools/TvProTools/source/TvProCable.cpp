#include "stdafx.h"

#include "TvProCable.h"



ProError TvProCableTest1( ProAssembly assembly )
{
	ProError err = PRO_TK_NO_ERROR;

	ProHarness *pHarnesses = NULL;
	err = ProAssemblyHarnessesCollect( assembly, &pHarnesses);
	if (err) return err;
	
	int nHarnesses = 0;
	err = ProArraySizeGet( pHarnesses, &nHarnesses);
	if (err) return err;

	for (int i=0; i<nHarnesses; i++)
	{
		// get 
		// collect cables of harness
		ProCable *pCables = NULL;
		err = ProHarnessCablesCollect( pHarnesses[i], &pCables);
		if (err) continue;

		int nCables = 0;
		err = ProArraySizeGet( pCables, &nCables);
		if (err) return err;

		for (int j=0; j<nCables; j++)
		{
			ProName cable_name;
			err = ProCableNameGet( & pCables[j], cable_name );
			if (err) continue;

			// get length
			double cable_length = 0.0;
			err = ProCableLengthGet( & pCables[j], &cable_length);
			if (err) continue;

			// get type
			ProCableType cable_type;
			err = ProCableTypeGet( & pCables[j], &cable_type);
			if (err) continue;

			// type == PRO_CABLETYPE_CABLE
			// there is no logical ends
			ProSelection log_end_1, log_end_2;
			err = ProCableLogicalEndsGet( assembly, & pCables[j], &log_end_1, &log_end_2 );
			if (err==PRO_TK_NO_ERROR) 
			{
				ProModelitem log_end_mi_1;
				err = ProSelectionModelitemGet( log_end_1, &log_end_mi_1);
				if (err) continue;

				ProModelitem log_end_mi_2;
				err = ProSelectionModelitemGet( log_end_2, &log_end_mi_2);
				if (err) continue;
			}

			// re-init ProCable
			ProCable cable;
			err = ProCableByNameGet( pHarnesses[i], cable_name, &cable);
			if (err) continue;

			if (cable_type == PRO_CABLETYPE_CABLE)
			{
				// is complete
				// !!!crash!!!!, if type==PRO_CABLETYPE_WIRE
				ProBoolean is_complete;
				err = ProCableIsComplete( & cable, &is_complete);
				if (err) return err;

				// get segments
				// !!!crash!!!!, if type==PRO_CABLETYPE_WIRE
				ProCablesegment *pCableSegs = NULL;
				err = ProCableSegmentsGet( & cable, &pCableSegs);
				if (err) continue;

				int nCableSegs = 0;
				err = ProArraySizeGet( pCableSegs, &nCableSegs);
				if (err) continue;

				err = ProArrayFree( (ProArray*) &pCableSegs);
				if (err) return err;
			}

			// 
			ProCablelocation *pLocations = NULL;
			err = ProCableLocationsCollect( assembly, &cable, &pLocations);
			if (err) continue;

			int nLocations = 0;
			err = ProArraySizeGet( pLocations, &nLocations);
			if (err) continue;

			for (int k=0; k<nLocations; k++)
			{
				ProCablelocationType loc_type;
				err = ProCablelocationTypeGet( &pLocations[k], &loc_type );
				if (err) continue;

				ProPoint3d loc_pnt;
				ProVector loc_tan;
				err = ProCablelocationPointGet(&pLocations[k], loc_pnt, loc_tan);
				if (err) continue;
			}

			err = ProArrayFree( (ProArray*) &pLocations);
			if (err) return err;
		}

		err = ProArrayFree( (ProArray*) &pCables);
		if (err) return err;
	}


	err = ProArrayFree( (ProArray*) &pHarnesses);
	if (err) return err;
	return err;
}




ProError TvProCableTest2( ProAssembly assembly )
{
	ProError err;

	ProConnector *pConnectors = NULL;
	err = ProAssemblyConnectorsGet(assembly, &pConnectors);
	if (err) return err;

	int nConnectors = 0;
	err = ProArraySizeGet( pConnectors, &nConnectors);
	if (err) return err;

	for (int i=0; i<nConnectors; i++)
	{
		//
		ProMdl mdl;
		err = ProAsmcomppathMdlGet( & pConnectors[i], &mdl);
		if (err == PRO_TK_NO_ERROR)
		{
			ProName name;
			err = ProMdlNameGet(mdl, name);
			if (err) return err;
		}

		// 
		ProCableparam *pParams = NULL;
		err = ProConnectorParamsCollect( &pConnectors[i], &pParams );
		if (err == PRO_TK_NO_ERROR)
		{
			int nParams = 0;
			err = ProArraySizeGet( pParams, &nParams);
			if (err) return err;

			for (int j=0; j<nParams; j++)
			{
				ProCableparam param = pParams[j];
	
				ProName name;
				wcscpy_s(name, param.name);
			}

			err = ProArrayFree( (ProArray*) &pParams);
			if (err) return err;
		}
	}

	err = ProArrayFree( (ProArray*) &pConnectors);
	if (err) return err;
	
	return err;
}


ProError TvProCableTest3( ProMdl mdl )
{
	ProError err;

	// collect features
	ProFeature *pFeatures = NULL;
	int nFeatures = 0;
	err = TvSolidFeaturesCollect( (ProSolid)mdl, -1, &pFeatures, &nFeatures);
	if (err) return err;

	for (int i=0; i<nFeatures; i++)
	{
		ProFeattype type;
		err = ProFeatureTypeGet( & pFeatures[i], &type );
		if (err) continue;

		if (type != PRO_FEAT_COMPONENT)
			continue;

		// get status: == active
		ProFeatStatus status = PRO_FEAT_INVALID;
		err = ProFeatureStatusGet( &pFeatures[i], &status );
		if( status != PRO_FEAT_ACTIVE ) continue;

		ProMdl comp_mdl;
		err = ProAsmcompMdlGet( (ProAsmcomp*) & pFeatures[i], &comp_mdl );
		if( err ) continue;

		ProName name;
		err = ProMdlNameGet( comp_mdl, name );
		if (err) continue;

		// get mdl type
		ProMdlType mdl_type;
		err = ProMdlTypeGet( comp_mdl, &mdl_type );
		if (err) continue;

		ProMdlsubtype mdl_sub_type;
		err = ProMdlSubtypeGet(comp_mdl, &mdl_sub_type);
		if (err) continue;

		if (_wcsicmp(name, L"TESTKABELBAUM_2") != 0)
			continue;

		ProFeature *pFeats = NULL;
		int nFeats = 0;
		err = TvSolidFeaturesCollect( (ProSolid)comp_mdl, -1, &pFeats, &nFeats);
		if (err) return err;

		for (int j=0; j<nFeats; j++)
		{
			ProName feat_type_name;
			err = ProFeatureTypenameGet( &pFeats[j], feat_type_name);
			if (err) continue;

			ProFeattype feat_type;
			err = ProFeatureTypeGet( &pFeats[j], &feat_type );
			if (err) continue;

			if (feat_type == PRO_FEAT_CABLE_SEGM)
			{
				// visit geometrie
				ProGeomitem *pGeoms = NULL;
				int nGeoms = 0;
				err = TvFeatureGeomitemsCollect( &pFeats[j], PRO_TYPE_UNUSED, &pGeoms, &nGeoms);
				if (err==PRO_TK_NO_ERROR)
				{
					for (int k=0; k<nGeoms; k++)
					{
						// get type
						ProBoolean is_active;
						err = ProGeomitemIsInactive( &pGeoms[k], &is_active );
						if (err) return err;	

						if (pGeoms[k].type == PRO_CURVE)
						{
							ProCurve curve;
							err = ProGeomitemToCurve( &pGeoms[k], &curve );
							if (err == PRO_TK_NO_ERROR)
							{
								double length = 0.0;
								err = ProCurveLengthEval(curve, &length);
								if (err==PRO_TK_NO_ERROR)
								{

								}

								ProEnttype curve_type;
								err = ProCurveTypeGet(curve, &curve_type);
								if (err)
								{
								}
							}
						}
					}
				}
			}

			if (feat_type == PRO_FEAT_CABLE)
			{
				int *pChildren = NULL;
				int nChildren = 0;
				err = ProFeatureChildrenGet( &pFeats[j], &pChildren, &nChildren );
				if (err == PRO_TK_NO_ERROR)
				{


					err = ProArrayFree( (ProArray*) &pChildren);
					if (err) return err;
				}

			}

			ProName feat_name;
			err = ProModelitemNameGet( &pFeats[j], feat_name);
			if (err)
			{
			}

			ProElement tree;
			err = ProFeatureElemtreeExtract( &pFeats[j], NULL, PRO_FEAT_EXTRACT_NO_OPTS, &tree);
			if (err==PRO_TK_NO_ERROR)
			{
				// write to xml
				ProPath xml_file;
				swprintf_s(xml_file, L"ID_%d", pFeats[j].id);
				err = ProElemtreeWrite(tree, PRO_ELEMTREE_XML, xml_file);
				if (err) return err;

				err =  ProFeatureElemtreeFree( &pFeats[j], tree );
				if (err) return err;
			}

		}

		err = ProArrayFree( (ProArray*) &pFeats);
		if (err) return err;
	}

	err = ProArrayFree( (ProArray*) &pFeatures);
	if (err) return err;

	return err;
}