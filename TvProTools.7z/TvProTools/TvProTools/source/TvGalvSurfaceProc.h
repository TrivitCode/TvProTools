#pragma once
#include <ProToolkit.h>

void TvGalvSurfaceDialogCloseAction(char *dialog, char *component, ProAppData data);

//void TvGalvSurfaceDialogAddHoleAction(char *dialog, char *component, ProAppData data);
void TvGalvSurfaceListClickAction(char *dialog, char *component, ProAppData data);
void TvGalvSurfaceListMouseoverAction(char *dialog, char *component, ProAppData data);
void TvGalvSurfaceInputpanelInputAction(char *dialog, char *component, ProAppData data);
void TvGalvSurfacePushbuttonClickAction(char *dialog, char *component, ProAppData data);
