#pragma once
#include <TvProDllApp.h>
#include <ProToolkitDll.h>
#include <TvSolid.h>
#include <vector>
//#include "TvHoleItem.h"
//#include "TvCrossfeedList.h"

class TvGalvSurfApp : public TvProDllApp
{
public:
	TvGalvSurfApp(void);
	~TvGalvSurfApp(void);

	bool Initialize(void);
	bool Run(void);

	//bool AddHole();
	bool OnListClick(char *dialog, char *component, ProAppData data);
	bool OnListMouseover(char *dialog, char *component, ProAppData data);
	bool OnInputpanelInput(char *dialog, char *component, ProAppData data);
	bool OnPushbuttonClick(char *dialog, char *component, ProAppData data);
	void OnCancel(char *dialog);
	void OnOK(char *dialog);

protected:
	ProCharName m_szUIDlgName;
	ProCharName m_szUITextDlgName;
	ProCharName m_szUIDrwAreaName1;
	ProCharName m_szUIDrwAreaName2;
	ProCharName m_szUIDrwAreaName3;
	ProCharName m_szUIDrwAreaName4;
	ProCharName m_szUIListName;
	ProCharName m_szUITextAreaName;
	TvSolid* m_pSolid;
	double m_AreaTotal;
	double m_Weight;
	double m_AreaHoles;
	double m_AreaCrossfeed;
	double m_AreaFixed;
	ProCollection m_Collection;
	//vector<TvHoleItem> m_Holes;
	//TvCrossfeedList m_Crossfeeds;
	int m_CurrentListPos;

protected:
	bool InitializeUI();
	bool InitializeDefaults();
	bool InitializeCrossfeeds();
	bool ExtractCollectionSurfaces();
	bool AddReferenceAsHoleFrontSurface(ProReference ref);
	bool UpdateList(bool SaveSelection=false);
	bool HighlightListItem(int nItem, bool highlight);
	bool UpdateArea();
	bool SelectSurfaces();
	double SelectDiameter();
	bool UpdateDiameters();
	void ResetUI();
	bool FixTotalArea(double* pArea);
	ProError ShowDialog(CString &text);
	//bool CalculateFontSurfaceDiameters(TvSurfaceList* pSrfs);
	void UpdateLength();
};