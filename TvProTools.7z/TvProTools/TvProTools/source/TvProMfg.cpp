#include "stdafx.h"

#include "TvProMfg.h"

#include <ProToolkit.h>
#include <ProMfg.h>
#include <ProSolid.h>
#include <ProSelection.h>
#include <ProAsmcomppath.h>
#include <ProElement.h>
#include <ProElemId.h>
#include <ProValue.h>
#include <ProFeature.h>
#include <ProUtil.h>
#include <ProTool.h>
#include <ProNcseq.h>

ProError TvProMfgCollectProc(ProTool* tool, ProAppData app_data)
{
	ProError err = PRO_TK_NO_ERROR;

	err = ProArrayObjectAdd( (ProArray*) app_data, PRO_VALUE_UNUSED, 1, tool);

	return err;
}	

ProError TvProMfgToolsCollect()
{
	ProError err = PRO_TK_NO_ERROR, eno = PRO_TK_NO_ERROR;

	ProMfg mfg;
	err = ProMdlCurrentGet( (ProMdl*) &mfg);
	if( err ) return err;

	ProTool	*p_tools = NULL;
	err = ProArrayAlloc( 0, sizeof(ProTool), 1, (ProArray*) &p_tools );
	if( err ) return err;

	err = ProMfgToolVisit(mfg, (ProMfgToolAction)TvProMfgCollectProc, (ProAppData)&p_tools);
	if( err ) return err;

	int num_tools = 0;
	err = ProArraySizeGet( (ProArray) p_tools, &num_tools);
	if( err ) goto ON_ERR;

	for( int i=0; i<num_tools; i++ )
	{
		ProToolType type;
		eno = ProToolTypeGet( & p_tools[i], &type);

		ProParamvalue param_value;
		eno = ProToolParamGet( & p_tools[i], "CUTTER_DIAM", &param_value ); 

		eno = ProToolParamGet( & p_tools[i], "TOOL_COMMENT", &param_value ); 

		// try to redefine TOOL_COMMENT
		wcscpy_s( param_value.value.s_val, L"Hallo i am test" );

		ProElement Element = NULL;
		err = ProElementAlloc( PRO_E_PARAMS, &Element);
		if( err) continue;

		err = ProToolElemParamAdd( Element, &param_value, "TOOL_COMMENT" );
		if( err ) continue;

		ProToolinputPtr ToolInput = NULL;
		err = ProToolinputAlloc(&ToolInput);
		if( err ) continue;

		err = ProToolinputTypeSet(ToolInput, type);
		if( err ) 
		{
			ProToolinputFree (&ToolInput);
			continue;
		}

		err = ProToolinputElemAdd( ToolInput, Element );
		if( err ) 
		{
			ProToolinputFree (&ToolInput);
			continue;
		}

		ProErrorlist Errs;
		err = ProToolRedefine( &p_tools[i], ToolInput, &Errs );
		if( err ) 
		{
			ProToolinputFree (&ToolInput);
			continue;
		}

		ProToolinputFree (&ToolInput);

		err = ProToolVerify( &p_tools[i] );
		if( err ) continue;



		continue;
	}

	eno = ProArrayFree( (ProArray*)&p_tools );
	if( err ) return err;
	p_tools = NULL;


	return err;

ON_ERR:
	if( p_tools != NULL )
	{
		eno = ProArrayFree( (ProArray*)&p_tools );
		p_tools = NULL;
	}
	return err;
}

ProError CreateNcSeq()
{
	ProError err;

	// allocate element tree for Nc-Seq
	ProElement root;
	err = ProElementAlloc(PRO_E_FEATURE_TREE, &root);
	if (err) return err;

	ProElement elem = NULL;

	// add Type	-> PRO_E_FEATURE_TYPE = PRO_FEAT_DRILL
	err = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem);
	if (err) return err;
	err = ProElementIntegerSet(elem, PRO_FEAT_DRILL);
	if (err) return err;
	err = ProElemtreeElementAdd(root, NULL, elem);
	if (err) return err;

	/*
	<PRO_E_NUM_AXES type="int">3</PRO_E_NUM_AXES>
	<PRO_E_NCSEQ_TYPE type="int">5</PRO_E_NCSEQ_TYPE>
	<PRO_E_HOLEMAKING_TYPE type="int">4</PRO_E_HOLEMAKING_TYPE>
	<PRO_E_HOLE_CYCLE_TYPE type="int">4</PRO_E_HOLE_CYCLE_TYPE>
	<PRO_E_PECK_TYPE type="int">-1</PRO_E_PECK_TYPE>
	<PRO_E_MACH_HEAD type="int">1</PRO_E_MACH_HEAD>
	<PRO_E_POCKET_NUMBER type="int">1</PRO_E_POCKET_NUMBER>
	<PRO_E_OPERATION type="int">49</PRO_E_OPERATION>
	<PRO_E_FEAT_NAME type="wstring">BOHREN_DM13_G54_T0</PRO_E_FEAT_NAME>
	<PRO_E_COMMENTS type="multivalue">
	</PRO_E_COMMENTS>
	<PRO_E_TOOL type="wstring">4711-00</PRO_E_TOOL>
	*/

	// add num axes	-> PRO_E_NUM_AXES = 3
	err = ProElementAlloc(PRO_E_NUM_AXES, &elem);
	if (err) return err;
	err = ProElementIntegerSet(elem, 2);
	if (err) return err;
	err = ProElemtreeElementAdd(root, NULL, elem);
	if (err) return err;

	// add NcSeq Type	-> PRO_E_NCSEQ_TYPE = PRO_NCSEQ_HOLEMAKING
	err = ProElementAlloc(PRO_E_NCSEQ_TYPE, &elem);
	if (err) return err;
	err = ProElementIntegerSet(elem, PRO_NCSEQ_FF_TRAJ_MILL);
	if (err) return err;
	err = ProElemtreeElementAdd(root, NULL, elem);
	if (err) return err;

	//// add holemaking type	-> PRO_E_HOLEMAKING_TYPE = PRO_HOLE_MK_DRILL
	//err = ProElementAlloc(PRO_E_HOLEMAKING_TYPE, &elem);
	//if (err) return err;
	//err = ProElementIntegerSet(elem, PRO_HOLE_MK_DRILL);
	//if (err) return err;
	//err = ProElemtreeElementAdd(root, NULL, elem);
	//if (err) return err;

	//// add hole cycle type	-> PRO_E_HOLE_CYCLE_TYPE = 4
	//err = ProElementAlloc(PRO_E_HOLE_CYCLE_TYPE, &elem);
	//if (err) return err;
	//err = ProElementIntegerSet(elem, 4);
	//if (err) return err;
	//err = ProElemtreeElementAdd(root, NULL, elem);
	//if (err) return err;

	// add mach head type	-> PRO_E_MACH_HEAD = 1
	err = ProElementAlloc(PRO_E_MACH_HEAD, &elem);
	if (err) return err;
	err = ProElementIntegerSet(elem, 1);
	if (err) return err;
	err = ProElemtreeElementAdd(root, NULL, elem);
	if (err) return err;

	// add pocket number type	-> PRO_E_POCKET_NUMBER = 1
	err = ProElementAlloc(PRO_E_POCKET_NUMBER, &elem);
	if (err) return err;
	err = ProElementIntegerSet(elem, 1);
	if (err) return err;
	err = ProElemtreeElementAdd(root, NULL, elem);
	if (err) return err;

	// add operation id	-> PRO_E_OPERATION = 49
	err = ProElementAlloc(PRO_E_OPERATION, &elem);
	if (err) return err;
	err = ProElementIntegerSet(elem, 49);
	if (err) return err;
	err = ProElemtreeElementAdd(root, NULL, elem);
	if (err) return err;

	// add feat name	-> PRO_E_FEAT_NAME = "TEST_HOLE_MK_DRILL"
	//err = ProElementAlloc(PRO_E_FEAT_NAME, &elem);
	//if (err) return err;
	//err = ProElementWstringSet(elem, L"TEST_NC_LEIT2");
	//if (err) return err;
	//err = ProElemtreeElementAdd(root, NULL, elem);
	//if (err) return err;

	//// add tool name	-> PRO_E_TOOL = "4711-00"
	//err = ProElementAlloc(PRO_E_TOOL, &elem);
	//if (err) return err;
	//err = ProElementWstringSet(elem, L"4711-00");
	//if (err) return err;
	//err = ProElemtreeElementAdd(root, NULL, elem);
	//if (err) return err;

	// get modelitem
	ProMdl Mdl;
	err = ProMdlCurrentGet(&Mdl);
	if (err) return err;

	ProSelection Sel;
	err = TvMfgModelToSelection((ProMfg)Mdl, -1, PRO_TYPE_UNUSED, &Sel);
	if (err) return err;

	ProFeatureCreateOptions opts[1];
	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;
	ProFeature feat;
	ProErrorlist errors;
	err = ProFeatureCreate(Sel, root, opts, 1, &feat, &errors);
	if (err)
	{
		ProElementFree(&root);
		return err;
	}
	ProElementFree(&root);

	return PRO_TK_NO_ERROR;
}


/*====================================================================*\
Function : UserMillingCreate
Purpose  : Create a milling feature using element tree
\*====================================================================*/
ProError UserMillingCreate (ProMfg        mfg_model,
							ProNcseqType  ncseq_type,
							ProName       feat_name,
							int           oper_id, 
							int           retract_id,
							ProSelection *mach_csys,
							wchar_t      *tool_name )
{
	ProError       err  = PRO_TK_NO_ERROR;
	//ProElement     ncseq_elem      = (ProElement)NULL; 
	///* Individual element */
	//ProElement     ncseq_elem_tree = (ProElement)NULL; /* Entire tree */
	//ProValueData   value_data;
	//ProValue       value        = (ProValue)NULL;
	//ProErrorlist   errors;
	//ProSelection   selection;
	//ProFeature     ncseq_feature;
	//ProFeatureCreateOptions fd_opts[] = {PRO_FEAT_CR_DEFINE_MISS_ELEMS };
	//int            i = 0;

	//ProError UserWpieceSelCreate ( ProMfg, int, ProType, ProSelection*);
	//ProError UserMfgParamsSet(ProElement*);
	//ProError UserMfgSurfacesAdd(ProElement*);

	//static ElemTable  ncseq_elem_table[] =  {
	//	{ PRO_E_FEATURE_TYPE,  PRO_VALUE_TYPE_INT       },
	//	{ PRO_E_NCSEQ_TYPE,    PRO_VALUE_TYPE_INT       },
	//	{ PRO_E_OPERATION,     PRO_VALUE_TYPE_INT       },
	//	{ PRO_E_RETRACT,       PRO_VALUE_TYPE_INT       },
	//	{ PRO_E_CSYS,          PRO_VALUE_TYPE_SELECTION },
	//	{ PRO_E_MFG_PARAMS,    ARRAY                    },
	//	{ PRO_E_SURFACES,      COMPLEX                  },
	//	{ PRO_E_TOOL,          PRO_VALUE_TYPE_WSTRING   },
	//	{ PRO_E_FEAT_NAME,     PRO_VALUE_TYPE_WSTRING   }
	//};

	//int ncseq_elem_type_size = sizeof(ncseq_elem_table)/sizeof(ElemTable);

	///*--------------------------------------------------------------------*\
	//Allocate feature tree element
	//\*--------------------------------------------------------------------*/
	//err = ProElementAlloc(PRO_E_FEATURE_TREE, &ncseq_elem_tree);
	//ERROR_CHECK("UserNcsequenceCreate","ProElementAlloc()", err);

	//for (i=0 ; i < ncseq_elem_type_size; i++)
	//{
	//	/*--------------------------------------------------------------------*\
	//	Allocate sequence element
	//	\*--------------------------------------------------------------------*/
	//	err = ProElementAlloc(ncseq_elem_table[i].elem_type, &ncseq_elem);
	//	ERROR_CHECK("UserNcsequenceCreate","ProElementAlloc()", err);
	//	switch (ncseq_elem_table[i].elem_type)
	//	{
	//	case PRO_E_FEATURE_TYPE :
	//		value_data.v.i = PRO_FEAT_MILL;
	//		break;

	//	case PRO_E_NCSEQ_TYPE :
	//		value_data.v.i = ncseq_type ;
	//		break;

	//	case PRO_E_OPERATION :
	//		value_data.v.i = oper_id ;
	//		break;

	//	case PRO_E_RETRACT :
	//		value_data.v.i = retract_id ;
	//		break;

	//	case PRO_E_MFG_PARAMS:
	//		err = UserMfgParamsSet(&ncseq_elem);
	//		break;

	//	case PRO_E_CSYS:
	//		err = ProSelectionCopy(*mach_csys, &(value_data.v.r));
	//		break;

	//	case PRO_E_SURFACES:
	//		err = UserMfgSurfacesAdd(&ncseq_elem);
	//		break;

	//	case PRO_E_FEAT_NAME:
	//		value_data.v.w = (wchar_t*) malloc (sizeof(ProName));

	//		if (value_data.v.w)
	//			ProUtilWstrcpy(value_data.v.w,feat_name);
	//		else
	//			err = PRO_TK_BAD_INPUTS;
	//		break;

	//	case PRO_E_TOOL:
	//		value_data.v.w = (wchar_t*) malloc (sizeof(ProName));
	//		if (value_data.v.w)
	//			ProUtilWstrcpy(value_data.v.w,(wchar_t*)tool_name);
	//		else
	//			err = PRO_TK_BAD_INPUTS;
	//		break;

	//	default:

	//		ProTKFprintf(stderr, "Error setting element type\n");
	//		return PRO_TK_GENERAL_ERROR;
	//		break;
	//	}
	//	/*--------------------------------------------------------------------*\
	//	If element is simple add it its value to the element
	//	\*--------------------------------------------------------------------*/
	//	if ( ncseq_elem_table[i].val_type != ARRAY &&
	//		ncseq_elem_table[i].val_type != COMPLEX )
	//	{
	//		value_data.type = (ProValueDataType) ncseq_elem_table[i].val_type;
	//		err = ProValueAlloc ( &value );

	//		if (err == PRO_TK_NO_ERROR)
	//		{
	//			err = ProValueDataSet (value, &value_data);
	//			ERROR_CHECK("UserNcsequenceCreate", "ProValueDataSet()", err);
	//		}

	//		if ( err == PRO_TK_NO_ERROR )
	//		{
	//			err = ProElementValueSet ( ncseq_elem, value );
	//			ERROR_CHECK("UserNcsequenceCreate", "ProElementValueSet()",
	//				err);
	//		}
	//	}
	//	/*--------------------------------------------------------------------*\
	//	Add the element to the feature tree
	//	\*--------------------------------------------------------------------*/
	//	if ( err == PRO_TK_NO_ERROR )
	//	{
	//		err = ProElemtreeElementAdd (ncseq_elem_tree, NULL, ncseq_elem );
	//		ERROR_CHECK("UserNcsequenceCreate", "ProElemtreeElementAdd()",
	//			err);
	//	}

	//}

	//ProUtilElementtreePrint(ncseq_elem_tree, PRO_TEST_INFO_WINDOW, NULL );

	///*--------------------------------------------------------------------*\
	//Create the nc-sequence feature in the workpiece
	//\*--------------------------------------------------------------------*/
	//if (err == PRO_TK_NO_ERROR )
	//	err = UserWpieceSelCreate (mfg_model, PRO_TK_NOT_USED, (ProType)PRO_TK_NOT_USED, &selection);

	//if (err == PRO_TK_NO_ERROR)
	//{
	//	err = ProFeatureCreate(selection, ncseq_elem_tree,fd_opts,1,
	//		&ncseq_feature, &errors);
	//	ERROR_CHECK("UserNcsequenceCreate", "ProFeatureCreate()", err);

	//	if (err != PRO_TK_NO_ERROR)
	//	{
	//		ProTKFprintf(stderr, "Error in element %d\n", 
	//			errors.error_list[0].err_item_id);
	//	}
	//}

	///*--------------------------------------------------------------------*\
	//Free the feature tree
	//\*--------------------------------------------------------------------*/
	//err = ProElementFree(&ncseq_elem_tree);
	//ERROR_CHECK("UserNcsequenceCreate", "ProElementFree()", err);

	return err;
}
