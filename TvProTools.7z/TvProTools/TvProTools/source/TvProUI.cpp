#include "stdafx.h"

#include <ProToolkit.h>
#include <ProUITextarea.h>
#include <ProUILabel.h>
#include <ProUIInputpanel.h>
#include <ProUIList.h>
#include <ProUITab.h>
#include <ProUITree.h>
#include <ProUIInputpanel.h>
#include <ProUILayout.h>
#include <ProUICheckbutton.h>
#include <ProUIOptionmenu.h>
#include <TvProTkUtils.h>

/*********************************************************************/
ProError TvUITreeNodeVisitProc(char* dialog, char* component, char* node_name, ProError err, ProAppData appdata)
{
	CStringArray* p_nodes = (CStringArray*)appdata;
	CString node(node_name);
	p_nodes->Add(node);
	return PRO_TK_NO_ERROR;
}
/*********************************************************************/

ProError TvUIPrintDialogComponent(char* dlg_name, char* comp_name, CString &list, int t)
{
	char* comp_type;
	ProError err = ProUIComponentClassnameGet(dlg_name, comp_name, &comp_type);
	if (err) return err;

	CString prefix(L"");
	for (int i=0; i<t; i++)
		prefix += L"\t";

	CString item;
	item.Format(L"%scomp_name=%S, class_name=%S\r\n", prefix, comp_name, comp_type);
	list += item;

	if (strcmp(comp_type, "Label")==0)
	{
		wchar_t* value;
		err = ProUILabelTextGet(dlg_name, comp_name, &value);
		if (err) return err;		

		item.Format(L"%s\tLabelText=%s\r\n", prefix, value);
		ProWstringFree(value);
		list+=item;
	}
	else if (strcmp(comp_type, "Tab")==0)
	{
		int nLabels=0;
		wchar_t** pLabels;
		err = ProUITabLabelsGet(dlg_name, comp_name, &nLabels, &pLabels);
		if (err) return err;

		list += prefix;
		list += L"\tTabLabels=\r\n";

		for (int i=0; i<nLabels; i++)
		{
			item.Format(L"%s\t\tLabel_%02d: name=%s\r\n", prefix, i, pLabels[i]);
			list += item;
		}

		err = ProWstringarrayFree(pLabels, nLabels);
		if (err) return err;

		list += prefix;
		list += L"\tSelectedNames=\r\n";

		int nNames = 0;
		char** pNames;
		err = ProUITabSelectednamesGet(dlg_name, comp_name, &nNames, &pNames);
		if (err) return err;

		for (int i=0; i<nNames; i++)
		{
			item.Format(L"%s\t\tSelectedName_%02d: name=%S\r\n", prefix, i, pNames[i]);
			list += item;

			err = TvUIPrintDialogComponent(dlg_name, pNames[i], list, t+3);
			if (err) return err;
		}
		err = ProStringarrayFree(pNames, nNames);
		if (err) return err;
	}
	else if (strcmp(comp_type, "InputPanel")==0)
	{
		char* parent_name;
		err = ProUIInputpanelParentnameGet(dlg_name, comp_name, &parent_name);
		if (err) return err;

		wchar_t* value;
		err = ProUIInputpanelValueGet(dlg_name, comp_name, &value);
		if (err) return err;

		item.Format(L"%s\tInputpanelParent=%S, InputpanelValue=%s\r\n", prefix, parent_name, value);
		list+=item;

		err = ProStringFree(parent_name);
		if (err) return err;

		err = ProWstringFree(value);
		if (err) return err;
	}
	else if (strcmp(comp_type, "Layout")==0)
	{
		wchar_t* comp_text;
		err = ProUILayoutTextGet(dlg_name, comp_name, &comp_text);
		if (err) return err;

		wchar_t* comp_helptext;
		err = ProUILayoutHelptextGet(dlg_name, comp_name, &comp_helptext);
		if (err) return err;

		item.Format(L"%s\tcomp_text=%s, comp_helptext=%s\r\n", prefix, comp_text, comp_helptext);
		list += item;

		ProWstringFree(comp_text);
		ProWstringFree(comp_helptext);

		int nChildren=0;
		char** pChildren;
		err = ProUILayoutChildnamesGet(dlg_name, comp_name, &nChildren, &pChildren);
		if (err) return err;

		for (int i=0;i<nChildren; i++)
		{
			item.Format(L"%s\tchild_%02d: %S\r\n", prefix, i, pChildren[i]);
			list += item;

			err = TvUIPrintDialogComponent(dlg_name, pChildren[i], list, t+2);
			if (err) return err;
		}

		err = ProStringarrayFree(pChildren, nChildren);
		if (err) return err;
	}
	else if (strcmp(comp_type, "Textarea")==0)
	{
		wchar_t* comp_line;
		err = ProUITextareaValueGet(dlg_name, comp_name, &comp_line);
		if (err) return err;

		ProWstringFree(comp_line);
	}
	else if (strcmp(comp_type, "List")==0)
	{
		char** pSels;
		int nSels = 0;
		err = ProUIListSelectednamesGet(dlg_name, comp_name, &nSels, &pSels);
		if (err) return err;

		list += prefix;
		list += L"\tSelected names:\r\n";
		for (int i=0;i<nSels;i++)
		{
			item.Format(L"%s\t\t%s\r\n", prefix, pSels[i]);
			list+=item;
		}
		ProStringarrayFree(pSels, nSels);
	}
	else if (strcmp(comp_type, "PushButton")==0)
	{
		wchar_t* value;
		err = ProUIPushbuttonTextGet(dlg_name, comp_name, &value);
		if (err) return err;		

		item.Format(L"%s\tPushbuttonText=%s\r\n", prefix, value);
		list +=item;
		ProWstringFree(value);
	}
	else if (strcmp(comp_type, "CheckButton")==0)
	{
		wchar_t* value;
		err = ProUICheckbuttonTextGet(dlg_name, comp_name, &value);
		if (err) return err;

		item.Format(L"%s\tCheckbuttonText=%s\r\n", prefix, value);
		list +=item;
		ProWstringFree(value);
	}
	else if (strcmp(comp_type, "OptionMenu")==0)
	{
		list += prefix;
		list += L"\tSelectedNames=\r\n";

		int nNames = 0;
		char** pNames;
		err = ProUIOptionmenuSelectednamesGet(dlg_name, comp_name, &nNames, &pNames);
		if (err) return err;

		for (int i=0; i<nNames; i++)
		{
			item.Format(L"%s\t\tSelectedName_%02d: name=%S\r\n", prefix, i, pNames[i]);
			list += item;

			//err = PrintUIComponent(dlg_name, pNames[i], list, t+3);
			//if (err) return err;
		}
		err = ProStringarrayFree(pNames, nNames);
		if (err) return err;

		//
		wchar_t* value;
		err = ProUIOptionmenuValueGet(dlg_name, comp_name, &value);
		if (err) return err;

		item.Format(L"%s\tOptionmenuValue=%s", prefix, value);
		list += item;

		ProWstringFree(value);
	}
	else if (strcmp(comp_type, "Tree")==0)
	{
		// root
		char* root_node;
		err = ProUITreeTreerootnodeGet(dlg_name, comp_name, &root_node);
		if (err) return err;

		item.Format(L"%s\tTreerootnode=%S\r\n", prefix, root_node);
		list += item;

		/* find nodes */
		CStringArray nodes;
		err = ProUITreeNodesVisit(dlg_name, comp_name, root_node, TvUITreeNodeVisitProc, NULL, &nodes);
		if (err) return err;
		
		for (INT_PTR i=0; i<nodes.GetCount(); i++)
		{
			ProCharName node_name;
			strcpy_s(node_name, CW2A(nodes[i]));
			ProWstring node_label;
			err = ProUITreeNodeLabelGet(dlg_name, comp_name, node_name, &node_label);
			if (err) return err;

			item.Format(L"%s\t\tTreenode%02d: Name=%s, Label=%s\r\n", prefix, i, nodes[i], node_label);
			list += item;

			ProWstringFree(node_label);
		}

		ProStringFree(root_node);
		///////////////////////////////////////////////////////////////////////
		int nChildren=0;
		char** pChildren;
		err = ProUITreeChildnamesGet(dlg_name, comp_name, &nChildren, &pChildren);
		if (err) return err;

		for (int i=0;i<nChildren; i++)
		{
			item.Format(L"%s\tchild_%02d: %S\r\n", prefix, i, pChildren[i]);
			list += item;

			err = TvUIPrintDialogComponent(dlg_name, pChildren[i], list, t+2);
			if (err) return err;
		}

		err = ProStringarrayFree(pChildren, nChildren);
		if (err) return err;
	}

	ProStringFree(comp_type);
	list += L"\r\n";

	return PRO_TK_NO_ERROR;
}

ProError TvUIPrintDialog(char* dialog, CString &text)
{
	ProError err = PRO_TK_NO_ERROR;

	char** pComps;
	int nComps=0;
	err = ProUIDialogComponentsCollect(dialog, NULL, &nComps, &pComps);
	if (err) return err;

	for (int i=0; i<nComps; i++)
	{
		err = TvUIPrintDialogComponent(dialog, pComps[i], text, 0);
		if (err) return err;
	}
	err = ProStringarrayFree(pComps, nComps);
	if (err) return err;

	return err;
}

ProError TvUIPrintTree(char* dlg_name, char* tree_name, CString &text)
{
	ProError err = PRO_TK_NO_ERROR;


	return err;
}