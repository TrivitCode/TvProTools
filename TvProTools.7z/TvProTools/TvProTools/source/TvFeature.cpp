#include "stdafx.h"
#include "TvFeature.h"

#include <ProDtmCrv.h>

ProError TvGetTestSectionEntities(ProSection section);
ProError TvClearSectionEntities(ProSection section);
ProError TvPrintSecerrors(ProWSecerror *section_errors, CString &text);
ProError TvPrintSection(ProSection section, CString &text);


ProError TvRefreshSection(ProSection section)
{
	ProError err = PRO_TK_NO_ERROR;

	ProWSecerror sec_errors;
	err = ProSecerrorAlloc(&sec_errors);
	if (err) return err;

	CString text;

	// add dimension
	err = ProSectionAutodim(section, &sec_errors);
	if (err)
	{
		TvPrintSecerrors(&sec_errors, text);
		return err;
	}

	// regenerate
	err = ProSectionRegenerate(section, &sec_errors);
	if (err != 0)
	{
		TvPrintSecerrors(&sec_errors, text);
		return err; 
	}

	err = ProSecerrorFree(&sec_errors);
	return err;
}

ProError TvRemoveSectionEntities(ProSection section, int ids[], int ids_num)
{
	ProError err = PRO_TK_NO_ERROR;

	for (int i=0; i<ids_num; i++)
	{
		err = ProSectionEntityDelete(section, ids[i]);
		if (err) return err;
	}
	return err;
}



ProError TvCollectSectionEntityIds(ProSection section, int proj_ids[], int *p_proj_ids_num, int norm_ids[], int *p_norm_ids_num)
{
	ProError err;

	ProIntlist id_list;
	int id_num = 0;
	err = ProSectionEntityIdsGet(section, &id_list, &id_num);
	if (err) return err;

	int found_proj_ids = 0;
	int found_norm_ids = 0;
	for (int i=0; i<id_num; i++)
	{
		ProBoolean is_proj;
		err = ProSectionEntityIsProjection(section, id_list[i], &is_proj);
		if (err) return err;

		if (is_proj)
		{
			proj_ids[found_proj_ids] = id_list[i];
			found_proj_ids ++;
			continue;
		}

		norm_ids[found_norm_ids] = id_list[i];
		found_norm_ids ++;
	}

	(*p_proj_ids_num) = found_proj_ids;
	(*p_norm_ids_num) = found_norm_ids;

	err = ProArrayFree((ProArray*)&id_list);
	if (err) return err;

	return err;
}

/* Purpose : To print the Section errors and then free memory */ 
ProError TvPrintSecerrors(ProWSecerror *section_errors, CString &text)
{
	ProError err; 
	ProMsg error_message;
	int error_count; 
	int n_sec, error_id; 

	err = ProSecerrorCount ( section_errors, &n_sec ); 
	if (err) return err;

	text.Empty();

	CString line;
	line.Format(L"Number of errors in ProWSecerror = %d\r\n", n_sec);
	text += line;

	if ( err == PRO_TK_NO_ERROR )
	{
		for ( error_count = 0; error_count < n_sec; error_count++ )
		{
			err = ProSecerrorMsgGet ( *section_errors, error_count, error_message);
			if (err) return err;

			if ( err == PRO_TK_NO_ERROR )
			{
				err = ProSecerrorItemGet ( *section_errors, error_count, &error_id);
				if (err) return err;

				if ( err == PRO_TK_NO_ERROR )
				{
					line.Format(L" %s : Problem ID : %d \r\n", error_message, error_id );
					text += line;
				}
			}
		}
	}
	err = ProSecerrorFree ( section_errors ); 
	if (err) return err; 

	return err; 
}


ProError TvPrintSection(ProSection section, CString &text)
{
	ProError err = PRO_TK_NO_ERROR;

	ProIntlist id_list;
	int id_num = 0;
	err = ProSectionEntityIdsGet(section, &id_list, &id_num);
	if (err) return err;

	text.Empty();

	CString line = L"";
	for (int i=0; i<id_num; i++)
	{
		line.Format(L"Entity %02d:\r\n", i);
		text += line;

		ProBoolean is_proj;
		err = ProSectionEntityIsProjection(section, id_list[i], &is_proj);
		if (err) continue;

		if (is_proj)
		{
			line.Format(L"\t* This is Projection\r\n");
			text += line;
		}

		Pro2dEntdef *p_ent_def;
		err = ProSectionEntityGet(section, id_list[i], &p_ent_def);
		if (err) continue;

		switch (p_ent_def->type)
		{
		case PRO_2D_LINE:
			line.Format(L"\tType : PRO_2D_LINE\r\n");
			text += line;
			{
				Pro2dLinedef *p_line = (Pro2dLinedef*) p_ent_def;				
				line.Format(L"\tEnd1 : %f, %f\r\n", p_line->end1[0], p_line->end1[1]);
				text += line;
				line.Format(L"\tEnd2 : %f, %f\r\n", p_line->end2[0], p_line->end2[1]);
				text += line;
			}
			break;
		case PRO_2D_ARC:
			line.Format(L"\tType : PRO_2D_ARC\r\n");
			text += line;
			{
				Pro2dArcdef *p_arc = (Pro2dArcdef*) p_ent_def;				
				line.Format(L"\tCenter : %f, %f\r\n", p_arc->center[0], p_arc->center[1]);
				text += line;
				line.Format(L"\tRadius : %f\r\n", p_arc->radius);
				text += line;
				line.Format(L"\tStart angle : %f\r\n", p_arc->start_angle);
				text += line;
				line.Format(L"\tEnd angle : %f\r\n", p_arc->end_angle);
				text += line;
			}
			break;
		default:
			line.Format(L"\tType : %d\r\n", p_ent_def->type);
			text += line;
			break;
		}
	}

	return err;
}

ProError TvClearSectionEntities(ProSection section)
{
	ProError err = PRO_TK_NO_ERROR;

	ProIntlist id_list;
	int id_num = 0;
	err = ProSectionEntityIdsGet(section, &id_list, &id_num);
	if (err) return err;

	CString line = L"";
	for (int i=0; i<id_num; i++)
	{
		ProBoolean is_proj;
		err = ProSectionEntityIsProjection(section, id_list[i], &is_proj);
		if (err) continue;

		if (is_proj) continue;

		Pro2dEntdef *p_ent_def;
		err = ProSectionEntityGet(section, id_list[i], &p_ent_def);
		if (err) continue;

		switch (p_ent_def->type)
		{
		case PRO_2D_LINE:
			err = ProSectionEntityDelete(section, id_list[i]);
			if (err) continue;
			break;
		default:
			break;
		}
	}

	CString text;
	err = TvPrintSection(section, text);
	if (err) return err;

	return err;
}

ProError TvMoveSection(ProSection section, double x, double y)
{
	ProIntlist id_list;
	int id_num = 0;
	ProError err = ProSectionEntityIdsGet(section, &id_list, &id_num);
	if (err) return err;

	CString line = L"";
	for (int i=0; i<id_num; i++)
	{
		Pro2dEntdef *p_ent_def;
		err = ProSectionEntityGet(section, id_list[i], &p_ent_def);
		if (err) continue;

		// fix some value
		switch (p_ent_def->type)
		{
		case PRO_2D_LINE:
			{
				Pro2dLinedef *p_line = (Pro2dLinedef*) p_ent_def;				
				p_line->end1[0] += x;				
				p_line->end1[1] += y;
				p_line->end2[0] += x;				
				p_line->end2[1] += y;
			}
			break;
		default:
			break;
		}
	}

	ProWSecerror sec_errors;
	err = ProSecerrorAlloc(&sec_errors);
	if (err) return err;
	CString text;

	// solve
	err = ProSectionAutodim(section, &sec_errors);
	if (err)
	{
		TvPrintSecerrors(&sec_errors, text);
		return err;
	}

	// regenerate
	err = ProSectionRegenerate(section, &sec_errors);
	if (err != 0)
	{
		TvPrintSecerrors(&sec_errors, text);
		return err; 
	}

	err = ProSecerrorFree(&sec_errors);
	return err;
}

ProError TvGetTestSectionEntities(ProSection section)
{
	ProError err = PRO_TK_NO_ERROR;

	ProSection sec;
	ProName sec_name = L"SE4804078";
	err = ProMdlRetrieve(sec_name,PRO_MDL_2DSECTION,(ProMdl *)&sec);
	if (err) return err;	

	ProIntlist id_list;
	int id_num = 0;
	err = ProSectionEntityIdsGet(sec, &id_list, &id_num);
	if (err) return err;

	CString line = L"";
	for (int i=0; i<id_num; i++)
	{
		Pro2dEntdef *p_ent_def;
		err = ProSectionEntityGet(sec, id_list[i], &p_ent_def);
		if (err) continue;

		// fix some value
		switch (p_ent_def->type)
		{
		case PRO_2D_LINE:
			{
			}
			break;
		default:
			break;
		}

		int ent_id = 0;
		err = ProSectionEntityAdd(section, p_ent_def, &ent_id);
		if (err) continue;
	}

	err = ProMdlErase( (ProMdl) sec);
	if (err) return err;

	return err;
}



ProError TvFeatureRedefineSection(ProFeature *pFeat)
{
	ProError err = PRO_TK_NO_ERROR;

	ProElement tree;
	err = ProFeatureElemtreeExtract(pFeat, NULL, PRO_FEAT_EXTRACT_NO_OPTS, &tree);
	if (err) return err;

	// modify section
	/* path to PRO_E_SKETCHER element */ 
	ProElempathItem path_items[2];
	path_items[0].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	path_items[0].path_item.elem_id = PRO_E_STD_SECTION;
	path_items[1].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	path_items[1].path_item.elem_id = PRO_E_SKETCHER;

	// set path
	ProElempath path;
	err = ProElempathAlloc (&path);
	err = ProElempathDataSet (path, path_items, 2);

	// get PRO_E_SKETCHER
	ProElement sketch_element;
	err = ProElemtreeElementGet(tree, path, &sketch_element);
	if (err) return err;

	// get value
	ProValue value;
	err = ProElementValueGet(sketch_element, &value);
	if (err) return err;

	// get value data
	ProValueData value_data;
	err = ProValueDataGet(value, &value_data);
	if (err) return err;

	ProSection section;
	section = (ProSection) value_data.v.p;

	CString text;
	err = TvPrintSection(section, text);
	if (err) return err;

	int ids_proj[10];
	int ids_proj_num = 0;
	int ids_norm[100];
	int ids_norm_num = 0;
	err = TvCollectSectionEntityIds(section, ids_proj, &ids_proj_num, ids_norm, &ids_norm_num);
	if (err) return err;

	// modify section, use data from file
	err = TvGetTestSectionEntities(section);
	if (err) return err;
	err = TvRefreshSection(section);
	if (err) return err;
	err = TvPrintSection(section, text);
	if (err) return err;

	// remove old entities
	err = TvRemoveSectionEntities(section, ids_norm, ids_norm_num);
	if (err) return err;
	err = TvRefreshSection(section);
	if (err) return err;
	err = TvPrintSection(section, text);
	if (err) return err;

	// redefine feature
	ProErrorlist errors;
	ProFeatureCreateOptions opts[1];
	opts[0] = PRO_FEAT_CR_NO_OPTS;
	err = ProFeatureRedefine(NULL, pFeat, tree, opts, 1, &errors);
	if (err) return err;

	// free tree
	err = ProFeatureElemtreeFree(pFeat, tree);
	if (err) return err;

	return err;
}











//typedef struct mtrx_data{ 
//	ProVector x_axis[2];
//	ProVector y_axis[2];
//	ProMatrix sec_trf; 
//	ProMatrix sk_mtrx; 
//	ProSelection sk_plane;
//	double angle;
//}Matrix_data;
//
//
//ProError UserSectionBuild(ProSection section, ProSelection *sketch_refs);
//ProError UserSelectProjectionEntities(ProSelection **proj_refs);
//
//
ProError CreateSketchedDatumCurve()
{
	ProErrorlist            errors;
	ProMdl                  model;
	ProModelitem            model_item;
	ProSelection            model_sel;
	ProFeature              feature;
	ProFeatureCreateOptions opts[1];
	ProElempath             path;
	ProElempathItem         path_items[2];
	ProSection              section;
//	ProAsmcomppath          comp_path;
	ProAsmcomppath          *p_comp_path = NULL;
	ProValue                value;
//	double                  width;
//	double                  height;
//	double                  bite_radius;
//	double                  bite_height;
//	char                    name[PRO_NAME_SIZE];
//	ProBoolean              alloc;

	ProElement sketch_element; 
	ProElement created_elemtree; 

	ProElement pro_e_feature_tree;
	ProElement pro_e_feature_type;
	ProElement pro_e_curve_type;
	ProElement pro_e_std_section;
//	ProElement pro_e_std_sec_method;
	ProElement pro_e_std_sec_setup_plane;
	ProElement pro_e_std_sec_plane;
//	ProElement pro_e_sketcher;
	ProElement pro_e_std_sec_plane_view_dir;
	ProElement pro_e_std_sec_plane_orient_dir;
	ProElement pro_e_std_sec_plane_orient_ref;

	ProSelection *sketch_refs;

//	ProName wide_string;
	ProError status = PRO_TK_NO_ERROR;
	ProValueData value_data;
	ProSelection * p_select;
	int n_select;
	ProBoolean is_interactive = PRO_B_TRUE;

	//ProStringToWstring ( message_file, "utilities.txt" ); 

	//log_file = PTApplsUnicodeFopen ( "ug_sketched_curve.log", "w" ); 

	/*---------------------------------------------------------------*\
	Populating root element PRO_E_FEATURE_TREE 
	\*---------------------------------------------------------------*/
	// C_PRINT( " *** Processing Element PRO_E_FEATURE_TREE *** " );
	status = ProElementAlloc ( PRO_E_FEATURE_TREE, &pro_e_feature_tree ); 
	// C_LOG( " ProElementAlloc " );

	/*---------------------------------------------------------------*\
	Populating element PRO_E_FEATURE_TYPE 
	\*---------------------------------------------------------------*/
	// C_PRINT( " *** Processing Element PRO_E_FEATURE_TYPE *** " );
	status = ProElementAlloc ( PRO_E_FEATURE_TYPE, &pro_e_feature_type );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_INT;
	value_data.v.i = PRO_FEAT_CURVE; /* 949 */ 
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_feature_type, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_feature_tree, NULL, pro_e_feature_type );
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Populating element PRO_E_CURVE_TYPE
	\*---------------------------------------------------------------*/

	// C_PRINT( " *** Processing Element PRO_E_CURVE_TYPE *** " );
	status = ProElementAlloc ( PRO_E_CURVE_TYPE, &pro_e_curve_type );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_INT;
	value_data.v.i = PRO_CURVE_TYPE_SKETCHED; /* 0 */ 
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_curve_type, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_feature_tree, NULL, 
		pro_e_curve_type );
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Populating  element PRO_E_STD_SECTION
	\*---------------------------------------------------------------*/

	// C_PRINT( " *** Processing Element PRO_E_STD_SECTION *** " );
	status = ProElementAlloc ( PRO_E_STD_SECTION, &pro_e_std_section );
	// C_LOG( " ProElementAlloc" );
	status = ProElemtreeElementAdd ( pro_e_feature_tree, NULL, pro_e_std_section);
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Not required to populate   PRO_E_STD_SEC_METHOD 
	\*---------------------------------------------------------------*/

	/*
	// C_PRINT( " *** Processing Element PRO_E_STD_SEC_METHOD *** " );
	status = ProElementAlloc ( PRO_E_STD_SEC_METHOD, &pro_e_std_sec_method );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_INT;
	value_data.v.i = PRO_SEC_SKETCH ** 25;
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_std_sec_method, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_std_section, NULL, 
	pro_e_std_sec_method );
	// C_LOG( " ProElemtreeElementAdd" );

	*/
	/*---------------------------------------------------------------*\
	Populating element PRO_E_STD_SECTION 
	-> PRO_E_STD_SEC_SETUP_PLANE
	\*---------------------------------------------------------------*/
	// C_PRINT( " *** Processing Element PRO_E_STD_SEC_SETUP_PLANE *** " );
	status = ProElementAlloc ( PRO_E_STD_SEC_SETUP_PLANE, &pro_e_std_sec_setup_plane );
	// C_LOG( " ProElementAlloc" );
	status = ProElemtreeElementAdd ( pro_e_std_section, NULL, pro_e_std_sec_setup_plane );
	// C_LOG( " ProElemtreeElementAdd" );

	sketch_refs = ( ProSelection *) calloc ( 2, sizeof ( ProSelection ));

	/*---------------------------------------------------------------*\
	Populating element PRO_E_STD_SECTION 
	-> PRO_E_STD_SEC_SETUP_PLANE
	-> PRO_E_STD_SEC_PLANE
	\*---------------------------------------------------------------*/

	// C_PRINT( " *** Processing Element PRO_E_STD_SEC_PLANE *** " );
	//status = ProMessageDisplay ( message_file, "Select Surface for sketch placement");
	//// C_LOG( " ProMessageDisplay"  );
	//ProTKPrintf ( "Please select datum,surface,sldface,qltface_ID_5 type of Modelitem\n");
	status = ProSelect ( "datum,surface,sldface,qltface", 1, NULL, NULL, NULL, NULL, &p_select, &n_select );
	// C_LOG( " ProSelect" );
	if ( n_select <= 0 ) return (ProError)(ProError)-1; 
	else
	{
		status = ProSelectionCopy( p_select[0], &sketch_refs[0]);
		// C_LOG (" ProSelectionCopy ");
	}
	status = ProElementAlloc ( PRO_E_STD_SEC_PLANE, &pro_e_std_sec_plane );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_SELECTION;
	value_data.v.r = p_select[0];
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_std_sec_plane, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_std_sec_setup_plane, NULL, pro_e_std_sec_plane );
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Populating element PRO_E_STD_SECTION 
	-> PRO_E_STD_SEC_SETUP_PLANE
	-> PRO_E_STD_SEC_PLANE_VIEW_DIR
	\*---------------------------------------------------------------*/
	// C_PRINT( " *** Processing Element PRO_E_STD_SEC_PLANE_VIEW_DIR *** " );
	status = ProElementAlloc ( PRO_E_STD_SEC_PLANE_VIEW_DIR, &pro_e_std_sec_plane_view_dir );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_INT;
	value_data.v.i = PRO_SEC_VIEW_DIR_SIDE_ONE; /* 1 */ 
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_std_sec_plane_view_dir, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_std_sec_setup_plane, NULL, 
		pro_e_std_sec_plane_view_dir );
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Populating element PRO_E_STD_SECTION 
	-> PRO_E_STD_SEC_SETUP_PLANE
	-> PRO_E_STD_SEC_PLANE_ORIENT_DIR
	\*---------------------------------------------------------------*/
	// C_PRINT( " *** Processing Element PRO_E_STD_SEC_PLANE_ORIENT_DIR *** " );
	status = ProElementAlloc ( PRO_E_STD_SEC_PLANE_ORIENT_DIR, &pro_e_std_sec_plane_orient_dir );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_INT;
	value_data.v.i = PRO_SEC_ORIENT_DIR_UP; /* 1 */ 
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_std_sec_plane_orient_dir, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_std_sec_setup_plane, NULL, pro_e_std_sec_plane_orient_dir );
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Populating element PRO_E_STD_SECTION 
	-> PRO_E_STD_SEC_SETUP_PLANE
	-> PRO_E_STD_SEC_PLANE_ORIENT_REF
	\*---------------------------------------------------------------*/
	// C_PRINT( " *** Processing Element PRO_E_STD_SEC_PLANE_ORIENT_REF *** " );
	//status = ProMessageDisplay ( message_file, "Select Surface for sketch orientation");
	//// C_LOG( " ProMessageDisplay"  );
	//ProTKPrintf ( "Select datum,surface,sldface,qltface_ID_5 type of Modelitem\n");
	status = ProSelect ( "datum,surface,sldface,qltface", 1, NULL, NULL, NULL, NULL, &p_select, &n_select );
	// C_LOG( " ProSelect" );
	if ( n_select <= 0 ) return (ProError)(ProError)-1; 
	else
	{
		status = ProSelectionCopy( p_select[0], &sketch_refs[1]);
		// C_LOG (" ProSelectionCopy ");
	}

	status = ProElementAlloc ( PRO_E_STD_SEC_PLANE_ORIENT_REF, 
		&pro_e_std_sec_plane_orient_ref );
	// C_LOG( " ProElementAlloc " );
	value_data.type = PRO_VALUE_TYPE_SELECTION;
	value_data.v.r = p_select[0];
	status = ProValueAlloc ( &value );
	// C_LOG( " ProValueAlloc" );
	status = ProValueDataSet ( value, &value_data );
	// C_LOG( " ProValueDataSet" );
	status = ProElementValueSet ( pro_e_std_sec_plane_orient_ref, value );
	// C_LOG( " ProElementValueSet" );
	status = ProElemtreeElementAdd ( pro_e_std_sec_setup_plane, NULL, 
		pro_e_std_sec_plane_orient_ref );
	// C_LOG( " ProElemtreeElementAdd" );

	/*---------------------------------------------------------------*\
	Creating incomplete feature in the current model.
	\*---------------------------------------------------------------*/
	status = ProMdlCurrentGet (&model);
	if ( status != PRO_TK_NO_ERROR ) return (ProError)( status );
	status = ProMdlToModelitem( model, &model_item ); 
	status = ProSelectionAlloc (p_comp_path, &model_item,
		&model_sel);

	opts[0] = PRO_FEAT_CR_INCOMPLETE_FEAT;
	status = ProFeatureCreate (model_sel, pro_e_feature_tree, opts, 1,
		&feature, &errors);
	// C_LOG (" ProFeatureCreate"); 

	/* Using the element tree from created feature */ 
	status = ProFeatureElemtreeCreate ( &feature, &created_elemtree ); 
	// C_LOG (" ProFeatureElemtreeCreate"); 

	/*---------------------------------------------------------------*\
	Getting the initialized section element from the database.
	\*---------------------------------------------------------------*/
	/* path to PRO_E_SKETCHER element */ 
	path_items[0].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	path_items[0].path_item.elem_id = PRO_E_STD_SECTION;
	path_items[1].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	path_items[1].path_item.elem_id = PRO_E_SKETCHER;
	status = ProElempathAlloc (&path);
	status = ProElempathDataSet (path, path_items, 2);

	status = ProElemtreeElementGet ( created_elemtree, path, 
		&sketch_element);
	// C_LOG (" ProElemtreeElementGet PRO_E_SKETCHER "); 

	status = ProElementValueGet ( sketch_element, &value);
	// C_LOG (" ProElementValueGet PRO_E_SKETCHER "); 

	status = ProValueDataGet (value, &value_data);
	// C_LOG (" ProValueDataGet PRO_E_SKETCHER "); 
	section = (ProSection)value_data.v.p;

	/*---------------------------------------------------------------*\
	Creating a 3-D section 
	\*---------------------------------------------------------------*/

	status = TvGetTestSectionEntities ( section ); 
	// C_LOG ("UserSectionBuild"); 

	/*---------------------------------------------------------------*\
	Redefining the feature to make it complete.
	\*---------------------------------------------------------------*/
	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;

	status = ProFeatureRedefine (NULL, &feature, created_elemtree, opts, 1, &errors);
	// C_LOG (" ProFeatureRedefine"); 

	/*---------------------------------------------------------------*\
	Free up the allocated memory.
	\*---------------------------------------------------------------*/
	status = ProFeatureElemtreeFree (&feature, created_elemtree ); 
	// C_LOG (" ProFeatureElemtreeFree"); 

	status = ProElementFree (&pro_e_feature_tree ); 
	// C_LOG (" ProElementFree"); 

	return (ProError)(status);
}






/* =============================================================== *\
Function: UserSectionBuild(ProSection section, ProSelection *sketch_refs)
Purpose: Creates 3D section 
\* =============================================================== */
ProError UserSectionBuild(ProSection section, ProSelection *sketch_refs)
{
	ProError status = PRO_TK_NO_ERROR;

//
//	ProSelection *proj_ents;
//	int status, i, num_errors, err_counter, proj_ids[2];
//	int ctr_line_id, rt_line_id, lt_line_id, top_line_id, btm_line_id;
//	int upper_arc_id, lower_arc_id, ent_id[1], c_ent_id[2], proj_ent_id[2];
//	int ll_dim_id, tl_dim_id, ua_dim_id, la_dim_id, cl_dim_id, proj_dim_id[2];
//	ProWSecerror sec_errors;
//	Pro2dLinedef line;
//	Pro2dClinedef c_line;
//	Pro2dLinedef *left_linedef, *btm_linedef;
//	ProSectionPointType pt_type[1], proj_pt_type[2];
//	Pro2dArcdef arc;
//	Pro2dPnt place_pnt;
//	ProMsg wmsg;
//	char msg[PRO_PATH_SIZE];
//	double offsets[2];
//	Matrix_data matrix_data;
//
////	ProStringToWstring(msgfile, "msg_ug3dsketch.txt");
//
//
//	/* =============================================================== *\
//	Obtain projection entity handles as ProSelection structures
//	\* =============================================================== */
//	status = UserSelectProjectionEntities(&proj_ents);
//
//	// ERROR_CHECK("UserSelectrojectionEntities", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Project reference edges onto section
//	\* =============================================================== */
//
//	for (i = 0; i < 2; i++)
//	{
//		status = ProSectionEntityFromProjection(section, proj_ents[i], &proj_ids[i]);
//		// ERROR_CHECK("ProSectionEntityFromProjection", "UserSectionBuild", status);
//		if (status != PRO_TK_NO_ERROR) return (ProError)status;
//	}
//
//	/* =============================================================== *\
//	Create section csys from edges, and obtion transformation 
//	matrix between sketch plane csys and section csys
//	\* =============================================================== */
//
//	status = ProSectionEntityGet(section, proj_ids[0], (Pro2dEntdef **)&btm_linedef);
//	// ERROR_CHECK("ProSectionEntityGet", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	for (i = 0; i < 2; i++)
//	{
//		matrix_data.x_axis[0][i] = btm_linedef->end1[i];
//		matrix_data.x_axis[1][i] = btm_linedef->end2[i];
//		matrix_data.x_axis[i][2] = 0.0; 
//	}
//
//	status = ProSectionEntityGet(section, proj_ids[1], (Pro2dEntdef **)&left_linedef);
//	// ERROR_CHECK("ProSectionEntityGet", "UserSectionBuild", status);
//	if ( status != PRO_TK_NO_ERROR )
//		return (ProError)status; 
//
//	for (i = 0; i < 2; i++)
//	{
//		matrix_data.y_axis[0][i] = left_linedef->end1[i]; 
//		matrix_data.y_axis[1][i] = left_linedef->end2[i];
//		matrix_data.y_axis[i][2] = 0.0; 
//	}
//
//
//	status = ProSectionLocationGet(section, matrix_data.sk_mtrx);
//	// ERROR_CHECK("ProSectionLocationGet", "UserCreateTrfMatrix", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	status = ProSelectionCopy(sketch_refs[0], &(matrix_data.sk_plane));
//	// ERROR_CHECK("ProSelectionCopy", "UserSectionBuild", status) ;
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	status = UserCreateTrfMatrix(&matrix_data);
//	// ERROR_CHECK("UseCreateTrfMatrix", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Obtain offset values from projection entities
//	\* =============================================================== */
//
//	status = UserSelectOffsetDistances(offsets);
//	// ERROR_CHECK("UserSelectOffsetDistances", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add center line ...
//	\* =============================================================== */
//	c_line.type = PRO_2D_CENTER_LINE;
//	c_line.end1[0] = 0.0;
//	c_line.end1[1] = 0.0;
//	c_line.end2[0] = 0.0;
//	c_line.end2[1] = 1.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, c_line.end1, c_line.end1);
//	ProUtil2DPointTrans(matrix_data.sec_trf, c_line.end2, c_line.end2);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&c_line, &ctr_line_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 1", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add left vertical line ...
//	\* =============================================================== */
//	line.type = PRO_2D_LINE;
//	line.end1[0] = offsets[1];
//	line.end1[1] = offsets[0];
//	line.end2[0] = offsets[1];
//	line.end2[1] = offsets[0] + 50.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end1, line.end1);
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end2, line.end2);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&line, &lt_line_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 1", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add top line ...
//	\* =============================================================== */
//	line.type = PRO_2D_LINE;
//	line.end1[0] = offsets[1];
//	line.end1[1] = offsets[0] + 50.0;
//	line.end2[0] = offsets[1] + 25.0;
//	line.end2[1] = offsets[0] + 50.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end1, line.end1);
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end2, line.end2);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&line, &top_line_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 2", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add upper arc ...
//	\* =============================================================== */
//	arc.type = PRO_2D_ARC;
//	arc.center[0] = offsets[1] + 40.0; 
//	arc.center[1] = offsets[0] + 50.0;
//	arc.start_angle =  PI + matrix_data.angle;
//	arc.end_angle = 1.5*PI + matrix_data.angle;
//	arc.radius = 15.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, arc.center, arc.center);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&arc, &upper_arc_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 3", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add right vertical line ...
//	\* =============================================================== */
//	line.type = PRO_2D_LINE;
//	line.end1[0] = offsets[1] + 40.0;
//	line.end1[1] = offsets[0] + 35.0;
//	line.end2[0] = offsets[1] + 40.0;
//	line.end2[1] = offsets[0] + 10.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end1, line.end1);
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end2, line.end2);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&line, &rt_line_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 4", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add lower arc ...
//	\* =============================================================== */
//	arc.type = PRO_2D_ARC;
//	arc.center[0] = offsets[1] + 40.0; 
//	arc.center[1] = offsets[0];
//	arc.start_angle = 0.5*PI + matrix_data.angle;
//	arc.end_angle = PI + matrix_data.angle; 
//	arc.radius = 10.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, arc.center, arc.center);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&arc, &lower_arc_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 5", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add bottom line ...
//	\* =============================================================== */
//	line.type = PRO_2D_LINE;
//	line.end1[0] = offsets[1] + 30.0;
//	line.end1[1] = offsets[0];
//	line.end2[0] = offsets[1];
//	line.end2[1] = offsets[0];
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end1, line.end1);
//	ProUtil2DPointTrans(matrix_data.sec_trf, line.end2, line.end2);
//
//	status = ProSectionEntityAdd(section, (Pro2dEntdef*)&line, &btm_line_id);
//	// ERROR_CHECK("UserSectionEntityAdd - 6", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add dimension for left line
//	\* =============================================================== */
//
//	ent_id[0] = lt_line_id;
//	pt_type[0] = PRO_ENT_WHOLE;
//	place_pnt[0] = offsets[1] - 2.0;
//	place_pnt[1] = offsets[0] + 25.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, ent_id, pt_type, 1, PRO_TK_DIM_LINE, place_pnt, &ll_dim_id); 
//	// ERROR_CHECK("ProSecdimCreate - 1", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add dimension for top line
//	\* =============================================================== */
//
//	ent_id[0] = top_line_id;
//	pt_type[0] = PRO_ENT_WHOLE;
//	place_pnt[0] = offsets[1] + 13.0;
//	place_pnt[1] = offsets[0] + 52.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, ent_id, pt_type, 1, PRO_TK_DIM_LINE, place_pnt, &tl_dim_id); 
//	// ERROR_CHECK("ProSecdimCreate - 2", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add dimension for upper arc
//	\* =============================================================== */
//
//	ent_id[0] = upper_arc_id;
//	pt_type[0] = PRO_ENT_WHOLE;
//	place_pnt[0] = offsets[1] + 42.0;
//	place_pnt[1] = offsets[0] + 42.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, ent_id, pt_type, 1, PRO_TK_DIM_RAD, place_pnt, &ua_dim_id); 
//	// ERROR_CHECK("ProSecdimCreate - 3", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add dimension for lower arc
//	\* =============================================================== */
//
//	ent_id[0] = lower_arc_id;
//	pt_type[0] = PRO_ENT_WHOLE;
//	place_pnt[0] = offsets[1] +42.0;
//	place_pnt[1] = offsets[0] + 5.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, ent_id, pt_type, 1, PRO_TK_DIM_RAD, place_pnt, &la_dim_id); 
//	// ERROR_CHECK("ProSecdimCreate - 4", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add section dimension between center line and left line
//	\* =============================================================== */
//
//	c_ent_id[0] = ctr_line_id;
//	c_ent_id[1] = lt_line_id;
//	proj_pt_type[0] = PRO_ENT_WHOLE;	
//	proj_pt_type[1] = PRO_ENT_WHOLE;	
//	place_pnt[0] = offsets[1] - 2.0;
//	place_pnt[1] = offsets[0] + 15.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, c_ent_id, proj_pt_type, 2, PRO_TK_DIM_LINE_LINE, place_pnt, &cl_dim_id);
//	// ERROR_CHECK("ProSecdimCreate - 5", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	status = ProSecdimValueSet(section, cl_dim_id, offsets[1]);
//	// ERROR_CHECK("ProSecdimValueSet", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add section dimension between center line and left projection
//	entity
//	\* =============================================================== */
//
//	proj_ent_id[0] = ctr_line_id;
//	proj_ent_id[1] = proj_ids[1];
//	proj_pt_type[0] = PRO_ENT_WHOLE;	
//	proj_pt_type[1] = PRO_ENT_WHOLE;	
//	place_pnt[0] = -2.0;
//	place_pnt[1] = 15.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, proj_ent_id, proj_pt_type, 2, PRO_TK_DIM_LINE_LINE, place_pnt, &proj_dim_id[0]);
//	// ERROR_CHECK("ProSecdimCreate - 5", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	status = ProSecdimValueSet(section, proj_dim_id[0], 0.0);
//	// ERROR_CHECK("ProSecdimValueSet", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Add section dimension between bottom proj ent and bottom line
//	\* =============================================================== */
//
//	proj_ent_id[0] = btm_line_id;
//	proj_ent_id[1] = proj_ids[0];
//	proj_pt_type[0] = PRO_ENT_WHOLE;	
//	proj_pt_type[1] = PRO_ENT_WHOLE;	
//	place_pnt[0] = offsets[1] + 20.0;
//	place_pnt[1] = offsets[0] - 3.0;
//
//	ProUtil2DPointTrans(matrix_data.sec_trf, place_pnt, place_pnt);
//
//	status = ProSecdimCreate(section, proj_ent_id, proj_pt_type, 2, PRO_TK_DIM_LINE_LINE, place_pnt, &proj_dim_id[1]);
//	// ERROR_CHECK("ProSecdimCreate - 6", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	status = ProSecdimValueSet(section, proj_dim_id[1], offsets[0]);
//	// ERROR_CHECK("ProSecdimValueSet", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	/* =============================================================== *\
//	Solve and regenerate the section
//	\* =============================================================== */
//
//	status = ProSecerrorAlloc(&sec_errors);
//	// ERROR_CHECK("ProSecerrorAlloc", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR) return (ProError)status;
//
//	status = ProSectionSolve(section, &sec_errors);
//	if (status != 0)
//	{
//		UserSecerrorPrint (  &sec_errors );
//		return (ProError)status; 
//	}
//
//	status = ProSectionRegenerate(section, &sec_errors);
//	if (status != 0)
//	{
//		UserSecerrorPrint (  &sec_errors );
//		return (ProError)status; 
//	}
//
//	status = ProSelectionFree(&(matrix_data.sk_plane));
//	// ERROR_CHECK("ProSelectionFree", "UserSectionBuild", status);
//
//	free(temp1);
//	free(temp2);
//
//	temp1 = NULL;
//	temp2 = NULL; 
//
	return (ProError) (status);
}





///* =============================================================== *\
//Function: UserSelectProjectionEntities
//Purpose: Select projection entity references from existing geometry
//\* =============================================================== */
//ProError UserSelectProjectionEntities(ProSelection **proj_refs)
//{
//
//	ProSelection *sel;
//	int num_sel;
//	ProError status;
//
//	if (temp2== NULL)
//		temp2= (ProSelection *)calloc(2, sizeof(ProSelection));
//	/* =============================================================== *\
//	Prompt user to select reference geometry
//	\* =============================================================== */
//	ProStringToWstring(msgfile, "msg_ug3dsketch.txt");
//
//	//status = ProMessageDisplay(msgfile, "USER Select first projection reference (bottom edge of sketch plane)");
//	// ERROR_CHECK("ProMessageDisplay", "UserSectionBuild", status);
//	status = ProSelect("edge", 1, NULL, NULL, NULL, NULL, &sel, &num_sel);
//	// ERROR_CHECK("ProSelect", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR || num_sel < 1)
//		return(status);
//	status = ProSelectionCopy(sel[0], &temp2[0]);
//	// ERROR_CHECK("ProSelectionCopy", "UserSectionBuild", status);
//
//	//status = ProMessageDisplay(msgfile, "USER Select second projection reference (left edge of sketch plane)");
//	// ERROR_CHECK("ProMessageDisplay", "UserSectionBuild", status);
//	status = ProSelect("edge", 1, NULL, NULL, NULL, NULL, &sel, &num_sel);
//	// ERROR_CHECK("ProSelect", "UserSectionBuild", status);
//	if (status != PRO_TK_NO_ERROR || num_sel < 1)
//		return(status);
//	status = ProSelectionCopy(sel[0], &temp2[1]);
//	// ERROR_CHECK("ProSelectionCopy", "UserSectionBuild", status);
//
//	*proj_refs = temp2;
//
//	return(status);
//
//}

