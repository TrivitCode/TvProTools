#include "stdafx.h"
#include "TvProUtils.h"

#include <TvSolid.h>
#include <TvMath.h>
#include <TvFeature.h>

ProError AssembleComponent(ProAssembly assembly, ProPath comp_path);

ProError TvAsmcompConstrFixSet2(ProAsmcomp* pComp)
{
	TvFeature feat(*pComp);
	ProError err = feat.Initialize();
	if (err) return err;

	//feat.SetAsmcomppath();

	ProElement root;
	err = feat.GetElemTree(&root);

	// Getting the initialized section element from the database
/*
  <PRO_E_COMPONENT_CONSTRAINTS type="array">
    <PRO_E_COMPONENT_CONSTRAINT type="compound">
      <PRO_E_COMPONENT_CONSTR_TYPE type="int">13</PRO_E_COMPONENT_CONSTR_TYPE>
      <PRO_E_COMPONENT_COMP_CONSTR_REF type="selection"></PRO_E_COMPONENT_COMP_CONSTR_REF>
      <PRO_E_COMPONENT_ASSEM_CONSTR_REF type="selection">
        <PRO_XML_REFERENCE type="reference">
          <PRO_XML_REFERENCE_STATUS type="int">PRO_REF_MISSING</PRO_XML_REFERENCE_STATUS>
          <PRO_XML_REFERENCE_ID type="id">0</PRO_XML_REFERENCE_ID>
        </PRO_XML_REFERENCE>
      </PRO_E_COMPONENT_ASSEM_CONSTR_REF>
      <PRO_E_COMPONENT_CONSTR_REF_OFFSET type="double">0.000000</PRO_E_COMPONENT_CONSTR_REF_OFFSET>
      <PRO_E_COMPONENT_USER_DATA type="wstring"></PRO_E_COMPONENT_USER_DATA>
      <PRO_E_COMPONENT_CONSTR_ATTR type="int">0</PRO_E_COMPONENT_CONSTR_ATTR>
      <PRO_E_COMPONENT_COMP_ORIENT type="int">1</PRO_E_COMPONENT_COMP_ORIENT>
      <PRO_E_COMPONENT_ASSM_ORIENT type="int">1</PRO_E_COMPONENT_ASSM_ORIENT>
      <PRO_E_COMPONENT_CONSTR_SET_ID type="int">-1</PRO_E_COMPONENT_CONSTR_SET_ID>
      <PRO_E_COMPONENT_SLOT_EXTRA_CRV_REF type="multivalue">
      </PRO_E_COMPONENT_SLOT_EXTRA_CRV_REF>
    </PRO_E_COMPONENT_CONSTRAINT>
  </PRO_E_COMPONENT_CONSTRAINTS>
*/
	// path to PRO_E_SKETCHER element
	ProElempathItem path_items[1];
	path_items[0].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	path_items[0].path_item.elem_id = PRO_E_COMPONENT_CONSTRAINTS;

	ProElempath path;
	err = ProElempathAlloc(&path);
	if (err) return err;

	err = ProElempathDataSet(path, path_items, 1);
	if (err) return err;

	ProElement constraints_element;
	err = ProElemtreeElementGet(root, path, &constraints_element);
	if (err) return err;

	// add PRO_E_COMPONENT_CONSTRAINT
	ProElement constraint_elem;
	err = ProElementAlloc(PRO_E_COMPONENT_CONSTRAINT, &constraint_elem);
	if (err) return err;

	err = ProElemtreeElementAdd(constraints_element, NULL, constraint_elem);
	if (err) return err;

	//	-> PRO_E_COMPONENT_CONSTR_TYPE
	err = TvUtils::TvElementTreeElementAdd(constraint_elem, NULL, PRO_E_COMPONENT_CONSTR_TYPE, PRO_ASM_FIX);
	if (err) return err;
	
	CString err_msg;
	err = feat.Redefine(err_msg);
	if (err) return err;

	return PRO_TK_NO_ERROR;
}

ProError ConstrTest()
{
	ProError err;

	TvSolid solid;
	err = solid.InitializeCurrent();



	return PRO_TK_NO_ERROR;
}

ProError AssemblyTest()
{
	ProError err;

	ProMdl mdl;
	err = TvUtils::TvMdlAssemblyCreate(L"TEST1", &mdl, true);
	//err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	ProAssembly assembly = (ProAssembly) mdl;

	err = AssembleComponent(assembly, L"D:\\Test\\PEBEC\\work\\2011.08.02_v2.9\\Beispiel9\\work\\04l_100_010_f-kopf_mlb_130kw.asm.1");
	if (err) return err;

	err = AssembleComponent(assembly, L"D:\\Test\\PEBEC\\work\\2011.08.02_v2.9\\Beispiel9\\work\\04l_100_011_n-einspri_t6.asm.2");
	if (err) return err;

	//err = AssembleComponent(assembly, L"D:\\Test\\PEBEC\\work\\2011.08.02_v2.9\\Beispiel9\\work\\03l_905_061_f-pgsk.prt.1");
	//if (err) return err;

	//int win_id;
	//err = ProObjectwindowCreate(L"TEST1", PRO_ASSEMBLY, &win_id);
	//if (err) return err;

	// display and set to active
	err = ProMdlDisplay(mdl);
	if (err) return err;

	err = ProTreetoolRefresh(mdl);

	//err = ProWindowActivate(win_id);

	return PRO_TK_NO_ERROR;
}

ProError AssembleComponent(ProAssembly assembly, ProPath comp_path)
{
	//ProError err;

	//ProMdl mdl_part;
	//err = TvUtils::TvMdlRetrieve(comp_path, true, &mdl_part);
	//if (err) return err;

	//ProMatrix ma;
	//TvUtils::TvMatrixInit(ma);

	//ProAsmcomp asm_comp;
	//err = ProAsmcompAssemble(assembly, (ProSolid)mdl_part, ma, &asm_comp);
	//if (err) return err;

	//err = TvUtils::TvAsmcompConstrFixSet(&asm_comp);
	//if (err) 
	//{
	//	err = TvAsmcompConstrFixSet2(&asm_comp);
	//	if (err) return err;
	//}

	return PRO_TK_NO_ERROR;
}