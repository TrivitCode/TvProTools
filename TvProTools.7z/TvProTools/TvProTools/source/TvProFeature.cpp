#include "stdafx.h"

//#include <ProDataShareFeat.h>
//#include <ProQuilt.h>

#include "TvProUtils.h"

//// Hilfsfunktionen:
//ProError TvElementTreeElementAdd  (ProElement elemTree, ProElempath elemPath, ProElemId elemId, double value);
//ProError TvElementTreeElementAdd  (ProElement elemTree, ProElempath elemPath, ProElemId elemId, int value);
//ProError TvElementTreeElementAdd  (ProElement elemTree, ProElempath elemPath, ProElemId elemId, wchar_t *value);
//ProError TvElementTreeReferenceAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProReference ref);
//ProError TvElementTreeModelitemAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProModelitem mi);
//ProError TvElementTreeMdlAdd      (ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProMdl ref_mdl);
//ProError TvElementTreeCsysAdd     (ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProCsys csys, ProMdl csys_owner);
//ProError TvGeomitemVisitAction(ProGeomitem *p_handle, ProError status, ProAppData  app_data);
//ProError TvCreateCopyGeom(ProMdl mdl, ProMdl ref_mdl, ProCsys ref_csys, ProCsys csys, 
//						  ProFeature pub_geom, ProName name, ProFeature *pFeat);
//ProError TvCreateSolidify(ProMdl mdl, ProQuilt quilt, ProName name, ProFeature *pFeat);
//
//// export functions:
//ProError CreateCopyGeom(ProMdl mdl,						// model handle of actual model
//						ProPath refModel,				// name of reference model for copygeom
//						ProName refModelCsys,			// name of Coordinatesystem in referencemodel used for assembling
//						ProName refCsys,				// name of Coordinatesystem in actual model used for assembling
//						ProName refPubli,				// publiziergeometrie in referencemodel
//						ProName cgName,					// used for naming of copygeom element
//						ProFeature* copyGeomFeature);	// resulting element
//
//ProError CreateSolidify(ProFeature feat_quilt,			// feature handle of quilt
//						ProName name,					// name of solidify feature
//						ProFeature *pFeat);				// output handle of created feature
//
//
//
//
///************************************************/
//// main function to create copy geometry
//ProError CreateCopyGeom(ProMdl mdl,	ProPath refModel, ProName refModelCsys, ProName refCsys,
//						ProName refPubli, ProName cgName, ProFeature* copyGeomFeature)
//
//{
//	// Get ref model
//	ProMdl ref_mdl;
//	ProError err = ProMdlLoad(refModel, PRO_MDL_UNUSED, PRO_B_FALSE, &ref_mdl);
//	if (err) return err;
//
//	// Get csys in ref_mdl
//	ProModelitem mi_ref_csys;
//	err = ProModelitemByNameInit(ref_mdl, PRO_CSYS, refModelCsys, &mi_ref_csys);
//	if (err) return err;
//
//	ProCsys ref_csys;
//	err = ProCsysInit( (ProSolid) mi_ref_csys.owner, mi_ref_csys.id, &ref_csys);
//	if (err) return err;
//
//	// Get csys of current model
//	ProModelitem mi_csys;
//	err = ProModelitemByNameInit(mdl, PRO_CSYS, refCsys, &mi_csys);
//	if (err) return err;
//
//	ProCsys csys;
//	err = ProCsysInit( (ProSolid) mi_csys.owner, mi_csys.id, &csys);
//	if (err) return err;
//
//	// get pub.geom
//	ProFeature pub_geom;
//	err = ProModelitemByNameInit(ref_mdl, PRO_FEATURE, refPubli, &pub_geom);
//	if (err) return err;
//
//	// create copy geom feature using elemtree
//	err = TvCreateCopyGeom(mdl, ref_mdl, ref_csys, csys, pub_geom, cgName, copyGeomFeature);
//	if (err) return err;
//
//	return PRO_TK_NO_ERROR;
//}
//
//ProError CreateSolidify(ProFeature feat_quilt, ProName name, ProFeature *pFeat)
//{
//	ProError err = PRO_TK_NO_ERROR;
//
//	ProQuilt quilt;
//	// get ProQuilt from ProFeature
//	// step: use ProFeatureGeomitemVisit to visit all geomitems
//	//		 convert geomitem to ProQuilt
//	ProGeomitem *pGeomitems = NULL;
//	err = ProArrayAlloc(0, sizeof(ProGeomitem), 1, (ProArray*)&pGeomitems);
//	if (err) return err;
//
//	err = ProFeatureGeomitemVisit(&feat_quilt, PRO_QUILT, TvGeomitemVisitAction, NULL, (ProAppData)&pGeomitems);
//	if (err)
//	{
//		ProArrayFree((ProArray*)&pGeomitems);
//		return err;
//	}
//
//	// get size
//	int nGeomitems = 0;
//	err = ProArraySizeGet( (ProArray) pGeomitems, &nGeomitems);
//	if (err) return err;
//
//	if (nGeomitems == 0)
//		return PRO_TK_E_NOT_FOUND;
//
//	if (nGeomitems > 1)
//		return PRO_TK_GENERAL_ERROR;
//
//	err = ProGeomitemToQuilt(&pGeomitems[0], &quilt);
//	if (err) return err;
//
//	err = ProArrayFree((ProArray*)&pGeomitems);
//	if (err) return err;
//
//	// create solidify
//	err = TvCreateSolidify(feat_quilt.owner, quilt, name, pFeat);
//	if (err) return err;
//
//	return PRO_TK_NO_ERROR;
//}
//


/********************************************************/
/* Hilfsfunktionen										*/
/********************************************************/
//
//ProError TvElementTreeElementAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, double value)
//{
//	ProElement elem;
//	ProError err = ProElementAlloc( elemId, &elem );
//	if (err) return err;
//
//	err = ProElementDoubleSet( elem, value);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd( elemTree, elemPath, elem );
//	return err;
//}
//
//ProError TvElementTreeElementAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, int value)
//{
//	ProElement elem;
//	ProError err = ProElementAlloc( elemId, &elem );
//	if (err) return err;
//
//	err = ProElementIntegerSet( elem, value);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd( elemTree, elemPath, elem );
//	return err;
//}
//
//ProError TvElementTreeElementAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, wchar_t *value)
//{
//	ProElement elem;
//	ProError err = ProElementAlloc( elemId, &elem );
//	if (err) return err;
//
//	err = ProElementWstringSet( elem, value);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd( elemTree, elemPath, elem );
//	return err;
//}
//
//ProError TvElementTreeReferenceAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProReference ref)
//{
//	ProElement elem;
//	ProError err = ProElementAlloc( elemId, &elem );
//	if (err) return err;
//
//	err = ProElementReferenceSet( elem, ref);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd( elemTree, elemPath, elem );
//	return err;
//}
//
//ProError TvElementTreeModelitemAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProModelitem mi)
//{
//	ProSelection sel;
//	ProError err = ProSelectionAlloc(NULL, &mi, &sel);
//	if (err) return err;
//
//	ProReference ref;
//	err = ProSelectionToReference(sel, &ref);
//	if (err) return err;
//
//	err = ProSelectionFree(&sel);
//	if (err) return err;
//
//	ProElement elem;
//	err = ProElementAlloc( elemId, &elem );
//	if (err) return err;
//
//	err = ProElementReferenceSet( elem, ref);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd( elemTree, elemPath, elem );
//	if (err) return err;
//
//	err = ProReferenceFree(ref);
//	if (err) return err;
//
//	return err;
//
//}
//
//ProError TvElementTreeMdlAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProMdl ref_mdl)
//{
//	ProModelitem mi_ref_mdl;
//	ProError err = ProMdlToModelitem(ref_mdl, &mi_ref_mdl);
//	if (err) return err;
//
//	err = TvElementTreeModelitemAdd(elemTree, elemPath, elemId, mi_ref_mdl);
//	return err;
//}
//
//ProError TvElementTreeCsysAdd(ProElement elemTree, ProElempath elemPath, ProElemId elemId, ProCsys csys, ProMdl csys_owner)
//{
//	ProGeomitem gi;
//	ProError err = ProCsysToGeomitem((ProSolid) csys_owner, csys, &gi);
//	if (err) return err;
//
//	err = TvElementTreeModelitemAdd(elemTree, elemPath, elemId, gi);
//	return err;
//}

//ProError TvCreateCopyGeom(ProMdl mdl, ProMdl ref_mdl, ProCsys ref_csys, ProCsys csys, 
//						  ProFeature pub_geom, ProName name, ProFeature *pFeat)
//{
//	// create elements tree
//	// allocate root element PRO_E_FEATURE_TREE
//	ProElement tree;
//	ProError err = ProElementAlloc(PRO_E_FEATURE_TREE, &tree);
//	if (err) return err;
//
//	// allocate element PRO_E_FEATURE_TYPE
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_FEATURE_TYPE, PRO_FEAT_GEOM_COPY);
//	if (err) return err;
//
//	// Populating element PRO_E_STD_FEATURE_NAME
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_STD_FEATURE_NAME, name);
//	if (err) return err;
//
//	// set sub_type: PRO_E_CG_FEAT_SUB_TYPE = PRO_CG_COPY_GEOM
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_CG_FEAT_SUB_TYPE, PRO_CG_COPY_GEOM);
//	if (err) return err;
//
//	// set refs_type: PRO_E_CG_REFS_TYPE = 0
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_CG_REFS_TYPE, 0);
//	if (err) return err;
//
//	/***************************************************/
//	// START: set location
//	/*-------------------------------------------------*/
//	// insert element: PRO_E_CG_LOCATION
//	ProElement location;
//	err = ProElementAlloc(PRO_E_CG_LOCATION, &location);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd(tree, NULL, location);
//	if (err) return err;
//
//	// set location type:
//	err = TvElementTreeElementAdd(location, NULL, PRO_E_DSF_EXT_LOCAL_TYPE, PRO_DSF_PLACE_EXTERNAL);
//	if (err) return err;
//
//	// set reference model
//	err = TvElementTreeMdlAdd(location, NULL, PRO_E_DSF_SEL_REF_MDL, ref_mdl);
//	if (err) return err;
//
//	// insert placement
//	ProElement location_placement;
//	err = ProElementAlloc(PRO_E_CG_PLACEMENT, &location_placement);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd(location, NULL, location_placement);
//	if (err) return err;
//
//	// set placement_type
//	err = TvElementTreeElementAdd(location_placement, NULL, PRO_E_CG_PLACE_TYPE, PRO_CG_PLC_CSYS_CSYS);
//	if (err) return err;
//
//	// set reference of placement: two csys
//	ProElement location_placement_csys;
//	err = ProElementAlloc(PRO_E_CG_CSYS_PLACE, &location_placement_csys);
//	if (err) return err;
//
//	err = ProElemtreeElementAdd(location_placement, NULL, location_placement_csys);
//	if (err) return err;
//
//	// set local csys
//	err = TvElementTreeCsysAdd(location_placement_csys, NULL, PRO_E_CG_PLC_LOCAL_CSYS, csys, mdl);
//	if (err) return err;
//
//	// set external csys
//	err = TvElementTreeCsysAdd(location_placement_csys, NULL, PRO_E_CG_PLC_EXT_CSYS, ref_csys, ref_mdl);
//	if (err) return err;
//
//	/*-------------------------------------------------*/
//	// END: set location
//	/***************************************************/
//	
//	/***************************************************/
//	// START: set reference: pub.geom
//	/*-------------------------------------------------*/
//	// insert element: PRO_E_CG_LOCATION
//	ProElement pg_or_refs;
//	err = ProElementAlloc(PRO_E_CG_PG_OR_REFS, &pg_or_refs);
//
//	err = ProElemtreeElementAdd(tree, NULL, pg_or_refs);
//	if (err) return err;
//
//	// set reference of pub.geom: PRO_E_CG_PUBD_GEOM
//	err = TvElementTreeModelitemAdd(pg_or_refs, NULL, PRO_E_CG_PUBD_GEOM, pub_geom);
//	if (err) return err;
//	
//	/*-------------------------------------------------*/
//	// END: set reference: pub.geom
//	/***************************************************/
//	
//	// set PRO_E_DSF_DEPENDENCY
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_DSF_DEPENDENCY, PRO_DSF_DEPENDENT);
//	if (err) return err;
//
//	/***************************************************/
//	// END: set element tree
//	/***************************************************/
//	
//	// create feature
//	ProModelitem mi_mdl;
//	err = ProMdlToModelitem(mdl, &mi_mdl);
//	if (err) return err;
//
//	ProSelection sel_mdl;
//	err = ProSelectionAlloc(NULL, &mi_mdl, &sel_mdl);
//	if (err) return err;
//
//	ProFeatureCreateOptions opts[1];
//	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;
//
//	ProErrorlist errors;
//	err = ProFeatureCreate(sel_mdl, tree, opts, 1, pFeat, &errors);
//	
//	// free tree first
//	ProElementFree(&tree);
//	
//	return err;
//}

//ProError TvCreateSolidify(ProMdl mdl, ProQuilt quilt, ProName name, ProFeature *pFeat)
//{
//	// create elements tree
//	// allocate root element PRO_E_FEATURE_TREE
//	ProElement tree;
//	ProError err = ProElementAlloc(PRO_E_FEATURE_TREE, &tree);
//	if (err) return err;
//
//	// set element PRO_E_FEATURE_TYPE: PRO_FEAT_PROTRUSION
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_FEATURE_TYPE, PRO_FEAT_PROTRUSION);
//	if (err) return err;
//
//	// set element PRO_E_STD_FEATURE_NAME: name
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_STD_FEATURE_NAME, name);
//	if (err) return err;
//
//	// set element PRO_E_FEATURE_FORM: PRO_USE_SURFS
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_FEATURE_FORM, PRO_USE_SURFS);
//	if (err) return err;
//
//	// set element PRO_E_PATCH_QUILT: ProQuilt
//	ProGeomitem gi_quilt;
//	err = ProQuiltToGeomitem( (ProSolid) mdl, quilt, &gi_quilt);
//	if (err) return err;
//
//	err = TvElementTreeModelitemAdd(tree, NULL, PRO_E_PATCH_QUILT, gi_quilt);
//	if (err) return err;
//
//	// set element PRO_E_PATCH_TYPE: 917
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_PATCH_TYPE, 917);
//	if (err) return err;
//
//	// set element PRO_E_PATCH_MATERIAL_SIDE: 1
//	err = TvElementTreeElementAdd(tree, NULL, PRO_E_PATCH_MATERIAL_SIDE, 1);
//	if (err) return err;
//
//	/***************************************************/
//	// END: set element tree
//	/***************************************************/
//	
//	// create feature
//	ProModelitem mi_mdl;
//	err = ProMdlToModelitem(mdl, &mi_mdl);
//	if (err) return err;
//
//	ProSelection sel_mdl;
//	err = ProSelectionAlloc(NULL, &mi_mdl, &sel_mdl);
//	if (err) return err;
//
//	ProFeatureCreateOptions opts[1];
//	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;
//
//	ProErrorlist errors;
//	err = ProFeatureCreate(sel_mdl, tree, opts, 1, pFeat, &errors);
//	
//	// free tree first
//	ProElementFree(&tree);
//	
//	return err;
//}
//
//ProError TvGeomitemVisitAction(ProGeomitem *p_handle, ProError status, ProAppData  app_data)
//{
//	ProGeomitem **ppGeomitem = (ProGeomitem**) app_data;
//
//	ProError err = ProArrayObjectAdd( (ProArray*)ppGeomitem, -1, 1, p_handle);
//	if (err) return err;
//
//	return PRO_TK_NO_ERROR;
//}