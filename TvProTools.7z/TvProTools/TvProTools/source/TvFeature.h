#pragma once

#include <TvProTkUtils.h>


using namespace TvUtils;

ProError CreateSketchedDatumCurve();
ProError TvFeatureRedefineSection(ProFeature *pFeat);
ProError TvPrintSection(ProSection section, CString &text);
ProError TvMoveSection(ProSection section, double x, double y);