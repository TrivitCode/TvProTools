#pragma once

#include <ProToolkit.h>
#include <ProToolkitDll.h>

#include <ProAsmcomp.h>
#include <ProCsys.h>
#include <ProFeature.h>
#include <ProFeattype.h>
#include <ProMessage.h>
#include <ProModelitem.h>

#include <ProSelection.h>

#include <ProUtil.h>
#include <ProWstring.h>

#include <TvUtils.h>
#include <TvProErrors.h>
#include <TvProTkUtils.h>
using namespace TvUtils;

#include <TvFeature.h>

static ProFileName MSG_FILE  = L"tvprotools_msg.txt";

ProError TvXMLSave();
ProError TvConstrGet();
ProError TvCsysDataGet();
ProError TvCsysAxisGetAngle();
ProError TvUIPrintDialog(char* dlg_name, CString &text);

//ProError CreateCopyGeom(ProMdl mdl,						// model handle of actual model
//						ProPath refModel,				// name of reference model for copygeom
//						ProName refModelCsys,			// name of Coordinatesystem in referencemodel used for assembling
//						ProName refCsys,				// name of Coordinatesystem in actual model used for assembling
//						ProName refPubli,				// publiziergeometrie in referencemodel
//						ProName cgName,					// used for naming of copygeom element
//						ProFeature* copyGeomFeature);	// resulting element
//
//ProError CreateSolidify(ProFeature feat_quilt,			// feature handle of quilt
//						ProName name,					// name of solidify feature
//						ProFeature *pFeat);				// output handle of created feature


ProError UITest();

void SetWatchTimer(BOOL enable);

ProError ConstrTest();
ProError AssemblyTest();
//ProError IETest();

ProError CheckATBFeats(void);

