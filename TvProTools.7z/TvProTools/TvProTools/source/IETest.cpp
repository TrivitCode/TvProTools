#include "stdafx.h"
#include "TvProUtils.h"

#include < atlbase.h >
#include < mshtml.h >
#include < oleacc.h >
#pragma comment ( lib, "oleacc" )

BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam)
{
	TCHAR szClassName[100];

	::GetClassName( hwnd,  szClassName,  sizeof(szClassName) );
	if ( _tcscmp( szClassName,  _T("Internet Explorer_Server") ) == 0 )
	{
		*(HWND*)lParam = hwnd;
		return FALSE;  //
	}
	else 
		return TRUE;  // 
}

BOOL GetDocPtr(HWND hWnd, IHTMLDocument2** ppDoc)
{
	HWND hWndChild=NULL;
	::EnumChildWindows( hWnd, EnumChildProc, (LPARAM)&hWndChild );
	if(NULL == hWndChild) return FALSE;

	UINT nMsg = ::RegisterWindowMessage( _T("WM_HTML_GETOBJECT") );
	LRESULT lRes;
	::SendMessageTimeout( hWndChild, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (PDWORD_PTR) &lRes );

	if (::ObjectFromLresult(lRes, IID_IHTMLDocument2, 0, (LPVOID *)ppDoc) != S_OK)
		return FALSE;

	return TRUE;
}

void ModifyValue(CComPtr<IHTMLDocument2> spDoc) 
{
	// form
	CComPtr<IHTMLElementCollection> pElems;
	if (spDoc->get_all(&pElems) != S_OK)
		return;

	long n_elems = 0;
	if (pElems->get_length(&n_elems) != S_OK)
		return;

	for (long i=0; i<n_elems; i++)
	{
		CComDispatchDriver spInputElement;
		CComVariant vName, vVal, vId, vTitle;

		if (pElems->item(CComVariant(i), CComVariant(), &spInputElement) != S_OK)
			continue;

		if (spInputElement.GetPropertyByName(L"id", &vId) == S_OK)
		{
			if (vId == (CComVariant)"keywordkeywordField_SearchTextBox")
			{
				vVal = L"A*";
				spInputElement.PutPropertyByName(L"value", &vVal);
			}
		}
	}  

	return;
}

void ClickSearch(CComPtr<IHTMLDocument2> spDoc) 
{
	// form
	IHTMLElementCollection* pForms;
	if (spDoc->get_forms(&pForms) != S_OK)
		return;

	long n_forms = 0;
	if (pForms->get_length(&n_forms) != S_OK)
		return;

	for (long i=0; i<n_forms; i++)
	{
		IDispatch* spForm;
		if (pForms->item(CComVariant(i), CComVariant(), &spForm) != S_OK)
			continue;

		CComQIPtr<IHTMLFormElement> spFormElement = spForm; 
		spForm->Release(); 

		long nElemCount = 0;
		if (spFormElement->get_length(&nElemCount)!=S_OK)
			continue;

		for (long j=0; j<nElemCount; j++)
		{
			CComDispatchDriver spInputElement;
			CComVariant vName, vVal, vId, vTitle;

			if (spFormElement->item(CComVariant(j), CComVariant(), &spInputElement) != S_OK)
				continue;

			if (spInputElement.GetPropertyByName(L"name", &vName) == S_OK)
			{
				if (vName == (CComVariant)"search")
				{
					CComQIPtr<IHTMLElement> spButton(spInputElement);
					spButton->click();
					break;
				}
			}		
		}
	}

	return;
}


ProError IETest()
{
	HWND hWndTop = ::FindWindow(NULL, L"Pro/ENGINEER");
	
	CComPtr<IHTMLDocument2> spDoc;
	if (!GetDocPtr(hWndTop, &spDoc))
		return PRO_TK_GENERAL_ERROR;

	ModifyValue(spDoc);
	ClickSearch(spDoc);

	return PRO_TK_NO_ERROR;
}