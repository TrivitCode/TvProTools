#pragma once

BOOL SetHook(void);