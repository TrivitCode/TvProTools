#include "stdafx.h"

#include <ProToolkit.h>
#include <ProMessage.h>
#include <ProUICmd.h>
#include <ProUIDialog.h>
#include <TvProTkUtils.h>

#include "TvHelperToolsApp.h"

static ProFileName MENU_FILE = L"tvhelpertools_menu.txt";
static ProFileName MSG_FILE = L"tvhelpertools_msg.txt";
static const char APP_VERSION[] = "0.1";
static const wchar_t APP_NAME[] = L"TvHelperTools";
static char PROE_VERSION[32];
static char PROE_BUILD[32];

//#ifdef _DEBUG
//	CMemoryState g_oldMemState, g_newMemState, g_diffMemState;
//#endif

//$(AppName)* g_pApp = NULL;

ProError TvUpdateParameterProc();

/////////////////////////////////////////////////////////////////////////
// Pro/TOOLKIT initialization
//
extern "C" int user_initialize(int argc,			/** Number of arguments		**/
							   char *argv[],		/** Pro/E arguments			**/
							   char *proe_vsn,		/** Pro/E version			**/
							   char *build,			/** Pro/E build				**/
							   wchar_t err_buff[])	/** Error buffer			**/
{
	ProError err = PRO_TK_NO_ERROR;
	
	// add a command: main command
	uiCmdCmdId cmd_main;
	err = ProCmdActionAdd("TvUpdateParameterProc", (uiCmdCmdActFn)TvUpdateParameterProc, uiProe2ndImmediate, NULL, 
						  PRO_B_TRUE, PRO_B_TRUE, &cmd_main);
	if( err != PRO_TK_NO_ERROR )
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_PROTK_ERR", "ProCmdActionAdd", TvUtils::TvProErrors[-err]);
		return err;
	}

	// designate command
	err = ProCmdDesignate(cmd_main, "TV_MENU_UPDATE_PARAMS", "TV_MENU_UPDATE_PARAMS_TOOLTIP", "TV_MENU_UPDATE_PARAMS_DESC", MENU_FILE);
	if (err)
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_PROTK_ERR", "ProCmdDesignate", TvUtils::TvProErrors[-err]);
		return err;
	}

	err = ProCmdIconSet(cmd_main, "tvupdateparams.png");
	if (err)
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_PROTK_ERR", "ProCmdIconSet", TvUtils::TvProErrors[-err]);
		return err;
	}

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	ProMessageDisplay(MSG_FILE, "TV_APP_REG_SUCCESSED", APP_VERSION);

	// save pro_version and pro_build
	strcpy_s(PROE_VERSION, proe_vsn);
	strcpy_s(PROE_BUILD, build);

	return 0;
}

extern "C" void user_terminate()
{
	ProMessageDisplay(MSG_FILE, "TV_APP_EXIT");

	//if (g_pApp)
	//{
	//	delete g_pApp;
	//	g_pApp=NULL;
	//}

//#ifdef _DEBUG  
//	g_newMemState.Checkpoint();  
//	if (g_diffMemState.Difference(g_oldMemState, g_newMemState))
//	{
//		TRACE("Memory leak detected!\n");
//		ProMessageDisplay(MSG_FILE, "TV_APP_MSGW", L"Memory leak detected!");
//	}
//	else
//	{
//		TRACE("No Memory leak detected!\n");
//		ProMessageDisplay(MSG_FILE, "TV_APP_MSGW", L"No Memory leak detected!");
//	}
//#endif 
}

ProError TvUpdateParameterProc()
{
	ProError err = PRO_TK_NO_ERROR;

	// create app
#ifdef _DEBUG
	CMemoryState _oldMemState, _newMemState, _diffMemState;
	_oldMemState.Checkpoint();
#endif

	TvHelperToolsApp* pApp = new TvHelperToolsApp();
	pApp->SetAppName(APP_NAME);
	pApp->SetAppVersion(CA2W(APP_VERSION));
	pApp->SetMsgFile(MSG_FILE);
	pApp->SetProeVersion(CA2W(PROE_VERSION), CA2W(PROE_BUILD));

	if (!pApp->Initialize())
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_INIT_FAILED");
		return PRO_TK_APP_INIT_FAIL;
	}

	BOOL ret = pApp->UpdateParameters();

	if (ret == 0)
		err = PRO_TK_NO_ERROR;
	else
		err = PRO_TK_GENERAL_ERROR;

	delete pApp;
	pApp = NULL;

#ifdef _DEBUG  
	_newMemState.Checkpoint();  
	if (_diffMemState.Difference(_oldMemState, _newMemState))
	{
		TRACE("Memory leak detected!\n");
		ProMessageDisplay(MSG_FILE, "TV_APP_MSGW", L"Memory leak detected!");
	}
	else
	{
		TRACE("No Memory leak detected!\n");
		ProMessageDisplay(MSG_FILE, "TV_APP_MSGW", L"No Memory leak detected!");
	}
#endif 

	return err;
}


