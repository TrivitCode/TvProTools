#include "stdafx.h"

#include <ProUIDialog.h>
#include <ProUIPushbutton.h>
#include <ProUIDrawingarea.h>
#include <ProUILabel.h>
#include <ProUIInputpanel.h>
#include <ProUIList.h>
#include <ProUITextarea.h>
#include <ProSrfcollection.h>
#include <TvMath.h>

#include "TvGalvSurfaceApp.h"
#include "TvGalvSurfaceProc.h"

struct handle_data {
    unsigned long process_id;
    HWND window_handle;
};

BOOL CALLBACK EnumWindowsProc1(HWND hWnd, LPARAM lParam)
{
	handle_data* p_data = (handle_data*)lParam;

	DWORD nProcId = 0;
	GetWindowThreadProcessId(hWnd, &nProcId);

	p_data->process_id = nProcId;
	p_data->window_handle = hWnd;

	// find Notepad++
	TCHAR szClassName[1024];
	::GetClassName(hWnd,  szClassName,  1024);
	if ( _tcscmp( szClassName,  _T("HCS16139P") ) != 0 )
		return TRUE;

	::GetWindowText(hWnd, szClassName, 1024);
	CString text(szClassName);
	if (text.Find(L"Active")<0)
		return TRUE;

	return FALSE;
}

BOOL CALLBACK EnumVisibleChildWndProc1(HWND hwnd, LPARAM lParam)
{
	// check is window visiable
	if (!IsWindowVisible(hwnd))
		return TRUE;

	*(HWND*)lParam = hwnd;
	return FALSE;
}

//////////////////////////////////////////////
//
TvGalvSurfApp::TvGalvSurfApp()
{
	strcpy_s(m_szUIDlgName, "TvGalvsurfaceGUI");
	strcpy_s(m_szUIDrwAreaName1, "DrawingArea1");
	strcpy_s(m_szUIDrwAreaName2, "DrawingArea2");
	strcpy_s(m_szUIDrwAreaName3, "DrawingArea3");
	strcpy_s(m_szUIDrwAreaName4, "DrawingArea4");
	strcpy_s(m_szUIListName, "List1");
	strcpy_s(m_szUITextDlgName, "TvGalvsurfaceDlg");
	strcpy_s(m_szUITextAreaName, "TvGalvsurfaceTextArea");

	m_pSolid = NULL;
	m_AreaTotal = 0.0;
	m_AreaHoles = 0.0;
	m_AreaCrossfeed = 0.0;
	m_AreaFixed = 0.0;
	m_Collection = NULL;
	m_CurrentListPos = -1;
	m_Weight = 0.0;
}

TvGalvSurfApp::~TvGalvSurfApp()
{
}

bool TvGalvSurfApp::Initialize(void)
{
	if (!TvProDllApp::Initialize())
		return false;

	// initialize crossfeed list
	if (!InitializeCrossfeeds())
	{
		LogErr(L"Initialize Crossfeeds List failed: %s", GetLastError());
		return false;
	}

	return true;
}

bool TvGalvSurfApp::InitializeUI()
{
	ProError err = ProUIDialogCreate(m_szUIDlgName, m_szUIDlgName);
	if (err)
	{
		LogProErr(L"ProUIDialogCreate", err);
		return false;
	}

	// set close action
	err = ProUIDialogCloseActionSet(m_szUIDlgName, (ProUIAction)TvGalvSurfaceDialogCloseAction, NULL);
	if (err)
	{
		LogProErr(L"ProUIDialogCloseActionSet", err);
		return false;
	}

	err = ProUIDialogStartlocationSet(m_szUIDlgName, PROUITOP_RIGHT);
	if (err)
	{
		LogProErr(L"ProUIDialogStartlocationSet", err);
		return false;
	}

	int pos_x_null = 12;
	int pos_y_label_null = 12, pos_y_inputpanel_null=10, pos_y_button_null=10;
	int offset_y = 27;
	
	
	///////////////////////////////////////////////////////////////////////
	// DrawingArea1
	//
	//
	int OffsetInputpanel1 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel1", 161);
	int LengthInputpanel1 = m_pOptions->GetInt(L"UI", L"LengthInputpanel1", 10);
	//

	// line1
	// add component: Label1
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Label1");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label1", pos_x_null, pos_y_label_null);
	err = ProUILabelTextSet(m_szUIDlgName, "Label1", GetTextMsg("TV_MENU_GALV_TOTAL_SURFACE").GetBuffer());

	// add component: Inputpanel1
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Inputpanel1");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel1", OffsetInputpanel1, pos_y_inputpanel_null);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel1", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel1", LengthInputpanel1);
	err = ProUIInputpanelInputActionSet(m_szUIDlgName, "Inputpanel1", (ProUIAction)TvGalvSurfaceInputpanelInputAction, NULL);

	// add component: PushButton1
	int OffsetPushButton1 = m_pOptions->GetInt(L"UI", L"OffsetPushButton1", 294);
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName1, "PushButton1");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton1", OffsetPushButton1, pos_y_button_null);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton1", L"Fix...");
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton1", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// line2: 1_5
	// add component: Label1_5
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Label1_5");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label1_5", 90, pos_y_label_null+offset_y/*39*/);
	err = ProUILabelTextSet(m_szUIDlgName, "Label1_5", GetTextMsg("TV_MENU_GALV_WEIGHT").GetBuffer());

	// add component: Inputpanel1_5
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Inputpanel1_5");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel1_5", OffsetInputpanel1, pos_y_inputpanel_null+offset_y);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel1_5", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel1_5", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel1_5");

	// line3 -> moved from line 4
	// add component: Label4
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Label4");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label4", pos_x_null, pos_y_label_null+offset_y*2);
	err = ProUILabelTextSet(m_szUIDlgName, "Label4", GetTextMsg("TV_MENU_GALV_EFFECTIVE_SURF").GetBuffer());

	//
	int OffsetInputpanel4 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel4", 236);
	int LengthInputpanel4 = m_pOptions->GetInt(L"UI", L"LengthInputpanel4", 10);
	//
	// add component: Inputpanel4
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName1, "Inputpanel4");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel4", OffsetInputpanel4, pos_y_inputpanel_null+offset_y*2);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel4", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel4", LengthInputpanel4);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel4");

	///////////////////////////////////////////////////////////////////////
	// DrawingArea4
	//
	// line4: moved from line 2
	// add component: Label2
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Label2");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label2", pos_x_null, pos_y_label_null);
	err = ProUILabelTextSet(m_szUIDlgName, "Label2", GetTextMsg("TV_MENU_GALV_HOLE_SURF").GetBuffer());

	// add component: Inputpanel2
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Inputpanel2");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel2", OffsetInputpanel1, pos_y_inputpanel_null);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel2", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel2", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel2");

	// line5: moved from line 3
	// add component: Label3
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Label3");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label3", 102, pos_y_label_null+offset_y);
	err = ProUILabelTextSet(m_szUIDlgName, "Label3", GetTextMsg("TV_MENU_GALV_REF").GetBuffer());

	// add component: Inputpanel3
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Inputpanel3");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel3", OffsetInputpanel1, pos_y_inputpanel_null+offset_y);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel3", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel3", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel3");

	// add component: PushButton3
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName4, "PushButton3");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton3", OffsetPushButton1, pos_y_button_null+offset_y);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton3", GetTextMsg("TV_MENU_GALV_SELECT").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton3", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// line5: moved from line3_5
	// add component: Label3_5
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Label3_5");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label3_5", 73, pos_y_label_null+offset_y*2);
	err = ProUILabelTextSet(m_szUIDlgName, "Label3_5", GetTextMsg("TV_MENU_GALV_ADJ").GetBuffer());

	// add component: Inputpanel3_5
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName4, "Inputpanel3_5");
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel3_5", OffsetInputpanel1, pos_y_inputpanel_null+offset_y*2);
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel3_5", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel3_5", LengthInputpanel1);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel3_5");

	///////////////////////////////////////////////////////////////////////
	// DrawingArea2
	//
	// line5
	// add component: Label5
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label5");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label5", pos_x_null, 12);
	err = ProUILabelSizeSet(m_szUIDlgName, "Label5", 200, 24);
	err = ProUILabelTextSet(m_szUIDlgName, "Label5", GetTextMsg("TV_MENU_GALV_BORE_HOLES").GetBuffer());

	// line6 left
	int WidthList1 = m_pOptions->GetInt(L"UI", L"WidthList1", 194);
	// add component: List1
	err = ProUIDrawingareaListAdd(m_szUIDlgName, m_szUIDrwAreaName2, m_szUIListName);
	err = ProUIListPositionSet(m_szUIDlgName, m_szUIListName, pos_x_null, 30);
	err = ProUIListSizeSet(m_szUIDlgName, m_szUIListName, WidthList1, 102);
	err = ProUIListSelectActionSet(m_szUIDlgName, m_szUIListName, (ProUIAction)TvGalvSurfaceListClickAction, NULL);
	err = ProUIListTriggerhighlightActionSet(m_szUIDlgName, m_szUIListName, (ProUIAction)TvGalvSurfaceListMouseoverAction, NULL);

	// line6 right
	//
	int OffsetInputpanel6 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel6", 218);
	int LengthInputpanel6 = m_pOptions->GetInt(L"UI", L"LengthInputpanel6", 5);

	// add component: Label6
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label6");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label6", OffsetInputpanel6, 30);
	err = ProUILabelTextSet(m_szUIDlgName, "Label6", GetTextMsg("TV_MENU_GALV_DIAMETER").GetBuffer());

	// add component: Inputpanel6
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel6");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel6", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel6", OffsetInputpanel6, 48);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel6", LengthInputpanel6);
	err = ProUIInputpanelInputActionSet(m_szUIDlgName, "Inputpanel6", (ProUIAction)TvGalvSurfaceInputpanelInputAction, NULL);

	// add component: PushButton6
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName2, "PushButton6");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton6", OffsetPushButton1, 48);
	err = ProUIPushbuttonSizeSet(m_szUIDlgName, "PushButton6", 24, 24);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton6", GetTextMsg("TV_MENU_GALV_SELECT").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton6", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// line7
	// add component: Label7
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label7");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label7", OffsetInputpanel6, 76);
	err = ProUILabelTextSet(m_szUIDlgName, "Label7", GetTextMsg("TV_MENU_GALV_INTERSPERSION").GetBuffer());

	// add component: Inputpanel7
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel7");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel7", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel7", OffsetInputpanel6, 94);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel7", LengthInputpanel6);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel7");

	// line8
	// add component: Label8
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label8");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label8", OffsetInputpanel6, 122);
	err = ProUILabelTextSet(m_szUIDlgName, "Label8", GetTextMsg("TV_MENU_GALV_COMP_LEN").GetBuffer());

	// add component: Inputpanel8
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel8");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel8", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel8", OffsetInputpanel6, 140);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel8", LengthInputpanel6);
	err = ProUIInputpanelInputActionSet(m_szUIDlgName, "Inputpanel8", (ProUIAction)TvGalvSurfaceInputpanelInputAction, NULL);
	//err = ProUIInputpanelBackgroundcolorSet(m_szUIDlgName, "Inputpanel8", PRO_UI_COLOR_RED);

	// add component: Label8_1
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label8_1");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label8_1", OffsetPushButton1, 143);
	err = ProUILabelTextSet(m_szUIDlgName, "Label8_1", GetTextMsg("TV_MENU_GALV_CHECK_DIMENSION").GetBuffer());

	// line9
	// add component: Label9
	err = ProUIDrawingareaLabelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Label9");
	err = ProUILabelPositionSet(m_szUIDlgName, "Label9", pos_x_null, 143);
	err = ProUILabelTextSet(m_szUIDlgName, "Label9", GetTextMsg("TV_MENU_GALV_INTERSP_SURF").GetBuffer());

	//
	int OffsetInputpanel9 = m_pOptions->GetInt(L"UI", L"OffsetInputpanel9", 124);
	int LengthInputpanel9 = m_pOptions->GetInt(L"UI", L"LengthInputpanel9", 5);

	// add component: Inputpanel9
	err = ProUIDrawingareaInputpanelAdd(m_szUIDlgName, m_szUIDrwAreaName2, "Inputpanel9");
	err = ProUIInputpanelInputtypeSet(m_szUIDlgName, "Inputpanel9", PROUIINPUTTYPE_WSTRING);
	err = ProUIInputpanelPositionSet(m_szUIDlgName, "Inputpanel9", OffsetInputpanel9, 140);
	err = ProUIInputpanelColumnsSet(m_szUIDlgName, "Inputpanel9", LengthInputpanel9);
	err = ProUIInputpanelReadOnly(m_szUIDlgName, "Inputpanel9");

	///////////////////////////////////////////////////////////////////////
	// DrawingArea3
	//
	// line 10
	// add component: PushButton10_1
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName3, "PushButton10_1");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton10_1", 26, 12);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton10_1", L"OK");
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton10_1", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// add component: PushButton10_2
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName3, "PushButton10_2");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton10_2", 148, 12);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton10_2", GetTextMsg("TV_MENU_GALV_CANCEL").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton10_2", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	// add component: PushButton10_3
	err = ProUIDrawingareaPushbuttonAdd(m_szUIDlgName, m_szUIDrwAreaName3, "PushButton10_3");
	err = ProUIPushbuttonPositionSet(m_szUIDlgName, "PushButton10_3", 270, 12);
	err = ProUIPushbuttonTextSet(m_szUIDlgName, "PushButton10_3", GetTextMsg("TV_MENU_GALV_RESET").GetBuffer());
	err = ProUIPushbuttonActivateActionSet(m_szUIDlgName, "PushButton10_3", (ProUIAction)TvGalvSurfacePushbuttonClickAction, NULL);

	return true;
}


bool TvGalvSurfApp::Run(void)
{
	// create dialog
	if (!InitializeUI())
	{
		LogErr(L"Initialize UI failed: %s", GetLastError());
		return false;
	}

	// initialze default values
	if (!InitializeDefaults())
	{
		LogErr(L"Initialize default values failed: %s", GetLastError());
		return false;
	}

	ProError err = ProUIDialogShow(m_szUIDlgName);
	if (err)
	{
		LogProErr(L"ProUIDialogShow", err);
		return false;
	}

	int status = 0;
	err = ProUIDialogActivate(m_szUIDlgName, &status);
	if (err)
	{
		LogProErr(L"ProUIDialogActivate", err);
		return false;
	}

	// clear
	err = ProUIDialogDestroy(m_szUIDlgName);
	if (err)
		LogProErr(L"ProUIDialogDestroy", err, CA2W(m_szUIDlgName));
	else
		LogMsg(L"Dialog %S destroyed", m_szUIDlgName);

	if (m_pSolid)
	{
		delete m_pSolid;
		m_pSolid = NULL;
	}

	if (m_Collection)
	{
		ProCollectionFree(&m_Collection);
		m_Collection = NULL;
	}

	return true;
}

bool TvGalvSurfApp::InitializeDefaults()
{
	// get total surface
	if (m_pSolid) delete m_pSolid;

	m_pSolid = new TvSolid();
	TvProApp::CopyPropertiesTo(m_pSolid);
	ProError err = m_pSolid->InitializeCurrent();
	if (err)
	{
		LogProErr(L"TvSolid::InitializeCurrent", err);
		return false;
	}
	m_AreaTotal = m_pSolid->GetSurfaceArea()/10000.0;
	m_AreaFixed = m_AreaTotal;
	m_Weight    = m_pSolid->GetWeight();

	// set 
	CString Value;
	Value.Format(L"%.5g", m_AreaTotal);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel1", Value.GetBuffer());
	Value.Format(L"%.5g", m_AreaFixed);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel4", Value.GetBuffer());
	Value.Format(L"%.5g", m_Weight);
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel1_5", Value.GetBuffer());

	return true;
}

bool TvGalvSurfApp::SelectSurfaces()
{
	ProError err = PRO_TK_NO_ERROR;

	// hide main dialog
	ProUIDialogHide(m_szUIDlgName);
	// repaint window
	ProWindowRepaint(PRO_VALUE_UNUSED);

	// let user to select a surface as reference of hole surface

	// show main dialog
	ProUIDialogShow(m_szUIDlgName);

	LogMsg(L"Retrieve Hole Surfaces done!");
	return true;
}

bool TvGalvSurfApp::ExtractCollectionSurfaces()
{
	return true;
}

bool TvGalvSurfApp::AddReferenceAsHoleFrontSurface(ProReference ref)
{
	return true;
}

bool TvGalvSurfApp::UpdateList(bool SaveSelection)
{
	return true;
}

bool TvGalvSurfApp::OnListClick(char *dialog, char *component, ProAppData data)
{
	return true;
}

bool TvGalvSurfApp::OnListMouseover(char *dialog, char *component, ProAppData data)
{
	return true;
}

bool TvGalvSurfApp::HighlightListItem(int nItem, bool highlight)
{
	return true;
}

bool TvGalvSurfApp::InitializeCrossfeeds()
{
	return true;
}

bool TvGalvSurfApp::UpdateArea()
{
	return true;
}

bool TvGalvSurfApp::OnInputpanelInput(char *dialog, char *component, ProAppData data)
{
	return true;
}

bool TvGalvSurfApp::OnPushbuttonClick(char *dialog, char *component, ProAppData data)
{
	ProError err;

	CString comp(component);
	LogMsg(L"Click event from Pushbutton %s", comp);

	if (comp.CompareNoCase(L"PushButton1")==0)	// this is to call TvGewindeFlaeche
	{
		double fixed_total_area;
		if (!FixTotalArea(&fixed_total_area))
		{
			LogErr(L"Fix total area failed");
		}
		m_AreaTotal = fixed_total_area;
		CString Value;
		Value.Format(L"%.5g", m_AreaTotal);
		err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel1", Value.GetBuffer());
	}
	else if (comp.CompareNoCase(L"PushButton3")==0)	// this is to select surfaces
	{
		SelectSurfaces();
	}
	else if (comp.CompareNoCase(L"PushButton6")==0)		// this is to select diameter (dimension)
	{
	}
	else if (comp.CompareNoCase(L"PushButton10_1")==0)	// Button OK: save/update parameter, close dialog
	{
		OnOK(dialog);
	}
	else if (comp.CompareNoCase(L"PushButton10_2")==0)	// Button Abbrechen: close dialog
	{
		OnCancel(dialog);
	}
	else if (comp.CompareNoCase(L"PushButton10_3")==0)	// Button Zur�cksetzen: re-initialize default values
	{
		ProWindowRepaint(PRO_VALUE_UNUSED);
		ResetUI();
	}
	else if (comp.CompareNoCase(L"OK")==0)	// Button OK: close all
	{
		ProWindowRepaint(PRO_VALUE_UNUSED);
		ProUIDialogExit(dialog, PRO_TK_CONTINUE);
	}

	if (!UpdateArea())
		LogErr(L"Update area faield");

	return true;
}

void TvGalvSurfApp::OnCancel(char *dialog)
{
	if (strcmp(dialog, m_szUIDlgName)==0)
		ProWindowRepaint(PRO_VALUE_UNUSED);
	ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
}

void TvGalvSurfApp::OnOK(char *dialog)
{
	int win_id;
	ProWindowCurrentGet(&win_id);

	CString url = L"http://www.baidu.com";
	ProWindowURLShow(win_id, url.GetBuffer());

	//Sleep(5000);

	DWORD nProc = ::GetCurrentProcessId();

	handle_data data;
	data.process_id = nProc;
	data.window_handle = 0;
	 
	::EnumWindows(EnumWindowsProc1, (LPARAM)&data);
	if (data.window_handle == 0)
		return;

	TCHAR szText[1024];
	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	HWND hWnd = data.window_handle;

	// check child window "HCS16139C"
	HWND hWndParent = data.window_handle;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc1, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;
	
	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	// check child window "CefBrowserWindow"
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc1, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;

	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	// IE: Shell Embedding
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc1, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;

	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	// IE: Shell DocObject View
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc1, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;

	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	// IE: Internet Explorer_Server
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc1, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;

	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName (data.window_handle, szText, 1024);

	::SetForegroundWindow(hWnd);

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('A'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('A'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('C'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('C'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release
}

ProError TvGalvSurfApp::ShowDialog(CString &text)
{
	return PRO_TK_NO_ERROR;
}

double TvGalvSurfApp::SelectDiameter()
{
	ProError err;
	double ret = 0.0;

	ProSelection* pSels = NULL;
	int nSels = 0;
	err = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if (err)
	{
		LogProErr(L"ProSelect", err);
		return ret;
	}
	err = ProSelectionUnhighlight (pSels[0]);

	if (nSels != 1)
		return ret;

	err = ProGeomitemDiameterEval(pSels[0], &ret);
	if (err)
	{
		LogProErr(L"ProGeomitemDiameterEval", err);
		return ret;
	}

	LogMsg(L"Diameter selected: %g", ret);

	return ret;
}

bool TvGalvSurfApp::UpdateDiameters()
{
	return true;
}

void TvGalvSurfApp::ResetUI()
{
	ProError err;

	// re-initialize current model
	InitializeDefaults();

	// reset Holes area
	m_AreaHoles = 0.0;
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel2", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel3", L"");
	if (m_Collection)
	{
		ProCollectionFree(&m_Collection);
		m_Collection = NULL;
	}

	// reset hole information
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel6", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel7", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel8", L"");
	err = ProUIInputpanelWidestringSet(m_szUIDlgName, "Inputpanel9", L"");

	m_AreaCrossfeed = 0.0;
	m_CurrentListPos = -1;
}

bool TvGalvSurfApp::FixTotalArea(double* pArea)
{
	ProError err;

	CString AppPath = m_pOptions->GetString(L"DEFAULT", L"PathTvGewindeflaeche");
	if (AppPath.IsEmpty())
	{
		LogErr(L"[DEFAULT]PathTvGewindeflaeche not defined");
		return false;
	}

	// load this dll
	ProName app_name = L"TvGewindeflaeche";
	ProCharPath exec_file;
	sprintf_s(exec_file, PRO_PATH_SIZE, "%S\\x86e_win64\\TvGewindeFlaeche.dll", AppPath); 

	ProCharPath text_dir;
	strcpy_s(text_dir, PRO_PATH_SIZE, CW2A(AppPath));

	ProToolkitDllHandle handle;
	ProError user_err = PRO_TK_NO_ERROR;
	ProPath user_str = L"";
	err = ProToolkitDllLoad(app_name, exec_file, text_dir, PRO_B_TRUE, &handle, &user_err, user_str);
	if (err)
	{
		LogProErr(L"ProToolkitDllLoad", err);
		return false;
	}

	if (user_err!=PRO_TK_NO_ERROR)
	{
		LogErr(L"Load dll(%s) failed: %s", exec_file, user_str);
		return false;
	}
	LogMsg(L"%S loaded", exec_file);

	/////////////////////////////////////////////////////////////////////////////////
	// call open csv file proc
	ProArgument* p_inputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &p_inputs);
	if (err)
	{
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	ProArgument* p_outputs = NULL;
	err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) &p_outputs);
	if (err)
	{
		ProArgumentProarrayFree(&p_inputs);
		LogProErr(L"ProArrayAlloc", err);
		return false;
	}

	// hide main dialog
	err = ProUIDialogHide(m_szUIDlgName);
	if (err) return false;

	err = ProToolkitTaskExecute(handle, "GetFixedTotalArea", p_inputs, &p_outputs, &user_err);
	if (err)
	{
		LogProErr(L"ProToolkitTaskExecute", err, L"GetFixedTotalArea");
		ProArgumentProarrayFree(&p_inputs);
		ProArgumentProarrayFree(&p_outputs);
		ProUIDialogShow(m_szUIDlgName);
		return false;
	}

	ProUIDialogShow(m_szUIDlgName);

	// extract fixed area from argument
	int n_values = 0;
	err = ProArraySizeGet(p_outputs, &n_values);
	if (err) return FALSE;

	if (n_values == 1)
	{
		ProValueData value_data;
		err = ProArgumentByLabelGet(p_outputs, L"AREA_FIXED", &value_data);
		if (err)
		{
			LogErr(L"Argument \"AREA_FIXED\" not found");
			return FALSE;
		}

		if (value_data.type != PRO_VALUE_TYPE_DOUBLE)
			return FALSE;

		(*pArea) = value_data.v.d/10000.0;
		LogMsg(L"Fixed area: %g", value_data.v.d);
	}

	// free memory
	err = ProArgumentProarrayFree(&p_inputs);
	if (err) return FALSE;

	err = ProArgumentProarrayFree(&p_outputs);
	if (err) return FALSE;
	
	LogMsg(L"RunPproc GetFixedTotalArea succeed");
	/////////////////////////////////////////////////////////////////////////////////

	// unload dll
	err = ProToolkitDllUnload(handle);
	if (err)
	{
		LogProErr(L"ProToolkitDllUnload", err);
		return false;
	}
	LogMsg(L"%S unloaded", exec_file);

	return true;
}

void TvGalvSurfApp::UpdateLength()
{
}