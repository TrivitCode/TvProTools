﻿#include "stdafx.h"
#include "TvAssemblyTest.h"
#include "TvProUtils.h"
#include <TvSolid.h>
#include <ProAssembly.h>
#include <TvMath.h>

ProError TvRotateCompProc()
{
	ProError err = PRO_TK_NO_ERROR;

	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) return err;

	ProMdlType mdl_type;
	err = ProMdlTypeGet(mdl, &mdl_type);
	if (err) return err;

	if (mdl_type != PRO_MDL_ASSEMBLY)
		return err;

	TvSolid solid((ProSolid)mdl);
	err = solid.Initialize();
	if (err) return err;

	TvSolidList* p_comps = solid.GetComponents();
	if (p_comps == NULL) return err;

	if (p_comps->empty())
		return err;

	TvSolid* pComp = p_comps->at(0);

	ProAsmcomp asm_comp;
	asm_comp.id = pComp->GetAsmcompID();
	asm_comp.owner = mdl;
	asm_comp.type = PRO_FEATURE;

	ProMatrix trans;
	err = ProAsmcompPositionGet(&asm_comp, trans);
	if (err) return err;

	CString Name = solid.GetName();
	ProName name;

	for (int i=0; i<12; i++)
	{
		Sleep(1000);
		TvUtils::TvMatrixInit(trans, 0.0, 0.0, 0.0, (i+1)*30.0, 0.0, 0.0);
		err = ProAsmcompPositionSet(NULL, &asm_comp, trans);
		if (err) return err;

		err = ProAsmcompRegenerate(&asm_comp, PRO_B_FALSE);
		if (err) return err;

		err = ProMdlDisplay(mdl);
		if (err) return err;

		CString SaveName;
		SaveName.Format(L"%s_%d", Name, i+1);
		wcscpy_s(name, SaveName);

		err = ProMdlRename(mdl, name);
		if (err) return err;

		err = ProMdlSave(mdl);
		if (err) return err;		
	}

	wcscpy_s(name, Name);
	err = ProMdlRename(mdl, name);
	if (err) return err;

	err = ProMdlSave(mdl);
	if (err) return err;

	return PRO_TK_NO_ERROR;
}

ProError TvGetTransMatrixProc()
{
	ProError err = PRO_TK_NO_ERROR;

#ifdef _DEBUG
	CMemoryState _mem1, _mem2, _mem_diff;
	_mem1.Checkpoint();
#endif

	// let user to choose a dimension, and change tolerance to middle
	ProSelection *pSels = NULL;
	int nSels = 0;
	err = ProSelect("prt_or_asm", 1, NULL, NULL, NULL, NULL, &pSels, &nSels);
	if( err || nSels != 1)
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_MSGW", L"select cancelled", err);

	ProAsmcomppath comp_path;
	err = ProSelectionAsmcomppathGet(pSels[0], &comp_path);
	if (err) return err;

	// get transformation matrix
	ProMatrix trf;
	err = ProAsmcomppathTrfGet(&comp_path, PRO_B_TRUE, trf);
	if (err) return err;

	TvMatrixSetAccuracy(trf, -0.000001, 0.000001);
	CString text;
	for (int i=0; i<4; i++)
	{
		CString line;
		line.Format(L"%g, %g, %g, %g;\r\n", trf[i][0], trf[i][1], trf[i][2], trf[i][3]);
		text += line;
	}
	//

#ifdef _DEBUG
	_mem2.Checkpoint();
	if (_mem_diff.Difference(_mem1, _mem2))
	{
		TRACE("-> ERR!!!Memory leak detected!\n");  
		_mem_diff.DumpStatistics();
		AfxMessageBox(L"Memory leak detected!");
	}
	else
	{
		TRACE("-> No Memory leak detected!\n");
	}
#endif

	return err;
}