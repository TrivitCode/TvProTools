#pragma once

#include "TvProUtils.h"

extern "C" PRO_TK_DLL_EXPORT ProError TvUdfAdd(ProArgument* inputs, ProArgument** outputs);

ProError TvUdfFamtblExportProc();
ProError TvMacroUdfCreate(LPCTSTR szPathname);
