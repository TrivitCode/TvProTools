#include "stdafx.h"
#include "TvProUdf.h"
#include <ProUdf.h>
#include <ProMenu.h>
#include <ProWindows.h>
#include <shlwapi.h>
#include <TvProTkUtils.h>
using namespace TvUtils;

extern "C" PRO_TK_DLL_EXPORT ProError TvUdfAdd(ProArgument* inputs, ProArgument** outputs)
{
	ProError err = PRO_TK_NO_ERROR;

	if (inputs == NULL || outputs == NULL)
		return PRO_TK_BAD_INPUTS;

	// get input argument 1: udf pathname
	ProArgument in1;
	err = ProArgumentByLabelGet(inputs, L"TV_UDF_ADD_PATHNAME", &in1.value);
	if (err) return err;

	// get input argument 2: csys, as ProSelection 
	ProArgument in2;
	bool csys_defined = false;
	ProModelitem cs_mi;

	err = ProArgumentByLabelGet(inputs, L"TV_UDF_ADD_CSYS", &in2.value);
	if (err == PRO_TK_NO_ERROR) 
	{

#ifdef _DEBUG
		err = ProSelectionHighlight(in2.value.v.r, PRO_COLOR_HIGHLITE);
		if (err) return err;
#endif

		err = ProSelectionModelitemGet(in2.value.v.r, &cs_mi);
		if (err) return err;
		csys_defined = true;
	}
	
	// get input argument 3: ProMdl
	ProArgument in3;
	err = ProArgumentByLabelGet(inputs, L"TV_UDF_ADD_MDL", &in3.value);
	if (err) return err;
	ProModelitem mdl_mi;
	err = ProSelectionModelitemGet(in3.value.v.r, &mdl_mi);
	if (err) return err;

	ProMdl mdl;
	err = ProModelitemMdlGet(&mdl_mi, &mdl);
	if (err) return err;

#ifdef _DEBUG
	ProName mdl_name;
	err = ProMdlNameGet(mdl, mdl_name);
	if (err) return err;
#endif

	// get input argument 4: prompt of reference
	ProArgument in4;
	ProLine udf_prompt;
	if ( csys_defined )
	{
		err = ProArgumentByLabelGet(inputs, L"TV_UDF_ADD_REF", &in4.value);
		if (err) return err;

		err = ProWstringCopy(in4.value.v.w, udf_prompt, PRO_VALUE_UNUSED);
		if (err) return err;
	}

	////////////////////////////////////////////////////////////////
	//
	// load udf file
	//
	// define udf data
	ProUdfdata udf_data;
	err = ProUdfdataAlloc( &udf_data );
	if (err) return err;

	// extract udf path name
	ProPath udf_path;
	err = ProWstringCopy(in1.value.v.w, udf_path, PRO_VALUE_UNUSED);
	if (err) return err;

	err = ProUdfdataPathSet( udf_data, udf_path);
	if (err) return err;

	// create udf
	ProGroup udf;

	// set reference
	if (csys_defined)
	{
		ProUdfreference udf_ref;
		err = ProUdfreferenceAlloc(udf_prompt, in2.value.v.r, PRO_B_FALSE, &udf_ref);
		if (err) return err;

		err = ProUdfdataReferenceAdd(udf_data, udf_ref);
		if (err) return err;	

		// create udf without option
		err = ProUdfCreate( (ProSolid) mdl, udf_data, NULL, NULL, 0, &udf);
		if (err) return err;
	}
	else
	{
		ProUdfCreateOption opts[1];
		opts[0] = PROUDFOPT_FIX_MODEL_UI_OFF;

		err = ProUdfdataDimdisplaySet(udf_data, PROUDFDIMDISP_NORMAL);
		if (err) return err;

		// create udf with option
		err = ProUdfCreate( (ProSolid) mdl, udf_data, NULL, opts, 1, &udf);
		if (err) return err;
	}

	

	// free data
	err = ProUdfdataFree(udf_data);
	if (err) return err;

	//////////////////////////////////////////////////////////////////////
	//
	// set udf as output argument
	// check input arguments
	int nOutputs = 0;
	err = ProArraySizeGet( (ProArray) *outputs, &nOutputs);
	if (err) 
	{
		err = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*) outputs);
		if (err) return err;
	}

	// set output argument 1: csv pathname
	ProArgument out1;
	ProWstringCopy(L"TV_UDF_ADD_UDF", out1.label, PRO_VALUE_UNUSED);
	out1.value.type = PRO_VALUE_TYPE_SELECTION;

	// convert ProGroup to ProSelection
	err = ProSelectionAlloc(NULL, (ProModelitem*)&udf, &out1.value.v.r);
	if (err) return err;

	err = ProArrayObjectAdd( (ProArray*) outputs, -1, 1, &out1 );
	if (err) return err;

	return err;
}

ProError TvUdfFamtblExportProc()
{
	ProError err = PRO_TK_NO_ERROR;

	// check if current is part mode
	ProMdl mdl;
	err = ProMdlCurrentGet(&mdl);
	if (err) 
	{
		ProMessageClear();
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_NO_CURRENT_MODEL");
		return err;
	}

	ProMdlType type;
	err = ProMdlTypeGet(mdl, &type);
	if (err) return err;

	if (type != PRO_MDL_PART)
	{
		ProMessageClear();
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_CURRENT_NOT_PART");
		return err;
	}

	ProPath path;
	err = ProDirectoryChoose(NULL, NULL, NULL, NULL, path);
	if (err) return err;

	// list all .gph files in this directory
	ProPath *files = NULL, *dirs = NULL;
	err = ProArrayAlloc(0, sizeof(ProPath), 1, (ProArray*)&files);
	if (err) return err;

	err = ProArrayAlloc(0, sizeof(ProPath), 1, (ProArray*)&dirs);
	if (err) return err;

	ProLine filter;
	wcscpy_s(filter, L"*.gph");

	err = ProFilesList(path, filter, PRO_FILE_LIST_LATEST_SORTED, &files, &dirs);
	if (err) return err;

	err = ProArrayFree((ProArray*)&dirs);
	if (err) return err;

	int nfiles = 0;
	err = ProArraySizeGet(files, &nfiles);
	if (err) return err;

	if (nfiles == 0)
	{
		ProMessageClear();
		ProMessageDisplay(MSG_FILE, "TVPROTOOLS_DIR_EMPTY", path);
		return err;
	}

	for (int i=0; i<nfiles; i++)
	{
		ProPath pathname;
		wcscpy_s(pathname, files[i]);

		// parse file name
		ProName wszName;
		ProPath wszPath;
		err = ProFilenameParse(pathname, wszPath, wszName, NULL, NULL);
		if (err) continue;

		// check if ptd file exists
		CString ptd(wszPath);
		ptd = ptd + wszName + L".ptd";
		if (PathFileExists(ptd))
		{
			ProMessageClear();
			ProMessageDisplay(MSG_FILE, "TVPROTOOLS_FILE_EXIST", ptd.GetBuffer());
			continue;
		}

		CString strPathname(pathname);
		strPathname.Replace(L"\\", L"/");

		CString cmd;
		cmd.Format(L"~ Command `ProCmdMmUDFLib`;\
#MODIFY;\
~ Trail `UI Desktop` `UI Desktop` `DLG_PREVIEW_POST` `file_open`;\
~ Input `file_open` `Inputname` `%s`;\
~ Update `file_open` `Inputname` `%s`;\
~ Activate `file_open` `Open`;\
~ Select `Odui_Dlg_01` `odui_steps` 1 `FAMILY TABLE`;\
~ Activate `Odui_Dlg_01` `odui_steps` 1 `FAMILY TABLE`;\
~ Select `ftb_edit_table` `MenuBar` 1 `File`;\
~ Select `ftb_edit_table` `Write`;\
~ Close `ftb_edit_table` `MenuBar`;\
~ Close `ftb_edit_table` `Write`;\
~ Activate `ftb_edit_table` `WriteAsProtab`;\
~ Trail `UI Desktop` `UI Desktop` `DLG_PREVIEW_POST` `file_open`;\
~ Update `file_open` `Inputname` `%s`;\
~ Activate `file_open` `Open`;\
~ Activate `ftb_edit_table` `Cancel`;\
~ Activate `0_std_confirm` `OK`;\
~ Activate `Odui_Dlg_01` `cancel`;\
~ Activate `0_std_confirm` `OK`;\
#DONE/RETURN", strPathname, strPathname, wszName);

		err = ProMacroLoad(cmd.GetBuffer());
		if (err) return err;
	}
	
	err = ProArrayFree((ProArray*)&files);
	if (err) return err;

	err = ProMdlEraseNotDisplayed();
	if (err) return err;

	return err;
}

ProError TvProUdfTest(TvProTkUdfInfo udf, ProPath pathname)
{
	ProError err = PRO_TK_NO_ERROR;

	// define udf data
	ProUdfdata data;
	err = ProUdfdataAlloc( &data );
	if (err) return err;

	// set name
	err = ProUdfdataNameSet( data, udf.Name, udf.Instance );
	if (err) return err;

	// set path
	err = ProUdfdataPathSet( data, pathname);
	if (err) return err;

	//
	// get var dims
	ProUdfvardim *pVardims = NULL;
	err = ProUdfdataVardimsGet( data, &pVardims );
	if (err == PRO_TK_NO_ERROR)
	{
		err = ProArrayFree( (ProArray*) &pVardims);
		if (err) return err;
	}

	// get var params
	ProUdfvarparam *pVarparams = NULL;
	err = ProUdfdataVarparamsGet( data, &pVarparams );
	if (err == PRO_TK_NO_ERROR)
	{
		int nVarparams = 0;
		err = ProArraySizeGet( pVarparams, &nVarparams );
		if (err) return err;

		err = ProArrayFree( (ProArray*) &pVarparams);
		if (err) return err;
	}

	// get external symbols
	ProUdfextsymbol *pExtsyms = NULL;
	err = ProUdfdataExternalsymbolsGet( data, &pExtsyms );
	if (err == PRO_TK_NO_ERROR)
	{
		int nExtsyms = 0;
		err = ProArraySizeGet( pExtsyms, &nExtsyms );
		if (err) return err;

		err = ProArrayFree( (ProArray*) &pExtsyms);
		if (err) return err;
	}

	// get external symbols
	ProName *pInstnames = NULL;
	err = ProUdfdataInstancenamesGet( data, &pInstnames );
	if (err == PRO_TK_NO_ERROR)
	{
		int nInstnames = 0;
		err = ProArraySizeGet( pInstnames, &nInstnames );
		if (err) return err;

		err = ProArrayFree( (ProArray*) &pInstnames);
		if (err) return err;
	}

	// get required reference 
	ProUdfRequiredRef *pRegRefs = NULL;
	err = ProUdfdataRequiredreferencesGet( data, &pRegRefs );
	if (err == PRO_TK_NO_ERROR)
	{
		// get reference of created udf feature
		ProSelection *pRefs = NULL;
		int nRefs = 0;
		err = TvGroupReferencesGet( & udf.Udf, &pRefs, &nRefs );
		if (err) return err;

		int nRegRefs = 0;
		err = ProArraySizeGet( pRegRefs, &nRegRefs );
		if (err) return err;

		for (int j=0; j<nRegRefs; j++)
		{
			ProType ref_type;
			err = ProUdfrequiredrefTypeGet( pRegRefs[j], &ref_type);
			if (err) continue;

			ProLine ref_prompt;
			err = ProUdfrequiredrefPromptGet( pRegRefs[j], ref_prompt );
			if (err) continue;

			// find defined ref with ...type?
			for (int k=0; k<nRefs; k++)
			{
				ProModelitem mi;
				err = ProSelectionModelitemGet(pRefs[k], &mi);
				if (err) continue;

				ProFeattype mi_type;
				err = ProFeatureTypeGet( &mi, &mi_type );
				if (err) continue;

				ProReference ref;
				err = ProSelectionToReference( pRefs[k], &ref );
				if (err) continue;

				ProType ref_f_type;
				err = ProReferenceTypeGet( ref, &ref_f_type );
				if (err) continue;

				if (ref_f_type != ref_type)
					continue;

				// set this reference
				ProUdfreference udf_ref;
				err = ProUdfreferenceAlloc( ref_prompt, pRefs[k], PRO_B_FALSE, &udf_ref );
				if (err) continue;

				err = ProUdfdataReferenceAdd( data, udf_ref);
				if (err) continue;
			}

		}

		err = ProUdfrequiredrefProarrayFree(pRegRefs);
		if (err) return err;
	}

	err = ProUdfdataFree(data);
	if (err) return err;

	return err;
}


ProError TvMacroUdfCreate(LPCTSTR szPathname)
{
	ProError err = PRO_TK_NO_ERROR;

	CString pathname(szPathname);
	pathname.Replace(L"\\", L"\\\\");
	CString cmd;
	cmd.Format(L"~ Command `ProCmdUserDefined`;\
~ Trail `UI Desktop` `UI Desktop` `DLG_PREVIEW_POST` `file_open`;\
~ Update `file_open` `Inputname` `%s`;\
~ Activate `file_open` `Open`", pathname );

	err = ProMacroLoad(cmd.GetBuffer());
	if (err) return err;

	return err;	
}