#include "StdAfx.h"
#include "HttpFileClient.h"
#include <afxinet.h>

CHttpFileClient::CHttpFileClient(void)
{
}

CHttpFileClient::~CHttpFileClient(void)
{
}

BOOL CHttpFileClient::CanWebsiteVisit(CString sURI)
{
	CHttpConnection* pHttpConn = NULL;
	CHttpFile* pHttpFile = NULL;
	CInternetSession cis;
	BOOL bResult = FALSE;
	BOOL bRetVal = FALSE;

	DWORD dwType = 0;
	DWORD dwStateCode = 0;
	INTERNET_PORT wPort = 0;
	CString sServer = _T("");
	CString sObject = _T("");
	const int nTimeOut = 5000;

	try
	{
		bResult = AfxParseURL(sURI, dwType, sServer, sObject, wPort);
		if (!bResult)
			return FALSE;

		cis.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, nTimeOut);
		cis.SetOption(INTERNET_OPTION_CONNECT_RETRIES, 1);

		pHttpConn = cis.GetHttpConnection(sServer, wPort);

		if (pHttpConn)
		{
			pHttpFile = pHttpConn->OpenRequest(CHttpConnection::HTTP_VERB_GET, sObject);
			if (pHttpFile->SendRequest())
			{
				pHttpFile->QueryInfoStatusCode(dwStateCode);

				if(dwStateCode == HTTP_STATUS_CREATED || dwStateCode == HTTP_STATUS_OK)
					bRetVal = TRUE;
			}
		}
	}
	catch(CInternetException* e)
	{
		e->Delete();
	}
	catch (...)
	{
	}

	if (pHttpFile)
	{
		pHttpFile->Close();
		delete pHttpFile;
	}

	if (pHttpConn)
	{
		pHttpConn->Close();
		delete pHttpConn;
	}

	cis.Close();

	return bRetVal;
}

BOOL CHttpFileClient::UploadFile(LPCTSTR szRemoteURI, LPCTSTR szLocalPath)
{
	//ENSURE_ARG_EX(NULL != szRemoteURI && NULL != szLocalPath);

	BOOL bResult = FALSE;
	DWORD dwType = 0;
	CString sServer = _T("");
	CString sObject = _T("");

	INTERNET_PORT wPort = 0;
	DWORD dwPostSize    = 0;
	const int nTimeOut  = 5000;

	CHttpConnection* pHttpConn = NULL;
	CHttpFile*       pHttpFile = NULL;
	CInternetSession cis;

	bResult =  AfxParseURL(szRemoteURI, dwType, sServer, sObject, wPort);
	if(!bResult)
		return FALSE;

	bResult = FALSE;

	try
	{
		cis.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, nTimeOut);
		cis.SetOption(INTERNET_OPTION_CONNECT_RETRIES, 1);       

		pHttpConn = cis.GetHttpConnection(sServer, wPort, NULL, NULL);
		//VERIFY_EX(NULL != pHttpConn);
		pHttpFile = pHttpConn->OpenRequest(CHttpConnection::HTTP_VERB_PUT, sObject);
		//VERIFY_EX(NULL != pHttpFile);

		if(UseHttpSendReqEx(pHttpFile, szLocalPath))
		{
			DWORD dwStateCode = 0;
			pHttpFile->QueryInfoStatusCode(dwStateCode);

			if(dwStateCode == HTTP_STATUS_CREATED || dwStateCode == HTTP_STATUS_OK)
				bResult = TRUE;
		}
	}
	catch (CFileException* e)
	{
		e->Delete();
		//REPORT_CACHED_EXCEPTION(_T("CFileException"));
	}
	catch (CInternetException* e)
	{
		e->Delete();

		CString sError;
		sError.Format(_T("Inernet connection error : %d"), e->m_dwError);
		//REPORT_CACHED_EXCEPTION(sError);
	}

	if (pHttpFile)
	{
		pHttpFile->Close();
		delete pHttpFile;
	}
	if (pHttpConn)
	{
		pHttpConn->Close();
		delete pHttpConn;
	}
	cis.Close();

	return bResult;
}


BOOL CHttpFileClient::DownLoadFile(LPCTSTR szRemoteURI, LPCTSTR szLocalPath)
{
	//ENSURE_ARG_EX(NULL != szRemoteURI && NULL != szLocalPath);

	CInternetSession session;
	CHttpConnection* pHttpConnection = NULL;
	CHttpFile* pHttpFile             = NULL;
	CString strServer   = _T(""), strObject = _T("");
	INTERNET_PORT wPort = 0;
	DWORD dwType        = 0;

	HANDLE hFile = NULL;
	TCHAR  pszBuffer[__BUFFER_SIZE];
	DWORD  dwFileSize = 0;

	const int nTimeOut = 2000;
	session.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, nTimeOut);
	session.SetOption(INTERNET_OPTION_CONNECT_RETRIES, 1);       

	BOOL bResult = FALSE;

	try
	{
		AfxParseURL(szRemoteURI, dwType, strServer, strObject, wPort);
		pHttpConnection = session.GetHttpConnection(strServer, wPort, NULL, NULL);
		//VERIFY_EX(NULL != pHttpConnection);
		pHttpFile = pHttpConnection->OpenRequest(CHttpConnection::HTTP_VERB_GET, strObject);
		//VERIFY_EX(NULL != pHttpFile);
		if(!pHttpFile->SendRequest())
			goto _err_handler;

		DWORD dwStateCode;
		pHttpFile->QueryInfoStatusCode(dwStateCode);
		if(dwStateCode != HTTP_STATUS_OK)
			goto _err_handler;

		hFile = CreateFile(szLocalPath, GENERIC_WRITE,
			FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL); 
		if(hFile == INVALID_HANDLE_VALUE)
			goto _err_handler;

		BOOL bRet = pHttpFile->QueryInfo(HTTP_QUERY_CONTENT_LENGTH, dwFileSize);
		if (!bRet)
			goto _err_handler;


		DWORD dwWrite = 0, dwTotalWrite = 0;
		UINT nRead = 0;

		do
		{
			nRead = pHttpFile->Read(pszBuffer, __BUFFER_SIZE);
			if (nRead <= 0) break;
			WriteFile(hFile, pszBuffer, nRead, &dwWrite, NULL);
			//VERIFY_EX(nRead == dwWrite);
			dwTotalWrite += dwWrite;
		} while (TRUE);

		if (dwTotalWrite != dwFileSize)
			goto _err_handler;

		bResult = TRUE;
	}
	catch (CFileException* e)
	{
		e->Delete();
		//REPORT_CACHED_EXCEPTION(_T("CFileException"));
	}
	catch (CInternetException* e)
	{
		CString sError;
		sError.Format(_T("Inernet connection error : %d"), e->m_dwError);
		e->Delete();
		//REPORT_CACHED_EXCEPTION(sError);
	}

_err_handler:
	if (pHttpFile)
	{
		pHttpFile->Close();
		delete pHttpFile;
	}
	if (pHttpConnection)
	{
		pHttpConnection->Close();
		delete pHttpConnection;
	}
	session.Close();

	if (hFile) CloseHandle(hFile);

	return bResult;
}

BOOL CHttpFileClient::DeleteFile(LPCTSTR szRemoteURI)
{
	//ENSURE_ARG_EX(NULL != szRemoteURI);

	CInternetSession session;
	CHttpConnection* pHttpConnection = NULL;
	CHttpFile* pHttpFile             = NULL;
	CString strServer   = _T(""), strObject = _T("");
	INTERNET_PORT wPort = 0;
	DWORD dwType        = 0;

	const int nTimeOut = 2000;
	session.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, nTimeOut);
	session.SetOption(INTERNET_OPTION_CONNECT_RETRIES, 1);       

	BOOL bResult = FALSE;

	try
	{
		AfxParseURL(szRemoteURI, dwType, strServer, strObject, wPort);
		pHttpConnection = session.GetHttpConnection(strServer, wPort, NULL, NULL);
		//VERIFY_EX(NULL != pHttpConnection);
		pHttpFile = pHttpConnection->OpenRequest(CHttpConnection::HTTP_VERB_DELETE, strObject);
		//VERIFY_EX(NULL != pHttpFile);
		if(!pHttpFile->SendRequest())
			goto _err_handler;

		DWORD dwStateCode;
		pHttpFile->QueryInfoStatusCode(dwStateCode);
		if(dwStateCode != HTTP_STATUS_OK)
			goto _err_handler;

		bResult = TRUE;
	}
	catch (CFileException* e)
	{
		e->Delete();
		//REPORT_CACHED_EXCEPTION(_T("CFileException"));
	}
	catch (CInternetException* e)
	{
		CString sError;
		sError.Format(_T("Inernet connection error : %d"), e->m_dwError);
		//REPORT_CACHED_EXCEPTION(sError);
	}

_err_handler:
	if (pHttpFile)
	{
		pHttpFile->Close();
		delete pHttpFile;
	}
	if (pHttpConnection)
	{
		pHttpConnection->Close();
		delete pHttpConnection;
	}
	session.Close();

	return bResult;
}

BOOL CHttpFileClient::UseHttpSendReqEx(CHttpFile* httpFile, LPCTSTR szLocalFile)
{
	//ENSURE_ARG_EX(NULL != httpFile);
	//ENSURE_ARG_EX(NULL != szLocalFile);

	INTERNET_BUFFERS BufferIn;
	DWORD dwTotalWritten = 0;
	BYTE  pFileBuffer[__BUFFER_SIZE];
	DWORD dwPostSize = 0;
	CFile file;
	BOOL  bRet = FALSE;

	bRet = file.Open(szLocalFile, CFile::shareDenyNone | CFile::modeRead);
	if (!bRet)
		return FALSE;

	dwPostSize = (DWORD)file.GetLength();
	//ENSURE_EX(dwPostSize >= 0 && dwPostSize < 0x80000000);

	memset(&BufferIn, 0, sizeof(BufferIn));
	BufferIn.dwStructSize    = sizeof( INTERNET_BUFFERS ); // Must be set or error will occur
	BufferIn.Next            = NULL;
	BufferIn.lpcszHeader     = NULL;
	BufferIn.dwHeadersLength = 0;
	BufferIn.dwHeadersTotal  = 0;
	BufferIn.lpvBuffer       = NULL;               
	BufferIn.dwBufferLength  = 0;
	BufferIn.dwBufferTotal   = dwPostSize; // This is the only member used other than dwStructSize
	BufferIn.dwOffsetLow     = 0;
	BufferIn.dwOffsetHigh    = 0;

	if(!httpFile->SendRequestEx(&BufferIn, NULL, HSR_INITIATE, 1))
	{
		TRACE1( "Error on HttpSendRequestEx %d\n",GetLastError() );
		return FALSE;
	}

	file.SeekToBegin();
	do
	{
		int nActual = file.Read(pFileBuffer, __BUFFER_SIZE);
		if (nActual <= 0) break;
		httpFile->Write(pFileBuffer, nActual);
		dwTotalWritten += nActual;
	} while (TRUE);

	if (dwTotalWritten != dwPostSize)
	{
		file.Close();
		TRACE1( "\nError on InternetWriteFile %lu \n", GetLastError() );
		return FALSE;
	}

	if(!httpFile->EndRequest(0, NULL, 1))
	{
		file.Close();
		TRACE1( "Error on HttpEndRequest %lu \n", GetLastError());
		return FALSE;
	}

	file.Close();

	return TRUE;
}