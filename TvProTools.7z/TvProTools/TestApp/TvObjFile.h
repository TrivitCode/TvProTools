#pragma once
#include "afx.h"
class TvObjFile : public CStdioFile
{
public:
	TvObjFile(void);
	~TvObjFile(void);


};

