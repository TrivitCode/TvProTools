#include "StdAfx.h"
#include "TvObjFile.h"


TvObjFile::TvObjFile(void)
{
}


TvObjFile::~TvObjFile(void)
{
}
