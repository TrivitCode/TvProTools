
// TestAppDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestApp.h"
#include "TestAppDlg.h"
#include "afxdialogex.h"
#include <Wininet.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CTestAppDlg dialog




CTestAppDlg::CTestAppDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CTestAppDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Edit1);
}

BEGIN_MESSAGE_MAP(CTestAppDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CTestAppDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CTestAppDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CTestAppDlg::OnBnClickedButton3)
END_MESSAGE_MAP()


// CTestAppDlg message handlers

BOOL CTestAppDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestAppDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestAppDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestAppDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CTestAppDlg::OnBnClickedButton1()
{
	CString cookie;

	DWORD size = 4096;
	BOOL ret = InternetGetCookie(L"http://localhost:8480/", NULL, cookie.GetBuffer(4096), &size);
	if (!ret)
	{
		LPVOID lpMsgBuf;
		DWORD dw = ::GetLastError(); 

		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |	FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			dw,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR) &lpMsgBuf,
			0, NULL );

		CString msg((LPCTSTR)lpMsgBuf);

		LocalFree(lpMsgBuf);
	}



}

#include <afxinet.h>  

BOOL UploadFile(LPCTSTR strURL, LPCTSTR strLocalFileName)  //
{
	ASSERT(strURL != NULL && strLocalFileName != NULL);

	BOOL bResult = FALSE;
	DWORD dwType = 0;
	CString strServer;
	CString strObject;
	INTERNET_PORT wPort = 0;
	DWORD dwFileLength = 0;
	char * pFileBuff = NULL;

	CHttpConnection * pHC = NULL;
	CHttpFile * pHF = NULL;
	CInternetSession cis;

	bResult =  AfxParseURL(strURL, dwType, strServer, strObject, wPort);
	if(!bResult)
		return FALSE;
	CFile file;
	try
	{
		if(!file.Open(strLocalFileName, CFile::shareDenyNone | CFile::modeRead))
			return FALSE;
		dwFileLength = (DWORD)file.GetLength();
		if(dwFileLength <= 0)
			return FALSE;
		pFileBuff = new char[dwFileLength];
		memset(pFileBuff, 0, sizeof(char) * dwFileLength);
		file.Read(pFileBuff, dwFileLength);

		const int nTimeOut = 5000;
		cis.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, nTimeOut); //
		cis.SetOption(INTERNET_OPTION_CONNECT_RETRIES, 1);  //
		pHC = cis.GetHttpConnection(strServer, wPort);  //

		pHF = pHC->OpenRequest(CHttpConnection::HTTP_VERB_POST, strObject);
		if(!pHF->SendRequest(NULL, 0, pFileBuff, dwFileLength))
		{
			delete[]pFileBuff;
			pFileBuff = NULL;
			pHF->Close();
			pHC->Close();
			cis.Close();
			return FALSE;
		}
		DWORD dwStateCode = 0;
		pHF->QueryInfoStatusCode(dwStateCode);

		if(dwStateCode == HTTP_STATUS_OK)
			bResult = TRUE;
	}

	catch(CInternetException * pEx)
	{
		TCHAR sz[256] = L"";
		pEx->GetErrorMessage(sz, 25);
		CString str;
		str.Format(L"InternetException occur!\r\n%s", sz);
		AfxMessageBox(str);
	}
	catch(CFileException& fe)
	{
		CString str;
		str.Format(L"FileException occur!\r\n%d", fe.m_lOsError);
		AfxMessageBox(str);
	}
	catch(...)
	{
		DWORD dwError = GetLastError();
		CString str;
		str.Format(L"Unknow Exception occur!\r\n%d", dwError);
		AfxMessageBox(str);
	}

	delete[]pFileBuff;
	pFileBuff = NULL;
	file.Close();
	pHF->Close();
	pHC->Close();
	cis.Close();
	return bResult;
}

BOOL UploadFile2(LPCTSTR strURL, LPCTSTR strLocalFileName)
{
    if (strURL == NULL ||
        strURL == _T("") ||
        strLocalFileName == NULL ||
        strLocalFileName == _T("") ||
        !PathFileExists(strLocalFileName) ||
        PathIsDirectory(strLocalFileName))
    {
        return FALSE;
    }
 
    CHttpFile *pHttpFile = NULL;
    CHttpConnection* connection = NULL;
    CInternetSession session(_T("UploadFile"));
 
    DWORD dwType;
    INTERNET_PORT nPort;
    CString strServer, strObject;
    if (!AfxParseURL(strURL, dwType, strServer, strObject, nPort)) return FALSE;
 
    BOOL bSuccess = FALSE;
    DWORD dwReadLength;
    //DWORD dwResponseLength;
    //DWORD dwTotalRequestLength;
    const DWORD dwChunkLength = 1024;
 
    char pBuffer[dwChunkLength];
    memset(pBuffer, 0, dwChunkLength);
 
    try
    {
        connection = session.GetHttpConnection(strServer, nPort);
        pHttpFile = connection->OpenRequest(CHttpConnection::HTTP_VERB_POST, strObject);
 
        CTime ct;
        CString strTime, strBoundary;
        ct = CTime::GetCurrentTime();
        strTime = ct.Format(_T("%Y%m%d%H%M%S"));
        strBoundary = _T("*-*-*") + strTime + _T("*-*-*");
 
        CString strPreFileHeaders;
        strPreFileHeaders.Format(_T("Content-Type: multipart/form-data; boundary=%s\r\n"), strBoundary);
        pHttpFile->AddRequestHeaders(strPreFileHeaders);
 
        CString strPostData;
        strPostData.Format(_T("--%s\r\nContent-Disposition: form-data; name =\"voice\"; filename=\"%s.wav\"\r\nContent-Type: audio/x-wav\r\n\r\n"), strBoundary, strTime);
        CString endPostData;
        endPostData.Format(_T("\r\n--%s--\r\n"), strBoundary);
 
        CFile file;
        file.Open(strLocalFileName, CFile::shareDenyNone | CFile::modeRead);
 
        DWORD sendLength = strPostData.GetLength() + endPostData.GetLength() + (int)file.GetLength();
        pHttpFile->SendRequestEx(sendLength, HSR_SYNC | HSR_INITIATE);
 
        pHttpFile->Write((LPSTR)(LPCTSTR)strPostData, strPostData.GetLength());
        dwReadLength = -1;
        while (0 != dwReadLength)
        {
            dwReadLength = file.Read(pBuffer, dwChunkLength);
            if (dwReadLength > 0)
            {
                pHttpFile->Write(pBuffer, dwReadLength);
            }
        }
        file.Close();
 
        pHttpFile->Write((LPSTR)(LPCTSTR)endPostData, endPostData.GetLength());
        pHttpFile->EndRequest();
 
        DWORD dwStauts;
        if (!pHttpFile->QueryInfoStatusCode(dwStauts) ||
            dwStauts < 200 || 299 < dwStauts)
        {
            bSuccess = FALSE;
        }
        else
        {
            CString response, text;
            for (int i = 0; pHttpFile->ReadString(text); ++i)
            {
                response += text + L"\r\n";
            }
            if (response.IsEmpty())
            {
                bSuccess = FALSE;
            }
            else
            {
                bSuccess = FALSE;
            }
        }
    }
    catch (...)
    {
        bSuccess = FALSE;
    }
 
    if (pHttpFile != NULL)
    {
        pHttpFile->Close();
        delete pHttpFile;
        pHttpFile = NULL;
    }
    if (connection != NULL)
    {
        connection->Close();
        delete connection;
        connection = NULL;
    }
    session.Close();
    return bSuccess;
}

bool UploadString(const wchar_t *wszRemotePath, CString *pstrBuf)
{
	if( !wszRemotePath || !pstrBuf )
		return false;

	CInternetSession *pInet = new CInternetSession();
	CInternetFile* pFile = NULL;
	try
	{      
		pFile = (CInternetFile*) pInet->OpenURL(wszRemotePath, 1, 
				 INTERNET_FLAG_TRANSFER_ASCII|INTERNET_FLAG_RELOAD|INTERNET_FLAG_DONT_CACHE, NULL, 0);
	}
	catch (CInternetException* m_pException)
	{      
		pFile = NULL;  
		m_pException->Delete();
		pInet->Close();
		delete pInet;
		return false;
	} 

	// read data from server
	if( pFile == NULL )
	{
		pInet->Close();
		delete pInet;
		return false;
	}

	CString strBuf;
	while (pFile->ReadString(strBuf) != NULL)  
		pstrBuf->Append(strBuf);

	pFile->Close();
	delete pFile;

	pInet->Close();
	delete pInet;
	return true;
}

#include "HttpFileClient.h"

void FTPUploadFile()
{
	CInternetSession * pInternetSession = NULL;  
	CFtpConnection* pFtpConnection = NULL;  

	pInternetSession = new CInternetSession(AfxGetAppName());  

	CString strADddress = L"localhost";  

	CString strUserName = L"anonymous";  
	CString strPwd = L"";  

	CString strDir = L"\\";

	pFtpConnection = pInternetSession->GetFtpConnection(strADddress, strUserName, strPwd);  
	
	BOOL bRetVal = pFtpConnection->SetCurrentDirectory(strDir);  
	if(bRetVal == FALSE)  
	{  
		AfxMessageBox(L"failed to set current directory");  
		return;  
	}  
	else  
	{  
		CString strLocalFile = L"C:\\Temp\\trail.txt.232";  
		CString strRemoteFile = L"trail.txt";  
		if (!pFtpConnection->PutFile(strLocalFile, strRemoteFile))
		{
			 DWORD eno = GetLastError();

		}
	}  

	if(NULL != pFtpConnection)  
	{  
		pFtpConnection->Close();  
		delete pFtpConnection;  
		pFtpConnection = NULL;  
	}  
	if(NULL != pInternetSession)  
	{  
		delete pInternetSession;  
		pInternetSession = NULL;  
	}
}

struct handle_data {
    unsigned long process_id;
    HWND window_handle;
};

BOOL CALLBACK EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	handle_data* p_data = (handle_data*)lParam;

	DWORD nProcId = 0;
	GetWindowThreadProcessId(hWnd, &nProcId);

	p_data->process_id = nProcId;
	p_data->window_handle = hWnd;

	// find Notepad++
	TCHAR szClassName[1024];
	::GetClassName(hWnd,  szClassName,  1024);
	if ( _tcscmp( szClassName,  _T("HCS16139P") ) != 0 )
		return TRUE;  // 

	//// find 
	//TCHAR szText[1024];
	//::GetWindowText(hWnd,  szText,  1024);
	//if ( _tcscmp( szText,  _T("*new 2 - Notepad++") ) != 0 )
	//	return TRUE;  // 

	return FALSE;
}

BOOL CALLBACK EnumVisibleChildWndProc2(HWND hwnd, LPARAM lParam)
{
	// check is window visiable
	if (!IsWindowVisible(hwnd))
		return TRUE;

	TCHAR szClassName[100];
	::GetClassName(hwnd,  szClassName,  sizeof(szClassName));
	if ( _tcscmp( szClassName,  _T("Scintilla") ) == 0 )
	{
		*(HWND*)lParam = hwnd;
		return FALSE;  //
	}
	else 
		return TRUE;  // continue
}

BOOL CALLBACK EnumVisibleChildWndProc(HWND hwnd, LPARAM lParam)
{
	// check is window visiable
	if (!IsWindowVisible(hwnd))
		return TRUE;

	*(HWND*)lParam = hwnd;
	return FALSE;  //
}

//#include < atlbase.h >
#include < mshtml.h >
#include < oleacc.h >
#pragma comment ( lib, "oleacc" )

BOOL GetDocPtr(HWND hWnd, IHTMLDocument2** ppDoc)
{
	UINT nMsg = ::RegisterWindowMessage( _T("WM_HTML_GETOBJECT") );
	LRESULT lRes;
	::SendMessageTimeout( hWnd, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (PDWORD_PTR) &lRes );

	if (::ObjectFromLresult(lRes, IID_IHTMLDocument2, 0, (LPVOID *)ppDoc) != S_OK)
		return FALSE;

	return TRUE;
}

void CTestAppDlg::OnBnClickedButton2()
{
	// Find Window
	// find chrome window, send ctrl+a, and ctrl+v
	DWORD nProc = ::GetCurrentProcessId();

	handle_data data;
	data.process_id = nProc;
	data.window_handle = 0;
	 
	::EnumWindows(EnumWindowsProc, (LPARAM)&data);
	if (data.window_handle == 0)
		return;

	TCHAR szText[1024];
	::GetWindowText(data.window_handle, szText, 1024);
	::GetClassName(data.window_handle,  szText, 1024);

	HWND hWnd = data.window_handle;

	// check child window "HCS16139C"
	HWND hWndParent = data.window_handle;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;
	
	::GetWindowText(hWnd, szText, 1024);
	::GetClassName (hWnd, szText, 1024);

	// check child window "CefBrowserWindow"
	hWndParent = hWnd;
	hWnd = 0;
	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
	if (hWnd == 0)
		return;

	::GetWindowText(hWnd, szText, 1024);
	::GetClassName (hWnd, szText, 1024);

//	// IE: Shell Embedding
//	hWndParent = hWnd;
//	hWnd = 0;
//	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
//	if (hWnd == 0)
//		return;
//
//	::GetWindowText(hWnd, szText, 1024);
//	::GetClassName (hWnd, szText, 1024);
//
//	// IE: Shell DocObject View
//	hWndParent = hWnd;
//	hWnd = 0;
//	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
//	if (hWnd == 0)
//		return;
//
//	::GetWindowText(hWnd, szText, 1024);
//	::GetClassName (hWnd, szText, 1024);
//
//	// IE: Internet Explorer_Server
//	hWndParent = hWnd;
//	hWnd = 0;
//	::EnumChildWindows(hWndParent, EnumVisibleChildWndProc, (LPARAM)&hWnd);
//	if (hWnd == 0)
//		return;
//
//	::GetWindowText(hWnd, szText, 1024);
//	::GetClassName (hWnd, szText, 1024);
//
//	//Sleep(1000);
//	CComPtr<IHTMLDocument2> spDoc;
//	if (!GetDocPtr(hWnd, &spDoc))
//		return;
//
//	// form
//	BSTR text = NULL;
//	spDoc->get_title(&text);
//
//	CString Text = text;
//
//	//spDoc->get_
//	//IHTMLElement *pElem = NULL;
//	//spDoc->get_body(&pElem);
//
//	//if (pElem)
//	//{
//	//	pElem->get_innerText(&text);
//	//	Text = text;
//	//}
//
//	CComPtr<IHTMLElementCollection> pElems;
//	if (spDoc->get_all(&pElems) != S_OK)
//		return;
//
//	long n_elems = 0;
//	if (pElems->get_length(&n_elems) != S_OK)
//		return;
//
//	
////	CString Text;
//	for (long i=0; i<n_elems; i++)
//	{
//		CComDispatchDriver spInputElement;
//		CComVariant vName, vVal, vId, vTitle;
//
//		if (pElems->item(CComVariant(i), CComVariant(), &spInputElement) != S_OK)
//			continue;
//
//		CComQIPtr <IHTMLElement, &IID_IHTMLElement> pElement;
//		if (spInputElement->QueryInterface(IID_IHTMLElement, (void**)&pElement) != S_OK)
//			continue;
//
//
//		pElement->get_innerText(&text);
//
//		// find string in text
//	}  
//
//	return;
//


	
	::SetForegroundWindow(hWnd);
	//::SetFocus(hWnd);
	//SetKeyboardState(VK_CONTROL);

	//INPUT ip={0}; KEYBDINPUT kb={0};
	//kb.wVk = VK_CONTROL;
	//kb.dwFlags = KEYEVENTF_EXTENDEDKEY;
	//ip.type=INPUT_KEYBOARD;
	//ip.ki=kb;
	//SendInput(1,&ip,sizeof(INPUT));
	
	//BOOL ret;
	////ret = ::PostMessage(hWnd, WM_SYSKEYDOWN, VK_CONTROL, 0);
	//SHORT vkey = VkKeyScan('a');
	//
	//ret = ::PostMessage(hWnd, WM_KEYDOWN, vkey, 0);
	//ret = ::PostMessage(hWnd, WM_KEYUP, VkKeyScan('a'), 0);
	//ret = ::PostMessage(hWnd, WM_SYSKEYUP, VK_CONTROL, 0);

	//kb.dwFlags = KEYEVENTF_KEYUP;
	//SendInput(1,&ip,sizeof(INPUT));

	//Sleep(500);

	//ret = ::PostMessage(hWnd, WM_KEYDOWN, VkKeyScan('c'), 0);
	//ret = ::PostMessage(hWnd, WM_KEYUP, VkKeyScan('c'), 0);

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('A'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('A'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

	keybd_event(VK_CONTROL,0x9d,0 , 0); // Ctrl Press
	keybd_event(VkKeyScan('C'),0x9e,0 , 0); // �A� Press
	keybd_event(VkKeyScan('C'),0x9e, KEYEVENTF_KEYUP,0); // �A� Release
	keybd_event(VK_CONTROL,0x9d,KEYEVENTF_KEYUP,0); // Ctrl Release

		//INPUT ip={0}; KEYBDINPUT kb={0};

	////kb.wScan=0xE1;
	//kb.wVk = VK_CONTROL;
	//kb.dwFlags = KEYEVENTF_EXTENDEDKEY;
	//ip.type=INPUT_KEYBOARD;
	//ip.ki=kb;
	//SendInput(1,&ip,sizeof(INPUT));

	//kb.wScan = 'A';
	//kb.dwFlags = KEYEVENTF_SCANCODE;
	//SendInput(1,&ip,sizeof(INPUT));

	//kb.dwFlags = KEYEVENTF_KEYUP;
	//SendInput(1,&ip,sizeof(INPUT));
	
}

//BOOL CTestAppDlg::GetSource(CString& refString)
//{
//	BOOL bRetVal = FALSE;
//	CComPtr<IDispatch> spDisp = GetHtmlDocument();
//
//	if (spDisp != NULL)
//	{
//		HGLOBAL hMemory;
//		hMemory = GlobalAlloc(GMEM_MOVEABLE, 0);
//		if (hMemory != NULL)
//		{
//			CComQIPtr<IPersistStreamInit> spPersistStream = spDisp;
//			if (spPersistStream != NULL)
//			{
//				CComPtr<IStream> spStream;
//				if (SUCCEEDED(CreateStreamOnHGlobal(hMemory, TRUE, &spStream)))
//				{
//					spPersistStream->Save(spStream, FALSE);
//
//					LPCTSTR pstr = (LPCTSTR) GlobalLock(hMemory);
//					if (pstr != NULL)
//					{
//						// Stream is always ANSI, but CString
//						// assignment operator will convert implicitly.
//
//						bRetVal = TRUE;
//						TRY
//						{                        
//							refString = pstr;
//						}
//						CATCH_ALL(e)
//						{
//							bRetVal = FALSE;
//							DELETE_EXCEPTION(e);
//						}
//						END_CATCH_ALL
//
//						if(bRetVal == FALSE)
//							GlobalFree(hMemory);
//						else
//							GlobalUnlock(hMemory);
//					}
//				}
//			}
//		}
//	}
//
//	return bRetVal;
//}


//#include <cef_browser_capi.h>
//#include "libcef_dll/ctocpp/browser_host_ctocpp.h"
//#include "libcef_dll/cpptoc/client_cpptoc.h"
//#include "libcef_dll/cpptoc/download_image_callback_cpptoc.h"
//#include "libcef_dll/cpptoc/navigation_entry_visitor_cpptoc.h"
//#include "libcef_dll/cpptoc/pdf_print_callback_cpptoc.h"
//#include "libcef_dll/cpptoc/run_file_dialog_callback_cpptoc.h"
//#include "libcef_dll/ctocpp/browser_ctocpp.h"
//#include "libcef_dll/ctocpp/drag_data_ctocpp.h"
//#include "libcef_dll/ctocpp/extension_ctocpp.h"
//#include "libcef_dll/ctocpp/navigation_entry_ctocpp.h"
//#include "libcef_dll/ctocpp/request_context_ctocpp.h"
//#include "libcef_dll/shutdown_checker.h"
//#include "libcef_dll/transfer_util.h"

//#pragma import "libcef.dll"

typedef int( *pCreateProc)(void*, void*, void*, void*, void*);

void CTestAppDlg::OnBnClickedButton3()
{
	//HMODULE hModule = LoadLibrary(L"C:\\PTC\\Creo\\Platform\\4\\libcef.dll");

	//if (hModule == NULL)
	//	return;

	//pCreateProc p_proc =  (pCreateProc)GetProcAddress(hModule, "cef_browser_host_create_browser");

	//p_proc(0,0,0,0,0);
	//CefWindowInfo windowInfo;
	//CefRefPtr<CefClient> client;
	//CefString url;
	//CefBrowserSettings settings;
 //   CefRefPtr<CefRequestContext> request_context;

	//cef_browser_host_create_browser(&windowInfo, CefClientCppToC::Wrap(client), url.GetStruct(), &settings,
 //     CefRequestContextCToCpp::Unwrap(request_context));

	//m_Edit1.SetFocus();

	::SetFocus(m_Edit1.m_hWnd);

	return;
}
